import bpy
import bmesh
from mathutils import Vector

from .constants import EPS
from .utils import (
    _ensure_object_mode,
    _mesh_apply_scale,
    _set_active,
    _world_height_to_local_dz,
)


def _clean_2d_points(points):
    clean = []
    for x, y in points:
        pt = (float(x), float(y))
        if clean and abs(clean[-1][0] - pt[0]) <= EPS and abs(clean[-1][1] - pt[1]) <= EPS:
            continue
        clean.append(pt)

    if len(clean) > 1 and abs(clean[0][0] - clean[-1][0]) <= EPS and abs(clean[0][1] - clean[-1][1]) <= EPS:
        clean.pop()

    changed = True
    while changed and len(clean) >= 3:
        changed = False
        result = []
        n = len(clean)
        for i, b in enumerate(clean):
            a = clean[(i - 1) % n]
            c = clean[(i + 1) % n]
            cross = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0])
            if abs(cross) <= EPS:
                changed = True
                continue
            result.append(b)
        clean = result
    return clean


def _create_polygon_prism_mesh(points, height: float, mesh_name: str = "BaseMesh", obj_name: str = "Building"):
    height = max(EPS, float(height))
    points = _clean_2d_points(points)
    if len(points) < 3:
        return None

    mesh = bpy.data.meshes.new(mesh_name)
    obj = bpy.data.objects.new(obj_name, mesh)
    bpy.context.collection.objects.link(obj)

    bm = bmesh.new()
    verts = [bm.verts.new((float(x), float(y), 0.0)) for (x, y) in points]
    face = bm.faces.new(verts)

    res = bmesh.ops.extrude_face_region(bm, geom=[face])
    extruded_verts = [e for e in res["geom"] if isinstance(e, bmesh.types.BMVert)]
    bmesh.ops.translate(bm, verts=extruded_verts, vec=Vector((0.0, 0.0, height)))


    bmesh.ops.translate(bm, verts=bm.verts, vec=Vector((0.0, 0.0, -height * 0.5)))

    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.normal_update()
    bm.to_mesh(mesh)
    bm.free()

    mesh.update()
    return obj


def _create_l_prism_mesh(
    width: float,
    depth: float,
    height: float,
    arm_width: float,
    x_length: float,
    y_length: float,
    vertical_width: float | None = None,
    horizontal_width: float | None = None,
):


    height = max(EPS, float(height))

    x_len = max(EPS * 10.0, float(x_length))
    y_len = max(EPS * 10.0, float(y_length))

    common_t = max(EPS, float(arm_width))
    v_t = max(EPS, float(vertical_width if vertical_width is not None else common_t))
    h_t = max(EPS, float(horizontal_width if horizontal_width is not None else common_t))


    v_t = min(v_t, x_len * 0.95)
    h_t = min(h_t, y_len * 0.95)

    pts = [
        (0.0, 0.0),
        (x_len, 0.0),
        (x_len, h_t),
        (v_t, h_t),
        (v_t, y_len),
        (0.0, y_len),
    ]
    cx = x_len * 0.5
    cy = y_len * 0.5
    pts = [(x - cx, y - cy) for (x, y) in pts]
    return _create_polygon_prism_mesh(pts, height, mesh_name="LBaseMesh")


def _create_u_prism_mesh(
    width: float,
    depth: float,
    height: float,
    arm_width: float,
    left_length: float,
    right_length: float,
    left_arm_width: float | None = None,
    right_arm_width: float | None = None,
    support_depth: float | None = None,
):


    width = max(EPS, float(width))
    height = max(EPS, float(height))

    common_t = max(EPS, float(arm_width))
    left_t = max(EPS, float(left_arm_width if left_arm_width is not None else common_t))
    right_t = max(EPS, float(right_arm_width if right_arm_width is not None else common_t))
    support_t = max(EPS, float(support_depth if support_depth is not None else common_t))


    max_side_total = max(EPS, width * 0.95)
    side_total = left_t + right_t
    if side_total > max_side_total:
        k = max_side_total / side_total
        left_t *= k
        right_t *= k

    left_len = max(support_t + EPS, float(left_length))
    right_len = max(support_t + EPS, float(right_length))
    support_t = min(support_t, min(left_len, right_len) * 0.95)
    bbox_depth = max(left_len, right_len)

    pts = [
        (0.0, 0.0),
        (width, 0.0),
        (width, right_len),
        (width - right_t, right_len),
        (width - right_t, support_t),
        (left_t, support_t),
        (left_t, left_len),
        (0.0, left_len),
    ]
    cx = width * 0.5
    cy = bbox_depth * 0.5
    pts = [(x - cx, y - cy) for (x, y) in pts]
    return _create_polygon_prism_mesh(pts, height, mesh_name="UBaseMesh")


def _create_plus_prism_mesh(width: float, depth: float, height: float, arm_width: float | None = None, arm_ratio: float = 0.33):
    width = max(EPS, float(width))
    depth = max(EPS, float(depth))
    height = max(EPS, float(height))

    hw = width * 0.5
    hd = depth * 0.5

    if arm_width is None or float(arm_width) <= 0.0:
        ratio = min(0.95, max(0.05, float(arm_ratio)))
        arm_width = min(width, depth) * ratio
    else:
        arm_width = float(arm_width)


    arm_width = max(EPS, min(arm_width, width * 0.95, depth * 0.95))
    t = arm_width * 0.5

    pts = [
        (-t, -hd), (t, -hd), (t, -t),
        (hw, -t), (hw, t), (t, t),
        (t, hd), (-t, hd), (-t, t),
        (-hw, t), (-hw, -t), (-t, -t),
    ]

    return _create_polygon_prism_mesh(pts, height, mesh_name="PlusBaseMesh")


def create_building(
    floors=1,
    width=8.0,
    depth=6.0,
    floor_height=2.0,
    loc_x=0.0,
    loc_y=0.0,
    base_type="RECT",
    plus_arm_ratio=0.33,
    plus_arm_width=2.0,
    plus_size_mode="WIDTH",
    l_arm_width=2.0,
    l_vertical_width=None,
    l_horizontal_width=None,
    l_x_length=6.0,
    l_y_length=4.0,
    u_arm_width=1.5,
    u_left_arm_width=None,
    u_right_arm_width=None,
    u_support_depth=None,
    u_left_length=5.0,
    u_right_length=5.0,
):
    _ensure_object_mode()
    bpy.ops.object.select_all(action="DESELECT")

    base_type = str(base_type).upper().strip()

    if base_type == "RECT":
        bpy.ops.mesh.primitive_cube_add(size=2.0, location=(loc_x, loc_y, floor_height * 0.5))
        building = bpy.context.active_object
        building.name = "Building"
        building.dimensions = (width, depth, floor_height)
        _mesh_apply_scale(building)

    elif base_type == "CIRCLE":
        bpy.ops.mesh.primitive_cylinder_add(
            vertices=64,
            radius=1.0,
            depth=floor_height,
            location=(loc_x, loc_y, floor_height * 0.5),
        )
        building = bpy.context.active_object
        building.name = "Building"
        building.dimensions = (width, depth, floor_height)
        _mesh_apply_scale(building)

    elif base_type == "PLUS":
        plus_size_mode = "WIDTH"
        building = _create_plus_prism_mesh(
            width,
            depth,
            floor_height,
            arm_width=plus_arm_width,
            arm_ratio=plus_arm_ratio,
        )
        building.location = (loc_x, loc_y, floor_height * 0.5)
        _mesh_apply_scale(building)
        building["house_plus_size_mode"] = plus_size_mode
        building["house_plus_arm_width"] = float(min(width, depth, max(EPS, float(plus_arm_width))))

    elif base_type == "L":
        building = _create_l_prism_mesh(
            width,
            depth,
            floor_height,
            arm_width=l_arm_width,
            x_length=l_x_length,
            y_length=l_y_length,
            vertical_width=l_vertical_width,
            horizontal_width=l_horizontal_width,
        )
        building.location = (loc_x, loc_y, floor_height * 0.5)
        _mesh_apply_scale(building)
        building["house_l_arm_width"] = float(l_arm_width)
        building["house_l_vertical_width"] = float(l_vertical_width if l_vertical_width is not None else l_arm_width)
        building["house_l_horizontal_width"] = float(l_horizontal_width if l_horizontal_width is not None else l_arm_width)
        building["house_l_x_length"] = float(l_x_length)
        building["house_l_y_length"] = float(l_y_length)
        building["house_effective_width"] = float(l_x_length)
        building["house_effective_depth"] = float(l_y_length)

    elif base_type == "U":
        building = _create_u_prism_mesh(
            width,
            depth,
            floor_height,
            arm_width=u_arm_width,
            left_length=u_left_length,
            right_length=u_right_length,
            left_arm_width=u_left_arm_width,
            right_arm_width=u_right_arm_width,
            support_depth=u_support_depth,
        )
        building.location = (loc_x, loc_y, floor_height * 0.5)
        _mesh_apply_scale(building)
        building["house_u_arm_width"] = float(u_arm_width)
        building["house_u_left_arm_width"] = float(u_left_arm_width if u_left_arm_width is not None else u_arm_width)
        building["house_u_right_arm_width"] = float(u_right_arm_width if u_right_arm_width is not None else u_arm_width)
        building["house_u_support_depth"] = float(u_support_depth if u_support_depth is not None else u_arm_width)
        building["house_u_left_length"] = float(u_left_length)
        building["house_u_right_length"] = float(u_right_length)
        building["house_effective_width"] = float(width)
        building["house_effective_depth"] = float(max(u_left_length, u_right_length))

    else:
        return None

    building["house_floor_height"] = float(floor_height)
    building["house_base_type"] = base_type
    building["house_plus_arm_ratio"] = float(plus_arm_ratio)

    for _ in range(max(0, floors - 1)):
        add_floor(obj=building, floor_height=floor_height)

    _set_active(building)
    return building


def add_floor(obj=None, floor_height=2.0):
    _ensure_object_mode()
    if obj is None:
        obj = bpy.context.active_object

    if obj is None or obj.type != "MESH":
        return False, "Пожалуйста, выберите здание (Mesh)."

    dz_local = _world_height_to_local_dz(obj, floor_height)

    me = obj.data
    bm = bmesh.new()
    bm.from_mesh(me)

    max_z = max(v.co.z for v in bm.verts)
    top_faces = [f for f in bm.faces if all(abs(v.co.z - max_z) < EPS for v in f.verts)]
    if not top_faces:
        bm.free()
        return False, "Не найдена верхняя грань для экструзии."

    res = bmesh.ops.extrude_face_region(bm, geom=top_faces)
    verts_extruded = [ele for ele in res["geom"] if isinstance(ele, bmesh.types.BMVert)]
    bmesh.ops.translate(bm, verts=verts_extruded, vec=Vector((0, 0, dz_local)))

    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.normal_update()
    bm.to_mesh(me)
    bm.free()
    me.update()
    return True, None
