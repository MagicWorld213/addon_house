import bpy

from .utils import _parent_keep_world


def _unique_name(base: str) -> str:
    if base not in bpy.data.objects:
        return base
    i = 1
    while f"{base}.{i:03d}" in bpy.data.objects:
        i += 1
    return f"{base}.{i:03d}"


def _world_mesh_bounds(obj):
    if not obj or obj.type != "MESH" or not obj.data.vertices:
        return None
    mw = obj.matrix_world
    pts = [mw @ v.co for v in obj.data.vertices]
    return (
        min(p.x for p in pts), max(p.x for p in pts),
        min(p.y for p in pts), max(p.y for p in pts),
        min(p.z for p in pts), max(p.z for p in pts),
    )


def _make_platform_mesh_object(name, x0, x1, y0, y1, z0, z1, border_inset=0.45):
    width = max(0.01, float(x1 - x0))
    depth = max(0.01, float(y1 - y0))
    max_inset = max(0.0, min(width, depth) * 0.5 - 0.01)
    inset = min(max(0.0, float(border_inset)), max_inset)

    mesh = bpy.data.meshes.new(name + "Mesh")

    if inset <= 1e-6:
        verts = [
            (x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0),
            (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1),
        ]
        faces = [
            (3, 2, 1, 0),
            (4, 5, 6, 7),
            (0, 1, 5, 4),
            (1, 2, 6, 5),
            (2, 3, 7, 6),
            (3, 0, 4, 7),
        ]
    else:
        xi0 = x0 + inset
        xi1 = x1 - inset
        yi0 = y0 + inset
        yi1 = y1 - inset
        verts = [

            (x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0),

            (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1),

            (xi0, yi0, z1), (xi1, yi0, z1), (xi1, yi1, z1), (xi0, yi1, z1),
        ]
        faces = [
            (3, 2, 1, 0),
            (0, 1, 5, 4),
            (1, 2, 6, 5),
            (2, 3, 7, 6),
            (3, 0, 4, 7),

            (4, 5, 9, 8),
            (5, 6, 10, 9),
            (6, 7, 11, 10),
            (7, 4, 8, 11),
            (8, 9, 10, 11),
        ]

    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(_unique_name(name), mesh)
    bpy.context.collection.objects.link(obj)
    return obj


def _spawn_platform_under_building(
    building,
    offset_x=0.5,
    offset_y=0.5,
    height=0.2,
    border_inset=0.45,
    parent_to_building=True,
):
    bounds = _world_mesh_bounds(building)
    if not bounds:
        return None, "Не удалось определить размеры здания."
    min_x, max_x, min_y, max_y, min_z, _ = bounds
    ox = max(0.0, float(offset_x))
    oy = max(0.0, float(offset_y))
    h = max(0.01, float(height))
    platform = _make_platform_mesh_object(
        "Platform",
        min_x - ox,
        max_x + ox,
        min_y - oy,
        max_y + oy,
        min_z - h,
        min_z,
        border_inset=border_inset,
    )
    platform["house_generated_platform"] = True
    platform["house_platform_for"] = building.name
    platform["house_platform_overhang"] = ox if abs(ox - oy) <= 1e-6 else max(ox, oy)
    platform["house_platform_offset_x"] = ox
    platform["house_platform_offset_y"] = oy
    platform["house_platform_height"] = h
    platform["house_platform_border_inset"] = max(0.0, float(border_inset))
    if parent_to_building:
        _parent_keep_world(platform, building)
    return platform, None
