import bpy
import bmesh
from mathutils import Vector

from .constants import EPS
from .utils import (
    _face_axes_bounds_world_by_index,
    _parent_keep_world,
    _set_object_basis_world,
)


def _create_stairs_object(steps: int, size_x: float, size_y: float, size_z: float):
    steps = max(1, int(steps))
    size_x = max(EPS, float(size_x))
    size_y = max(EPS, float(size_y))
    size_z = max(EPS, float(size_z))

    run = size_x / steps
    rise = size_z / steps

    pts = [(0.0, 0.0), (size_x, 0.0), (size_x, size_z)]
    for i in range(steps - 1, -1, -1):
        pts.append((i * run, (i + 1) * rise))
        pts.append((i * run, i * rise))

    mesh = bpy.data.meshes.new("StairsMesh")
    obj = bpy.data.objects.new("Stairs", mesh)
    bpy.context.collection.objects.link(obj)

    bm = bmesh.new()
    verts = [bm.verts.new((x, 0.0, z)) for (x, z) in pts]
    face = bm.faces.new(verts)

    res = bmesh.ops.extrude_face_region(bm, geom=[face])
    extruded_verts = [e for e in res["geom"] if isinstance(e, bmesh.types.BMVert)]
    bmesh.ops.translate(bm, verts=extruded_verts, vec=Vector((0.0, size_y, 0.0)))

    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.normal_update()
    bm.to_mesh(mesh)
    bm.free()

    return obj


def _spawn_stairs_on_face(
    building,
    face_index: int,
    steps: int,
    size_x: float,
    size_y: float,
    size_z: float,
    offset_x: float,
    offset_z: float,
    gap: float,
    parent_to_building: bool = True,
):
    data, err = _face_axes_bounds_world_by_index(building, face_index)
    if err:
        print(err)
        return None

    center_w, n_w, right_w, up_w, min_u, max_u, min_v, _ = data

    stairs = _create_stairs_object(steps, size_x, size_y, size_z)

    u_center = (min_u + max_u) * 0.5 + float(offset_x)
    u_origin = u_center - (float(size_y) * 0.5)

    v_origin = float(min_v) + float(offset_z)

    g = max(0.0, float(gap))
    loc = center_w + right_w * u_origin + up_w * v_origin + n_w * (g + float(size_x))

    _set_object_basis_world(stairs, -n_w, right_w, up_w, loc)

    if parent_to_building:
        _parent_keep_world(stairs, building)

    return stairs
