import bpy
import bmesh
from math import sin, cos, pi
from mathutils import Vector, Matrix
from mathutils.geometry import tessellate_polygon

from .utils import (
    _face_axes_bounds_world_by_index,
    _parent_keep_world,
    _set_object_basis_world,
)


def _unique_object_name(base: str) -> str:
    if base not in bpy.data.objects:
        return base
    i = 1
    while f"{base}.{i:03d}" in bpy.data.objects:
        i += 1
    return f"{base}.{i:03d}"


def _unique_modifier_name(obj: bpy.types.Object, base: str) -> str:
    if not obj.modifiers.get(base):
        return base
    i = 1
    while obj.modifiers.get(f"{base}.{i:03d}"):
        i += 1
    return f"{base}.{i:03d}"


def _prepare_cutout_object(obj: bpy.types.Object, building: bpy.types.Object):


    obj.hide_render = True
    obj.display_type = "WIRE"
    obj["house_cutout"] = True
    _parent_keep_world(obj, building)


def _opening_surface_point(building, face_index, u, v):
    data, err = _face_axes_bounds_world_by_index(building, face_index)
    if err:
        print(err)
        return None, err
    center_w, n_w, right_w, up_w, *_ = data
    return (center_w + right_w * float(u) + up_w * float(v), n_w, right_w, up_w), None


def _cutout_location(surface_w: Vector, n_w: Vector, depth: float, outward_margin: float):
    depth = max(0.001, float(depth))
    outward_margin = max(0.001, float(outward_margin))
    total = depth + outward_margin


    loc = surface_w + n_w * ((outward_margin - depth) * 0.5)
    return loc, total


def _make_profile_points(profile_type: str, width: float, height: float, segments: int = 16):
    profile_type = (profile_type or "RECT").upper()
    width = max(0.001, float(width))
    height = max(0.001, float(height))
    segments = max(4, int(segments or 16))

    if profile_type == "ROUND":

        pts = []
        rx = width * 0.5
        rz = height * 0.5
        for i in range(max(8, segments)):
            a = (i / max(8, segments)) * pi * 2.0
            pts.append((cos(a) * rx, sin(a) * rz))
        return pts

    if profile_type == "ARCH":


        r = width * 0.5
        z_bottom = -height * 0.5
        z_top = height * 0.5
        z_arc_center = max(z_bottom, z_top - r)
        x0, x1 = -width * 0.5, width * 0.5
        pts = [(x0, z_bottom), (x1, z_bottom), (x1, z_arc_center)]
        arc_steps = max(4, segments)
        for i in range(1, arc_steps):
            a = (i / arc_steps) * pi
            pts.append((cos(a) * r, z_arc_center + sin(a) * r))
        pts.append((x0, z_arc_center))
        return pts


    return [
        (-width * 0.5, -height * 0.5),
        (width * 0.5, -height * 0.5),
        (width * 0.5, height * 0.5),
        (-width * 0.5, height * 0.5),
    ]


def _create_profile_prism_object(profile_points, total_depth: float, name: str):
    mesh = bpy.data.meshes.new(name + "Mesh")
    obj = bpy.data.objects.new(_unique_object_name(name), mesh)
    bpy.context.collection.objects.link(obj)

    bm = bmesh.new()
    y0 = -max(0.001, float(total_depth)) * 0.5
    y1 = max(0.001, float(total_depth)) * 0.5

    back = [bm.verts.new((x, y0, z)) for x, z in profile_points]
    front = [bm.verts.new((x, y1, z)) for x, z in profile_points]
    n = len(profile_points)


    try:
        bm.faces.new(back)
    except ValueError:
        pass
    try:
        bm.faces.new(tuple(reversed(front)))
    except ValueError:
        pass

    for i in range(n):
        j = (i + 1) % n
        try:
            bm.faces.new((back[i], back[j], front[j], front[i]))
        except ValueError:
            pass

    bm.normal_update()
    bm.to_mesh(mesh)
    bm.free()
    mesh.update()
    return obj


def _create_profile_cutout_object_from_axes(
    building,
    surface_w: Vector,
    n_w: Vector,
    right_w: Vector,
    up_w: Vector,
    width: float,
    height: float,
    depth: float,
    outward_margin: float,
    profile_type: str,
    segments: int,
    name: str,
):
    loc, total_depth = _cutout_location(surface_w, n_w, depth, outward_margin)
    pts = _make_profile_points(profile_type, width, height, segments)
    cutter = _create_profile_prism_object(pts, total_depth, name)
    _set_object_basis_world(cutter, right_w, n_w, up_w, loc)
    _prepare_cutout_object(cutter, building)
    return cutter


def _create_rect_cutout_object(
    building,
    face_index: int,
    u: float,
    v: float,
    width: float,
    height: float,
    depth: float,
    outward_margin: float,
    name: str,
):
    point_data, err = _opening_surface_point(building, face_index, u, v)
    if err:
        return None

    surface_w, n_w, right_w, up_w = point_data
    return _create_profile_cutout_object_from_axes(
        building=building,
        surface_w=surface_w,
        n_w=n_w,
        right_w=right_w,
        up_w=up_w,
        width=width,
        height=height,
        depth=depth,
        outward_margin=outward_margin,
        profile_type="RECT",
        segments=4,
        name=name,
    )


def _create_profile_cutout_object(
    building,
    face_index: int,
    u: float,
    v: float,
    scale: Vector,
    depth: float,
    outward_margin: float,
    profile_type: str,
    segments: int,
    name: str,
    width_extra: float = 0.0,
    height_extra: float = 0.0,
):
    point_data, err = _opening_surface_point(building, face_index, u, v)
    if err:
        return None

    surface_w, n_w, right_w, up_w = point_data
    return _create_profile_cutout_object_from_axes(
        building=building,
        surface_w=surface_w,
        n_w=n_w,
        right_w=right_w,
        up_w=up_w,
        width=float(scale.x) + float(width_extra) * 2.0,
        height=float(scale.z) + float(height_extra) * 2.0,
        depth=depth,
        outward_margin=outward_margin,
        profile_type=profile_type,
        segments=segments,
        name=name,
    )


def _apply_boolean_cut(building: bpy.types.Object, cutter: bpy.types.Object, base_name: str = "OpeningCut") -> str | None:
    if not building or not cutter:
        return None

    mod_name = _unique_modifier_name(building, base_name)
    mod = building.modifiers.new(mod_name, type="BOOLEAN")
    mod.operation = "DIFFERENCE"
    mod.object = cutter
    try:
        mod.solver = "EXACT"
    except Exception:
        pass
    mod.show_viewport = True
    mod.show_render = True

    previous_active = bpy.context.view_layer.objects.active
    try:
        for o in bpy.context.view_layer.objects:
            o.select_set(False)
        building.select_set(True)
        bpy.context.view_layer.objects.active = building
        if bpy.context.object and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.modifier_apply(modifier=mod.name)
    except Exception as ex:
        print(f"Boolean cut was not applied: {ex}")
        return mod.name
    finally:
        try:
            if previous_active and previous_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = previous_active
        except Exception:
            pass

    try:
        building.update_tag(refresh={"DATA"})
        bpy.context.view_layer.update()
    except Exception:
        pass
    return ""


def _apply_and_remove_cutters(building: bpy.types.Object, cutters: list[bpy.types.Object], modifier_name: str = "Opening_Cut"):
    modifiers = []
    for cutter in cutters:
        if not cutter:
            continue
        mod_name = _apply_boolean_cut(building, cutter, modifier_name)
        if mod_name:
            modifiers.append(mod_name)
        try:
            bpy.data.objects.remove(cutter, do_unlink=True)
        except Exception:
            pass
    return "|".join(modifiers)


def _area_2d(points):
    area = 0.0
    n = len(points)
    for i in range(n):
        x1, y1 = points[i]
        x2, y2 = points[(i + 1) % n]
        area += x1 * y2 - x2 * y1
    return area * 0.5


def _local_vec_from_world_direction(obj: bpy.types.Object, vec_w: Vector) -> Vector:
    v = obj.matrix_world.to_3x3().inverted() @ vec_w
    if v.length > 0.0:
        v.normalize()
    return v


def _world_to_local(obj: bpy.types.Object, point_w: Vector) -> Vector:
    return obj.matrix_world.inverted() @ point_w


def _make_face_point_local(obj, center_w, right_w, up_w, u: float, v: float) -> Vector:
    return _world_to_local(obj, center_w + right_w * float(u) + up_w * float(v))


def _safe_new_face(bm, verts, target_normal_l: Vector | None = None):
    verts = [v for v in verts if v is not None]
    if len(verts) < 3 or len(set(verts)) < 3:
        return None
    try:
        face = bm.faces.new(tuple(verts))
    except ValueError:
        return None
    try:
        face.normal_update()
        if target_normal_l is not None and face.normal.length > 0.0 and face.normal.dot(target_normal_l) < 0.0:
            face.normal_flip()
    except Exception:
        pass
    return face


def _clamped_opening_spec(u, v, width, height, min_u, max_u, min_v, max_v, profile_type, segments):
    margin = 1e-4
    u0 = max(min_u + margin, float(u) - float(width) * 0.5)
    u1 = min(max_u - margin, float(u) + float(width) * 0.5)
    v0 = max(min_v + margin, float(v) - float(height) * 0.5)
    v1 = min(max_v - margin, float(v) + float(height) * 0.5)

    if u1 <= u0 + margin or v1 <= v0 + margin:
        return None

    cu = (u0 + u1) * 0.5
    cv = (v0 + v1) * 0.5
    w = max(margin, u1 - u0)
    h = max(margin, v1 - v0)
    return {
        "u": cu,
        "v": cv,
        "width": w,
        "height": h,
        "profile_type": (profile_type or "RECT").upper(),
        "segments": int(segments or 16),
    }


def _prepare_opening_specs(building, face_index: int, raw_specs: list[dict]):
    data, err = _face_axes_bounds_world_by_index(building, face_index)
    if err:
        print(err)
        return None, err
    center_w, n_w, right_w, up_w, min_u, max_u, min_v, max_v = data

    specs = []
    for raw in raw_specs:
        spec = _clamped_opening_spec(
            raw.get("u", 0.0),
            raw.get("v", 0.0),
            raw.get("width", 0.1),
            raw.get("height", 0.1),
            min_u,
            max_u,
            min_v,
            max_v,
            raw.get("profile_type", "RECT"),
            raw.get("segments", 16),
        )
        if spec:
            specs.append(spec)

    if not specs:
        return None, "Проём не помещается в выбранную грань."
    return (center_w, n_w, right_w, up_w, min_u, max_u, min_v, max_v, specs), None


def _build_opening_loop_2d(spec: dict):
    pts = _make_profile_points(
        spec.get("profile_type", "RECT"),
        spec.get("width", 0.1),
        spec.get("height", 0.1),
        spec.get("segments", 16),
    )
    cu = float(spec.get("u", 0.0))
    cv = float(spec.get("v", 0.0))
    pts = [(cu + float(x), cv + float(y)) for x, y in pts]


    if _area_2d(pts) < 0.0:
        pts.reverse()
    return pts


def _is_rect_opening_spec(spec: dict) -> bool:
    return (spec.get("profile_type", "RECT") or "RECT").upper() == "RECT"


def _uniq_sorted_values(values, eps: float = 1e-5):
    out = []
    for value in sorted(float(v) for v in values):
        if not out or abs(value - out[-1]) > eps:
            out.append(value)
    return out


def _find_existing_vert_for_uv(outer_verts, outer_uv, target_u, target_v, eps: float = 1e-4):
    best = None
    best_d2 = None
    for vtx, (u, v) in zip(outer_verts, outer_uv):
        d2 = (float(u) - float(target_u)) ** 2 + (float(v) - float(target_v)) ** 2
        if best_d2 is None or d2 < best_d2:
            best = vtx
            best_d2 = d2
    if best is not None and best_d2 is not None and best_d2 <= eps * eps:
        return best
    return None


def _uv_inside_rect_spec(u: float, v: float, spec: dict, eps: float = 1e-6) -> bool:
    u0 = float(spec["u"]) - float(spec["width"]) * 0.5
    u1 = float(spec["u"]) + float(spec["width"]) * 0.5
    v0 = float(spec["v"]) - float(spec["height"]) * 0.5
    v1 = float(spec["v"]) + float(spec["height"]) * 0.5
    return (u0 + eps) < float(u) < (u1 - eps) and (v0 + eps) < float(v) < (v1 - eps)


def _grid_value_index(values, value, eps: float = 1e-5):
    for i, v in enumerate(values):
        if abs(float(v) - float(value)) <= eps:
            return i
    return None


def _apply_rect_recesses_to_face_clean(
    building: bpy.types.Object,
    face_index: int,
    raw_specs: list[dict],
    cut_depth: float,
):
    prepared, err = _prepare_opening_specs(building, face_index, raw_specs)
    if err:
        return False, err

    center_w, n_w, right_w, up_w, min_u, max_u, min_v, max_v, specs = prepared
    if not specs or not all(_is_rect_opening_spec(spec) for spec in specs):
        return False, "Clean quad topology is available only for rectangular openings."

    depth = max(0.001, float(cut_depth))
    margin = 1e-5

    rect_specs = []
    u_values = []
    v_values = []
    for spec in specs:
        u0 = max(float(min_u) + margin, float(spec["u"]) - float(spec["width"]) * 0.5)
        u1 = min(float(max_u) - margin, float(spec["u"]) + float(spec["width"]) * 0.5)
        v0 = max(float(min_v) + margin, float(spec["v"]) - float(spec["height"]) * 0.5)
        v1 = min(float(max_v) - margin, float(spec["v"]) + float(spec["height"]) * 0.5)
        if u1 <= u0 + margin or v1 <= v0 + margin:
            continue
        rect_specs.append({"u0": u0, "u1": u1, "v0": v0, "v1": v1})
        u_values.extend([u0, u1])
        v_values.extend([v0, v1])

    if not rect_specs:
        return False, "Проём не помещается в выбранную грань."

    for i, a in enumerate(rect_specs):
        for b in rect_specs[i + 1:]:
            overlap_u = min(a["u1"], b["u1"]) - max(a["u0"], b["u0"])
            overlap_v = min(a["v1"], b["v1"]) - max(a["v0"], b["v0"])
            if overlap_u > 1e-5 and overlap_v > 1e-5:
                return False, "Проёмы пересекаются. Увеличьте spacing или уменьшите размер окна/двери."

    me = building.data
    bm = bmesh.new()
    bm.from_mesh(me)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    if face_index < 0 or face_index >= len(bm.faces):
        bm.free()
        return False, "Неверный индекс грани."


    target_normal_l = _local_vec_from_world_direction(building, n_w)
    right_l = _local_vec_from_world_direction(building, right_w)
    up_l = _local_vec_from_world_direction(building, up_w)
    plane_co_l = _world_to_local(building, center_w)

    if target_normal_l.length <= 0.0 or right_l.length <= 0.0 or up_l.length <= 0.0:
        bm.free()
        return False, "Не удалось построить локальные оси проёма."

    def to_local_point(u: float, v: float, inward: float = 0.0) -> Vector:
        return _world_to_local(
            building,
            center_w + right_w * float(u) + up_w * float(v) - n_w * float(inward),
        )

    def uv_from_local(co: Vector):
        p_w = building.matrix_world @ co
        rel = p_w - center_w
        return right_w.dot(rel), up_w.dot(rel), n_w.dot(rel)

    def facade_geom():


        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        geom = []
        seen = set()
        for f in list(bm.faces):
            try:
                if f.normal.dot(target_normal_l) < 0.75:
                    continue
                cu, cv, dn = uv_from_local(f.calc_center_median())
                if abs(dn) > 2e-4:
                    continue
                if not (float(min_u) - 2e-4 <= cu <= float(max_u) + 2e-4):
                    continue
                if not (float(min_v) - 2e-4 <= cv <= float(max_v) + 2e-4):
                    continue
            except Exception:
                continue

            for item in list(f.verts) + list(f.edges) + [f]:
                key = id(item)
                if key not in seen:
                    seen.add(key)
                    geom.append(item)
        return geom

    def bisect_at(point_l: Vector, normal_l: Vector):
        geom = facade_geom()
        if not geom:
            raise RuntimeError("Не найдена фасадная область для локального разреза.")
        try:
            bmesh.ops.bisect_plane(
                bm,
                geom=geom,
                dist=1e-5,
                plane_co=point_l,
                plane_no=normal_l,
                clear_outer=False,
                clear_inner=False,
            )
        except Exception as ex:
            raise RuntimeError(str(ex))


    try:
        for u in _uniq_sorted_values(u_values):
            bisect_at(to_local_point(u, 0.0, 0.0), right_l)
        for v in _uniq_sorted_values(v_values):
            bisect_at(to_local_point(0.0, v, 0.0), up_l)
    except RuntimeError as ex:
        bm.free()
        return False, f"Не удалось разрезать фасадную сетку: {ex}"

    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()


    cut_faces = []
    facade_tol = 2e-4
    for f in list(bm.faces):
        try:
            if f.normal.dot(target_normal_l) < 0.75:
                continue
            cu, cv, dn = uv_from_local(f.calc_center_median())
            if abs(dn) > facade_tol:
                continue
            if not (float(min_u) - facade_tol <= cu <= float(max_u) + facade_tol):
                continue
            if not (float(min_v) - facade_tol <= cv <= float(max_v) + facade_tol):
                continue
            for r in rect_specs:
                if (r["u0"] + 1e-5) < cu < (r["u1"] - 1e-5) and (r["v0"] + 1e-5) < cv < (r["v1"] - 1e-5):
                    cut_faces.append(f)
                    break
        except Exception:
            continue

    if not cut_faces:
        bm.free()
        return False, "Не удалось найти фасадные ячейки для проёма после разреза."

    bmesh.ops.delete(bm, geom=cut_faces, context="FACES_ONLY")

    def find_front_vert(u: float, v: float):
        best = None
        best_score = None
        for vtx in bm.verts:
            try:
                vu, vv, dn = uv_from_local(vtx.co)
            except Exception:
                continue
            d2 = (vu - float(u)) ** 2 + (vv - float(v)) ** 2 + (dn * 2.0) ** 2


            if abs(dn) > 5e-4:
                continue
            if best_score is None or d2 < best_score:
                best = vtx
                best_score = d2
        if best is not None and best_score is not None and best_score <= 1e-6:
            return best
        return bm.verts.new(to_local_point(u, v, 0.0))


    for r in rect_specs:
        f_bl = find_front_vert(r["u0"], r["v0"])
        f_br = find_front_vert(r["u1"], r["v0"])
        f_tr = find_front_vert(r["u1"], r["v1"])
        f_tl = find_front_vert(r["u0"], r["v1"])

        b_bl = bm.verts.new(to_local_point(r["u0"], r["v0"], depth))
        b_br = bm.verts.new(to_local_point(r["u1"], r["v0"], depth))
        b_tr = bm.verts.new(to_local_point(r["u1"], r["v1"], depth))
        b_tl = bm.verts.new(to_local_point(r["u0"], r["v1"], depth))

        _safe_new_face(bm, [f_bl, f_tl, b_tl, b_bl], None)
        _safe_new_face(bm, [f_br, b_br, b_tr, f_tr], None)
        _safe_new_face(bm, [f_bl, b_bl, b_br, f_br], None)
        _safe_new_face(bm, [f_tl, f_tr, b_tr, b_tl], None)
        _safe_new_face(bm, [b_bl, b_br, b_tr, b_tl], target_normal_l)

    try:
        loose_faces = [f for f in bm.faces if len(f.verts) < 3]
        if loose_faces:
            bmesh.ops.delete(bm, geom=loose_faces, context="FACES")
    except Exception:
        pass

    try:
        bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=1e-6)
    except Exception:
        pass

    bm.verts.index_update()
    bm.edges.index_update()
    bm.faces.index_update()
    bm.normal_update()
    bm.to_mesh(me)
    bm.free()
    me.update()

    try:
        building.update_tag(refresh={"DATA"})
        bpy.context.view_layer.update()
    except Exception:
        pass
    return True, None


def _is_local_profile_opening_spec(spec: dict) -> bool:
    return (spec.get("profile_type", "RECT") or "RECT").upper() in {"ARCH", "ROUND"}


def _apply_profile_recesses_to_face_local_frame(
    building: bpy.types.Object,
    face_index: int,
    raw_specs: list[dict],
    cut_depth: float,
):
    prepared, err = _prepare_opening_specs(building, face_index, raw_specs)
    if err:
        return False, err

    center_w, n_w, right_w, up_w, min_u, max_u, min_v, max_v, specs = prepared
    if not specs or not all(_is_local_profile_opening_spec(spec) for spec in specs):
        return False, "Local profile topology is available only for ARCH/ROUND openings."

    depth = max(0.001, float(cut_depth))
    margin = 1e-5

    frames = []
    u_values = []
    v_values = []

    for spec in specs:
        width = float(spec["width"])
        height = float(spec["height"])
        cu = float(spec["u"])
        cv = float(spec["v"])
        pu0 = max(float(min_u) + margin, cu - width * 0.5)
        pu1 = min(float(max_u) - margin, cu + width * 0.5)
        pv0 = max(float(min_v) + margin, cv - height * 0.5)
        pv1 = min(float(max_v) - margin, cv + height * 0.5)
        if pu1 <= pu0 + margin or pv1 <= pv0 + margin:
            continue


        base_pad = max(min(width, height) * 0.06, 0.025)
        pad_u = min(base_pad, max(0.0, pu0 - float(min_u) - margin), max(0.0, float(max_u) - pu1 - margin))
        pad_v = min(base_pad, max(0.0, pv0 - float(min_v) - margin), max(0.0, float(max_v) - pv1 - margin))


        pad_u = max(pad_u, min(0.005, max(0.0, pu0 - float(min_u) - margin), max(0.0, float(max_u) - pu1 - margin)))
        pad_v = max(pad_v, min(0.005, max(0.0, pv0 - float(min_v) - margin), max(0.0, float(max_v) - pv1 - margin)))

        fu0 = max(float(min_u) + margin, pu0 - pad_u)
        fu1 = min(float(max_u) - margin, pu1 + pad_u)
        fv0 = max(float(min_v) + margin, pv0 - pad_v)
        fv1 = min(float(max_v) - margin, pv1 + pad_v)

        if fu1 <= fu0 + margin or fv1 <= fv0 + margin:
            continue

        loop_uv = _build_opening_loop_2d(spec)


        sep = 1e-4
        inside = all((fu0 + sep) < u < (fu1 - sep) and (fv0 + sep) < v < (fv1 - sep) for u, v in loop_uv)
        if not inside:

            fu0 = max(float(min_u) + margin, min(u for u, _ in loop_uv) - 0.01)
            fu1 = min(float(max_u) - margin, max(u for u, _ in loop_uv) + 0.01)
            fv0 = max(float(min_v) + margin, min(v for _, v in loop_uv) - 0.01)
            fv1 = min(float(max_v) - margin, max(v for _, v in loop_uv) + 0.01)
            inside = all((fu0 + sep) < u < (fu1 - sep) and (fv0 + sep) < v < (fv1 - sep) for u, v in loop_uv)
            if not inside:
                return False, "Недостаточно места вокруг арочного/круглого окна для чистой локальной рамки."

        frame = {
            "u0": fu0,
            "u1": fu1,
            "v0": fv0,
            "v1": fv1,
            "profile_loop_uv": loop_uv,
        }
        frames.append(frame)
        u_values.extend([fu0, fu1])
        v_values.extend([fv0, fv1])

    if not frames:
        return False, "Проём не помещается в выбранную грань."

    for i, a in enumerate(frames):
        for b in frames[i + 1:]:
            overlap_u = min(a["u1"], b["u1"]) - max(a["u0"], b["u0"])
            overlap_v = min(a["v1"], b["v1"]) - max(a["v0"], b["v0"])
            if overlap_u > 1e-5 and overlap_v > 1e-5:
                return False, "Локальные рамки окон пересекаются. Увеличьте spacing или уменьшите размер окна."

    me = building.data
    bm = bmesh.new()
    bm.from_mesh(me)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    if face_index < 0 or face_index >= len(bm.faces):
        bm.free()
        return False, "Неверный индекс грани."

    target_normal_l = _local_vec_from_world_direction(building, n_w)
    right_l = _local_vec_from_world_direction(building, right_w)
    up_l = _local_vec_from_world_direction(building, up_w)

    if target_normal_l.length <= 0.0 or right_l.length <= 0.0 or up_l.length <= 0.0:
        bm.free()
        return False, "Не удалось построить локальные оси проёма."

    def to_local_point(u: float, v: float, inward: float = 0.0) -> Vector:
        return _world_to_local(
            building,
            center_w + right_w * float(u) + up_w * float(v) - n_w * float(inward),
        )

    def uv_from_local(co: Vector):
        p_w = building.matrix_world @ co
        rel = p_w - center_w
        return right_w.dot(rel), up_w.dot(rel), n_w.dot(rel)

    def facade_geom():
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        geom = []
        seen = set()
        for f in list(bm.faces):
            try:
                if f.normal.dot(target_normal_l) < 0.75:
                    continue
                cu, cv, dn = uv_from_local(f.calc_center_median())
                if abs(dn) > 2e-4:
                    continue
                if not (float(min_u) - 2e-4 <= cu <= float(max_u) + 2e-4):
                    continue
                if not (float(min_v) - 2e-4 <= cv <= float(max_v) + 2e-4):
                    continue
            except Exception:
                continue
            for item in list(f.verts) + list(f.edges) + [f]:
                key = id(item)
                if key not in seen:
                    seen.add(key)
                    geom.append(item)
        return geom

    def bisect_at(point_l: Vector, normal_l: Vector):
        geom = facade_geom()
        if not geom:
            raise RuntimeError("Не найдена фасадная область для локального разреза.")
        bmesh.ops.bisect_plane(
            bm,
            geom=geom,
            dist=1e-5,
            plane_co=point_l,
            plane_no=normal_l,
            clear_outer=False,
            clear_inner=False,
        )

    try:
        for u in _uniq_sorted_values(u_values):
            bisect_at(to_local_point(u, 0.0, 0.0), right_l)
        for v in _uniq_sorted_values(v_values):
            bisect_at(to_local_point(0.0, v, 0.0), up_l)
    except Exception as ex:
        bm.free()
        return False, f"Не удалось разрезать фасадную сетку вокруг окна: {ex}"

    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    cut_faces = []
    facade_tol = 2e-4
    for f in list(bm.faces):
        try:
            if f.normal.dot(target_normal_l) < 0.75:
                continue
            cu, cv, dn = uv_from_local(f.calc_center_median())
            if abs(dn) > facade_tol:
                continue
            for frame in frames:
                if (frame["u0"] + 1e-5) < cu < (frame["u1"] - 1e-5) and (frame["v0"] + 1e-5) < cv < (frame["v1"] - 1e-5):
                    cut_faces.append(f)
                    break
        except Exception:
            continue

    if not cut_faces:
        bm.free()
        return False, "Не удалось найти локальные фасадные ячейки для арочного/круглого окна."

    bmesh.ops.delete(bm, geom=cut_faces, context="FACES_ONLY")

    def find_front_vert(u: float, v: float):
        best = None
        best_score = None
        for vtx in bm.verts:
            try:
                vu, vv, dn = uv_from_local(vtx.co)
            except Exception:
                continue
            if abs(dn) > 5e-4:
                continue
            d2 = (vu - float(u)) ** 2 + (vv - float(v)) ** 2 + (dn * 2.0) ** 2
            if best_score is None or d2 < best_score:
                best = vtx
                best_score = d2
        if best is not None and best_score is not None and best_score <= 1e-6:
            return best
        return bm.verts.new(to_local_point(u, v, 0.0))

    for frame in frames:
        f_bl = find_front_vert(frame["u0"], frame["v0"])
        f_br = find_front_vert(frame["u1"], frame["v0"])
        f_tr = find_front_vert(frame["u1"], frame["v1"])
        f_tl = find_front_vert(frame["u0"], frame["v1"])
        outer = [f_bl, f_br, f_tr, f_tl]

        profile_uv = frame["profile_loop_uv"]
        front = [bm.verts.new(to_local_point(u, v, 0.0)) for u, v in profile_uv]
        back = [bm.verts.new(to_local_point(u, v, depth)) for u, v in profile_uv]


        loops_coords = [[v.co.copy() for v in outer], [v.co.copy() for v in reversed(front)]]
        loops_verts = [outer, list(reversed(front))]
        flat = []
        for loop in loops_verts:
            flat.extend(loop)
        try:
            triangles = tessellate_polygon(loops_coords)
        except Exception as ex:
            bm.free()
            return False, f"Не удалось построить локальную рамку арочного/круглого окна: {ex}"
        for tri in triangles:
            _safe_new_face(bm, [flat[i] for i in tri], target_normal_l)

        n = len(front)
        for i in range(n):
            j = (i + 1) % n
            _safe_new_face(bm, [front[i], front[j], back[j], back[i]], None)

        back_coords = [[v.co.copy() for v in back]]
        try:
            back_tris = tessellate_polygon(back_coords)
            for tri in back_tris:
                _safe_new_face(bm, [back[i] for i in tri], target_normal_l)
        except Exception:
            _safe_new_face(bm, list(reversed(back)), target_normal_l)

    try:
        bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=1e-6)
    except Exception:
        pass

    bm.verts.index_update()
    bm.edges.index_update()
    bm.faces.index_update()
    bm.normal_update()
    bm.to_mesh(me)
    bm.free()
    me.update()

    try:
        building.update_tag(refresh={"DATA"})
        bpy.context.view_layer.update()
    except Exception:
        pass
    return True, None

def _apply_profile_recesses_to_face(
    building: bpy.types.Object,
    face_index: int,
    raw_specs: list[dict],
    cut_depth: float,
):


    if raw_specs and all(_is_rect_opening_spec(spec) for spec in raw_specs):
        ok, clean_err = _apply_rect_recesses_to_face_clean(building, face_index, raw_specs, cut_depth)
        if ok:
            return True, None


        if clean_err:
            print(clean_err)


    if raw_specs and all(_is_local_profile_opening_spec(spec) for spec in raw_specs):
        ok, local_err = _apply_profile_recesses_to_face_local_frame(building, face_index, raw_specs, cut_depth)
        if ok:
            return True, None
        if local_err:
            print(local_err)

    prepared, err = _prepare_opening_specs(building, face_index, raw_specs)
    if err:
        return False, err

    center_w, n_w, right_w, up_w, _min_u, _max_u, _min_v, _max_v, specs = prepared
    depth = max(0.001, float(cut_depth))

    me = building.data
    bm = bmesh.new()
    bm.from_mesh(me)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    if face_index < 0 or face_index >= len(bm.faces):
        bm.free()
        return False, "Неверный индекс грани."

    face = bm.faces[face_index]
    target_normal_l = _local_vec_from_world_direction(building, n_w)


    outer_verts = list(face.verts)
    outer_uv = []
    for vtx in outer_verts:
        p_w = building.matrix_world @ vtx.co
        rel = p_w - center_w
        outer_uv.append((right_w.dot(rel), up_w.dot(rel)))

    if _area_2d(outer_uv) < 0.0:
        outer_uv.reverse()
        outer_verts.reverse()

    loops_coords = [[v.co.copy() for v in outer_verts]]
    loops_verts = [outer_verts]
    hole_front_loops = []
    hole_back_loops = []

    for spec in specs:
        loop_uv_ccw = _build_opening_loop_2d(spec)

        front = [
            bm.verts.new(_make_face_point_local(building, center_w, right_w, up_w, u, v))
            for u, v in loop_uv_ccw
        ]

        back = [
            bm.verts.new(_world_to_local(building, center_w + right_w * u + up_w * v - n_w * depth))
            for u, v in loop_uv_ccw
        ]
        hole_front_loops.append(front)
        hole_back_loops.append(back)


        loops_coords.append([vtx.co.copy() for vtx in reversed(front)])
        loops_verts.append(list(reversed(front)))


    bmesh.ops.delete(bm, geom=[face], context="FACES_ONLY")

    flat_verts = []
    for loop in loops_verts:
        flat_verts.extend(loop)

    try:
        triangles = tessellate_polygon(loops_coords)
    except Exception as ex:
        bm.free()
        return False, f"Не удалось построить топологию проёма: {ex}"

    for tri in triangles:
        _safe_new_face(bm, [flat_verts[i] for i in tri], target_normal_l)

    inward_l = _local_vec_from_world_direction(building, -n_w)


    for front, back in zip(hole_front_loops, hole_back_loops):
        n = len(front)
        if n < 3:
            continue

        for i in range(n):
            j = (i + 1) % n

            _safe_new_face(bm, [front[i], front[j], back[j], back[i]], None)

        back_coords = [[v.co.copy() for v in back]]
        try:
            back_tris = tessellate_polygon(back_coords)
            for tri in back_tris:

                _safe_new_face(bm, [back[i] for i in tri], target_normal_l)
        except Exception:

            _safe_new_face(bm, list(reversed(back)), target_normal_l)

    try:
        bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    except Exception:
        pass

    bm.verts.index_update()
    bm.edges.index_update()
    bm.faces.index_update()
    bm.normal_update()
    bm.to_mesh(me)
    bm.free()
    me.update()

    try:
        building.update_tag(refresh={"DATA"})
        bpy.context.view_layer.update()
    except Exception:
        pass
    return True, None


def _add_opening_recesses(
    building,
    face_index: int,
    openings: list[dict],
    cut_depth: float,
):
    ok, err = _apply_profile_recesses_to_face(building, face_index, openings, cut_depth)


    if not ok:
        return "", "", (err or "Не удалось создать проём.")
    return "", "", None


def _add_opening_cutout_rect(
    building,
    face_index: int,
    u: float,
    v: float,
    width: float,
    height: float,
    cut_depth: float,
    outward_margin: float,
    cutter_name: str = "Opening_Cutout",
    modifier_name: str = "Opening_Cut",
    width_extra: float = 0.0,
    height_extra: float = 0.0,
):
    return _add_opening_recesses(
        building=building,
        face_index=face_index,
        openings=[{
            "u": float(u),
            "v": float(v),
            "width": float(width) + float(width_extra) * 2.0,
            "height": float(height) + float(height_extra) * 2.0,
            "profile_type": "RECT",
            "segments": 4,
        }],
        cut_depth=cut_depth,
    )


def _add_opening_cutout_profile(
    building,
    face_index: int,
    u: float,
    v: float,
    scale: Vector,
    cut_depth: float,
    outward_margin: float,
    profile_type: str,
    segments: int,
    cutter_name: str = "Opening_Cutout",
    modifier_name: str = "Opening_Cut",
    width_extra: float = 0.0,
    height_extra: float = 0.0,
):
    return _add_opening_recesses(
        building=building,
        face_index=face_index,
        openings=[{
            "u": float(u),
            "v": float(v),
            "width": float(scale.x) + float(width_extra) * 2.0,
            "height": float(scale.z) + float(height_extra) * 2.0,
            "profile_type": profile_type,
            "segments": segments,
        }],
        cut_depth=cut_depth,
    )


def _spawn_door(building, face_index, offset_x, offset_z, gap, scale: Vector, parent_to_building=True):
    data, err = _face_axes_bounds_world_by_index(building, face_index)
    if err:
        print(err)
        return None

    center_w, n_w, right_w, up_w, min_u, max_u, min_v, _ = data
    thickness = float(scale.y)
    height = float(scale.z)

    bpy.ops.mesh.primitive_cube_add(size=1.0)
    door = bpy.context.active_object
    door.name = "Door"

    u = (min_u + max_u) * 0.5 + offset_x
    v = min_v + (height * 0.5) + offset_z
    loc = center_w + right_w * u + up_w * v + n_w * (thickness * 0.5 + gap)

    _set_object_basis_world(door, right_w, n_w, up_w, loc)
    door.scale = scale

    if parent_to_building:
        _parent_keep_world(door, building)
    return door


def _door_uv(building, face_index, offset_x: float, offset_z: float, scale: Vector):
    data, err = _face_axes_bounds_world_by_index(building, face_index)
    if err:
        return None, err
    _, _, _, _, min_u, max_u, min_v, _ = data
    u = (min_u + max_u) * 0.5 + float(offset_x)
    v = min_v + float(scale.z) * 0.5 + float(offset_z)
    return (u, v), None


def _spawn_window_at_u_v(building, face_index, u, v, gap, scale: Vector, parent_to_building=True):
    data, err = _face_axes_bounds_world_by_index(building, face_index)
    if err:
        print(err)
        return None

    center_w, n_w, right_w, up_w, *_ = data
    thickness = float(scale.y)

    bpy.ops.mesh.primitive_cube_add(size=1.0)
    win = bpy.context.active_object
    win.name = "Window"

    loc = center_w + right_w * u + up_w * v + n_w * (thickness * 0.5 + gap)

    _set_object_basis_world(win, right_w, n_w, up_w, loc)
    win.scale = scale

    if parent_to_building:
        _parent_keep_world(win, building)
    return win


def _create_arched_window_unit_object(arc_segments: int = 16):
    arc_segments = max(4, int(arc_segments))

    w = 1.0
    h = 1.0
    t = 1.0

    r = 0.5
    side_h = h - r

    x0, x1 = -w * 0.5, w * 0.5
    z_bottom = -h * 0.5
    z_arc_center = z_bottom + side_h

    pts = [
        (x0, z_bottom),
        (x1, z_bottom),
        (x1, z_arc_center),
    ]

    for i in range(1, arc_segments):
        a = (i / arc_segments) * pi
        x = cos(a) * r
        z = sin(a) * r + z_arc_center
        pts.append((x, z))

    pts.append((x0, z_arc_center))

    mesh = bpy.data.meshes.new("ArchedWindowMesh")
    obj = bpy.data.objects.new("WindowArch", mesh)
    bpy.context.collection.objects.link(obj)

    bm = bmesh.new()

    y0 = -t * 0.5
    verts = [bm.verts.new((x, y0, -z)) for (x, z) in pts]
    face = bm.faces.new(verts)

    res = bmesh.ops.extrude_face_region(bm, geom=[face])
    extruded_verts = [e for e in res["geom"] if isinstance(e, bmesh.types.BMVert)]
    bmesh.ops.translate(bm, verts=extruded_verts, vec=Vector((0.0, t, 0.0)))

    bm.normal_update()
    bm.to_mesh(mesh)
    bm.free()
    mesh.update()
    return obj


def _spawn_window_arch_at_u_v(
    building,
    face_index: int,
    u: float,
    v: float,
    gap: float,
    scale: Vector,
    arc_segments: int = 16,
    parent_to_building: bool = True,
):
    data, err = _face_axes_bounds_world_by_index(building, face_index)
    if err:
        print(err)
        return None

    center_w, n_w, right_w, up_w, *_ = data

    thickness = float(scale.y)
    g = max(0.0, float(gap))
    loc = center_w + right_w * float(u) + up_w * float(v) + n_w * (g + thickness * 0.5)

    win = _create_arched_window_unit_object(arc_segments=arc_segments)
    win.name = "Window"
    _set_object_basis_world(win, right_w, n_w, up_w, loc)
    win.scale = Vector((float(scale.x), float(scale.y), float(scale.z)))

    if parent_to_building:
        _parent_keep_world(win, building)
    return win


def _create_round_window_unit_object(segments: int = 32):
    segments = max(8, int(segments))


    r = 0.5
    t = 1.0

    mesh = bpy.data.meshes.new("RoundWindowMesh")
    obj = bpy.data.objects.new("WindowRound", mesh)
    bpy.context.collection.objects.link(obj)

    bm = bmesh.new()


    mat = Matrix.Rotation(pi * 0.5, 4, "X")
    res = bmesh.ops.create_circle(bm, segments=segments, radius=r, matrix=mat)
    verts = res["verts"]

    for v in verts:
        v.co.y = -t * 0.5

    face = None
    try:
        face = bm.faces.new(verts)
    except ValueError:
        face = bm.faces[0] if bm.faces else None

    if face:
        ext = bmesh.ops.extrude_face_region(bm, geom=[face])
        ext_verts = [e for e in ext["geom"] if isinstance(e, bmesh.types.BMVert)]
        bmesh.ops.translate(bm, verts=ext_verts, vec=Vector((0.0, t, 0.0)))

    bm.normal_update()
    bm.to_mesh(mesh)
    bm.free()
    mesh.update()
    return obj


def _spawn_window_round_at_u_v(
    building,
    face_index: int,
    u: float,
    v: float,
    gap: float,
    scale: Vector,
    round_segments: int = 32,
    parent_to_building: bool = True,
):
    data, err = _face_axes_bounds_world_by_index(building, face_index)
    if err:
        print(err)
        return None

    center_w, n_w, right_w, up_w, *_ = data

    thickness = float(scale.y)
    g = max(0.0, float(gap))
    loc = center_w + right_w * float(u) + up_w * float(v) + n_w * (g + thickness * 0.5)

    win = _create_round_window_unit_object(segments=round_segments)
    win.name = "Window"
    _set_object_basis_world(win, right_w, n_w, up_w, loc)
    win.scale = Vector((float(scale.x), float(scale.y), float(scale.z)))

    if parent_to_building:
        _parent_keep_world(win, building)
    return win
