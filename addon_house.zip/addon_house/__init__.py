bl_info = {
    "name": "House",
    "author": "Ponomarev Evgeniy",
    "version": (5, 0, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Building Tools",
    "description": "Building generator with floors/doors/windows/roofs/stairs/balcony/columns/platforms",
    "category": "Object",
}

import bpy
import importlib

from . import constants as _constants
from . import utils as _utils
from . import callbacks as _callbacks
from . import building as _building
from . import openings as _openings
from . import roof as _roof
from . import stairs as _stairs
from . import balcony as _balcony
from . import platform as _platform
from . import columns as _columns
from . import operators as _operators
from . import ui as _ui


_constants = importlib.reload(_constants)
_utils = importlib.reload(_utils)
_callbacks = importlib.reload(_callbacks)
_building = importlib.reload(_building)
_openings = importlib.reload(_openings)
_roof = importlib.reload(_roof)
_stairs = importlib.reload(_stairs)
_balcony = importlib.reload(_balcony)
_platform = importlib.reload(_platform)
_columns = importlib.reload(_columns)
_operators = importlib.reload(_operators)
_ui = importlib.reload(_ui)

OBJECT_OT_create_building = _operators.OBJECT_OT_create_building
OBJECT_OT_add_floor = _operators.OBJECT_OT_add_floor
OBJECT_OT_add_door = _operators.OBJECT_OT_add_door
OBJECT_OT_add_window = _operators.OBJECT_OT_add_window
OBJECT_OT_add_stairs = _operators.OBJECT_OT_add_stairs
OBJECT_OT_add_balcony = _operators.OBJECT_OT_add_balcony
OBJECT_OT_add_roof = _operators.OBJECT_OT_add_roof
OBJECT_OT_add_platform = _operators.OBJECT_OT_add_platform
OBJECT_OT_add_column = _operators.OBJECT_OT_add_column
VIEW3D_PT_building_menu = _ui.VIEW3D_PT_building_menu
_cleanup_house_redo_backups = _utils._cleanup_house_redo_backups

classes = (
    OBJECT_OT_create_building,
    OBJECT_OT_add_floor,
    OBJECT_OT_add_door,
    OBJECT_OT_add_window,
    OBJECT_OT_add_stairs,
    OBJECT_OT_add_balcony,
    OBJECT_OT_add_roof,
    OBJECT_OT_add_platform,
    OBJECT_OT_add_column,
    VIEW3D_PT_building_menu,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    _cleanup_house_redo_backups()


if __name__ == "__main__":
    register()
