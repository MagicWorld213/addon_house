import bpy


class VIEW3D_PT_building_menu(bpy.types.Panel):
    bl_label = "Building Tools"
    bl_idname = "VIEW3D_PT_building_menu"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Building Tools"

    def draw(self, context):
        layout = self.layout

        col = layout.column(align=True)
        col.label(text="Building")
        col.operator("object.create_building", icon="MESH_CUBE")
        col.operator("object.add_floor", icon="ADD")
        col.operator("object.add_platform", icon="MESH_CUBE")

        layout.separator()

        col = layout.column(align=True)
        col.label(text="On selected face (Edit Mode)")
        col.operator("object.add_door", icon="MESH_CUBE")
        col.operator("object.add_window", icon="MESH_CUBE")
        col.operator("object.add_stairs", icon="MOD_ARRAY")
        col.operator("object.add_balcony", icon="MOD_ARRAY")
        col.operator("object.add_roof", icon="MOD_SOLIDIFY")
        col.operator("object.add_column", icon="MESH_CYLINDER")

        layout.separator()
