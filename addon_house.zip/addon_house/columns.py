import bpy
import math
from mathutils import Vector

from .constants import EPS
from .utils import (
    _face_axes_bounds_world_by_index,
    _parent_keep_world,
)


def _unique_name(base: str) -> str:
    if base not in bpy.data.objects:
        return base
    i = 1
    while f"{base}.{i:03d}" in bpy.data.objects:
        i += 1
    return f"{base}.{i:03d}"


def _world_mesh_bounds(obj):
    if not obj or obj.type != "MESH" or not obj.data.vertices:
        return None
    mw = obj.matrix_world
    pts = [mw @ v.co for v in obj.data.vertices]
    return (
        min(p.x for p in pts), max(p.x for p in pts),
        min(p.y for p in pts), max(p.y for p in pts),
        min(p.z for p in pts), max(p.z for p in pts),
    )


def _make_cylinder_mesh_object(name, center, radius, height, segments, z0, z1):
    radius = max(0.01, float(radius))
    segments = max(6, min(128, int(segments)))
    mesh = bpy.data.meshes.new(name + "Mesh")
    verts = []
    for z in (z0, z1):
        for i in range(segments):
            a = (math.tau * i) / segments
            verts.append((center.x + math.cos(a) * radius, center.y + math.sin(a) * radius, z))
    bottom_center = len(verts)
    verts.append((center.x, center.y, z0))
    top_center = len(verts)
    verts.append((center.x, center.y, z1))

    faces = []
    for i in range(segments):
        j = (i + 1) % segments
        faces.append((i, j, segments + j, segments + i))
        faces.append((bottom_center, j, i))
        faces.append((top_center, segments + i, segments + j))
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(_unique_name(name), mesh)
    bpy.context.collection.objects.link(obj)
    return obj


def _append_box(verts, faces, x0, x1, y0, y1, z0, z1):
    base = len(verts)
    verts.extend([
        (x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0),
        (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1),
    ])
    faces.extend([
        (base + 3, base + 2, base + 1, base + 0),
        (base + 4, base + 5, base + 6, base + 7),
        (base + 0, base + 1, base + 5, base + 4),
        (base + 1, base + 2, base + 6, base + 5),
        (base + 2, base + 3, base + 7, base + 6),
        (base + 3, base + 0, base + 4, base + 7),
    ])


def _append_revolved_sections(verts, faces, center, sections, segments, cap_bottom=True, cap_top=True):
    ring_starts = []
    for z, radius, fluted, flute_count, flute_depth in sections:
        start = len(verts)
        ring_starts.append(start)
        base_radius = max(0.001, float(radius))
        for i in range(segments):
            a = (math.tau * i) / segments
            r = base_radius
            if fluted and flute_count > 0 and flute_depth > 1e-6:
                groove = max(0.0, math.cos(flute_count * a))
                groove = groove * groove
                r -= flute_depth * groove
                r = max(base_radius * 0.55, r)
            verts.append((center.x + math.cos(a) * r, center.y + math.sin(a) * r, z))

    for ring_index in range(len(ring_starts) - 1):
        a0 = ring_starts[ring_index]
        b0 = ring_starts[ring_index + 1]
        for i in range(segments):
            j = (i + 1) % segments
            faces.append((a0 + i, a0 + j, b0 + j, b0 + i))

    if ring_starts and cap_bottom:
        first = ring_starts[0]
        z = sections[0][0]
        c = len(verts)
        verts.append((center.x, center.y, z))
        for i in range(segments):
            j = (i + 1) % segments
            faces.append((c, first + j, first + i))

    if ring_starts and cap_top:
        last = ring_starts[-1]
        z = sections[-1][0]
        c = len(verts)
        verts.append((center.x, center.y, z))
        for i in range(segments):
            j = (i + 1) % segments
            faces.append((c, last + i, last + j))


def _make_classic_column_mesh_object(name, center, radius, height, segments, z0, z1):
    radius = max(0.01, float(radius))
    segments = max(18, min(128, int(segments)))
    h = max(0.01, float(z1 - z0))

    base_plinth_h = h * 0.045
    base_mould_h = h * 0.085
    shaft_start = z0 + base_plinth_h + base_mould_h
    capital_h = h * 0.14
    shaft_end = z1 - capital_h
    shaft_h = max(h * 0.35, shaft_end - shaft_start)
    shaft_end = shaft_start + shaft_h
    capital_h = max(h * 0.08, z1 - shaft_end)

    base_r = radius * 1.10
    shaft_bottom_r = radius * 0.92
    shaft_top_r = radius * 0.78
    neck_r = radius * 0.84
    echinus_r = radius * 1.02
    abacus_r = radius * 1.22

    flute_count = max(8, min(16, segments // 2))
    flute_depth = radius * 0.12

    sections = [
        (z0 + base_plinth_h, base_r * 1.10, False, 0, 0.0),
        (z0 + base_plinth_h + h * 0.015, base_r, False, 0, 0.0),
        (z0 + base_plinth_h + h * 0.035, base_r * 0.96, False, 0, 0.0),
        (shaft_start, shaft_bottom_r, False, 0, 0.0),
        (shaft_start + shaft_h * 0.08, shaft_bottom_r * 0.99, True, flute_count, flute_depth),
        (shaft_start + shaft_h * 0.35, radius * 0.88, True, flute_count, flute_depth),
        (shaft_start + shaft_h * 0.68, radius * 0.84, True, flute_count, flute_depth * 0.92),
        (shaft_end - shaft_h * 0.04, shaft_top_r, True, flute_count, flute_depth * 0.85),
        (shaft_end, neck_r, False, 0, 0.0),
        (shaft_end + capital_h * 0.20, neck_r * 0.98, False, 0, 0.0),
        (shaft_end + capital_h * 0.55, echinus_r, False, 0, 0.0),
        (shaft_end + capital_h * 0.78, abacus_r * 0.96, False, 0, 0.0),
        (z1 - h * 0.012, abacus_r * 0.94, False, 0, 0.0),
    ]

    mesh = bpy.data.meshes.new(name + "Mesh")
    verts = []
    faces = []


    _append_revolved_sections(verts, faces, center, sections, segments, cap_bottom=True, cap_top=False)


    plinth_half = radius * 1.42
    _append_box(
        verts, faces,
        center.x - plinth_half, center.x + plinth_half,
        center.y - plinth_half, center.y + plinth_half,
        z0, z0 + base_plinth_h,
    )


    abacus_half = radius * 1.36
    abacus_z0 = z1 - h * 0.045
    _append_box(
        verts, faces,
        center.x - abacus_half, center.x + abacus_half,
        center.y - abacus_half, center.y + abacus_half,
        abacus_z0, z1,
    )


    top_cap_center = len(verts)
    verts.append((center.x, center.y, abacus_z0))
    last_ring_start = 0 + (len(sections) - 1) * segments
    for i in range(segments):
        j = (i + 1) % segments
        faces.append((top_cap_center, last_ring_start + i, last_ring_start + j))

    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(_unique_name(name), mesh)
    bpy.context.collection.objects.link(obj)
    return obj


def _make_column_mesh_object(name, center, radius, height, segments, z0, z1, style="CLASSIC"):
    style = str(style or "CLASSIC").upper().strip()
    if style == "SIMPLE":
        return _make_cylinder_mesh_object(name, center, radius, height, segments, z0, z1)
    return _make_classic_column_mesh_object(name, center, radius, height, segments, z0, z1)

def _merge_column_objects(columns, name="Columns", parent=None):
    valid = [o for o in columns if o and o.name in bpy.data.objects and o.type == "MESH"]
    if not valid:
        return None
    if len(valid) == 1:
        obj = valid[0]
        if parent and parent.name in bpy.data.objects:
            _parent_keep_world(obj, parent)
        return obj

    verts = []
    faces = []
    for obj in valid:
        mw = obj.matrix_world.copy()
        base = len(verts)
        verts.extend(tuple(mw @ v.co) for v in obj.data.vertices)
        for poly in obj.data.polygons:
            faces.append(tuple(base + i for i in poly.vertices))

    mesh = bpy.data.meshes.new(name + "Mesh")
    mesh.from_pydata(verts, [], faces)
    mesh.update()

    merged = bpy.data.objects.new(_unique_name(name), mesh)
    bpy.context.collection.objects.link(merged)

    first = valid[0]
    for key in first.keys():
        if key == "_RNA_UI":
            continue
        try:
            merged[key] = first[key]
        except Exception:
            pass
    merged["house_generated_column"] = True
    merged["house_column_merged"] = True
    merged["house_column_parts"] = len(valid)

    if parent and parent.name in bpy.data.objects:
        _parent_keep_world(merged, parent)

    for obj in valid:
        if obj.name in bpy.data.objects:
            bpy.data.objects.remove(obj, do_unlink=True)

    return merged


def _column_height_from_house_source(obj, fallback_height=2.0):
    candidates = []
    if obj:
        candidates.append(obj)
        if obj.parent:
            candidates.append(obj.parent)
        source_name = obj.get("house_platform_for") or obj.get("house_roof_for") or obj.get("house_column_for")
        if source_name:
            source = bpy.data.objects.get(str(source_name))
            if source:
                candidates.append(source)
    for candidate in candidates:
        try:
            value = float(candidate.get("house_floor_height", 0.0))
            if value > 0.01:
                return value
        except Exception:
            pass
    bounds = _world_mesh_bounds(obj)
    if bounds:
        return max(0.01, float(bounds[5] - bounds[4]))
    return max(0.01, float(fallback_height))


def _face_outward_normal_xy(building, center_w, n_w):
    normal_xy = Vector((n_w.x, n_w.y, 0.0))
    if normal_xy.length <= 1e-6:
        return Vector((0.0, 0.0, 0.0))
    normal_xy.normalize()

    bounds = _world_mesh_bounds(building)
    if bounds:
        min_x, max_x, min_y, max_y, _min_z, _max_z = bounds
        bounds_center = Vector(((min_x + max_x) * 0.5, (min_y + max_y) * 0.5, 0.0))
        to_face = Vector((center_w.x, center_w.y, 0.0)) - bounds_center
        if to_face.length > 1e-6 and normal_xy.dot(to_face.normalized()) < 0.0:
            normal_xy.negate()

    return normal_xy


def _longest_face_edge_direction_xy(building, poly):
    verts = list(poly.vertices)
    if len(verts) < 2:
        return Vector((1.0, 0.0, 0.0)), 0.0

    mw = building.matrix_world
    best_dir = None
    best_len = 0.0

    for i, idx in enumerate(verts):
        jdx = verts[(i + 1) % len(verts)]
        a = mw @ building.data.vertices[idx].co
        b = mw @ building.data.vertices[jdx].co
        d = Vector((b.x - a.x, b.y - a.y, 0.0))
        length = d.length
        if length > best_len + 1e-6:
            best_len = length
            best_dir = d

    if best_dir is None or best_len <= 1e-6:
        return Vector((1.0, 0.0, 0.0)), 0.0

    best_dir.normalize()
    return best_dir, best_len


def _spawn_columns_on_face(
    building,
    face_index,
    *,
    radius=0.18,
    segments=24,
    count=1,
    spacing=1.0,
    face_offset=0.0,
    z_offset=0.0,
    height=None,
    style="CLASSIC",
    parent_to_building=True,
):
    if not building or building.type != "MESH":
        return [], "Активный объект не Mesh."
    if face_index is None or face_index < 0 or face_index >= len(building.data.polygons):
        return [], "Выбранная грань больше недоступна."

    axes, err = _face_axes_bounds_world_by_index(building, face_index)
    if err:
        return [], err
    center_w, n_w, right_w, up_w, min_u, max_u, min_v, max_v = axes

    poly = building.data.polygons[face_index]
    verts_w = [building.matrix_world @ building.data.vertices[i].co for i in poly.vertices]
    if not verts_w:
        return [], "Не удалось прочитать выбранную грань."


    z0 = min(v.z for v in verts_w) + float(z_offset)
    source_height = _column_height_from_house_source(
        building,
        fallback_height=max(v.z for v in verts_w) - min(v.z for v in verts_w),
    )
    if height is None:
        final_height = source_height
    else:
        final_height = max(0.01, float(height))
    z1 = z0 + final_height
    if z1 - z0 <= 0.01:
        return [], "Высота колонны слишком мала."

    count = max(1, int(count))
    spacing = max(0.0, float(spacing))
    if count > 1 and spacing <= 1e-6:
        return [], "Для нескольких колонн параметр Spacing должен быть больше 0."


    direction, face_length = _longest_face_edge_direction_xy(building, poly)

    normal_xy = _face_outward_normal_xy(building, center_w, n_w)
    center_xy = Vector((center_w.x, center_w.y, 0.0))

    if normal_xy.length > 1e-6:


        base_center = center_xy + normal_xy * (float(radius) + float(face_offset))
    else:


        depth_dir = Vector((-direction.y, direction.x, 0.0))
        if depth_dir.length <= 1e-6:
            depth_dir = Vector((0.0, 1.0, 0.0))
        else:
            depth_dir.normalize()

        bounds = _world_mesh_bounds(building)
        if bounds:
            min_x, max_x, min_y, max_y, _min_z, _max_z = bounds
            bounds_center = Vector(((min_x + max_x) * 0.5, (min_y + max_y) * 0.5, 0.0))
            to_face = center_xy - bounds_center
            if to_face.length > 1e-6 and depth_dir.dot(to_face.normalized()) < 0.0:
                depth_dir.negate()

        base_center = center_xy + depth_dir * float(face_offset)

    middle = (count - 1) * 0.5
    columns = []
    for i in range(count):
        offset = (i - middle) * spacing
        center = base_center + direction * offset
        column = _make_column_mesh_object("Column", center, radius, z1 - z0, segments, z0, z1, style=style)
        column["house_generated_column"] = True
        column["house_column_for"] = building.name
        column["house_column_style"] = str(style).upper()
        column["house_column_face"] = int(face_index)
        column["house_column_index"] = i + 1
        column["house_column_count"] = count
        column["house_column_spacing"] = spacing
        column["house_column_face_length"] = float(face_length)
        column["house_column_row_direction"] = f"{direction.x:.6f},{direction.y:.6f},{direction.z:.6f}"
        column["house_column_in_out_offset"] = float(face_offset)
        column["house_column_height_source"] = float(source_height)
        column["house_column_height"] = float(final_height)
        if parent_to_building:
            _parent_keep_world(column, building)
        columns.append(column)

    return columns, None


def _bbox_world_minmax(obj):
    if not obj or obj.type != "MESH":
        return None
    pts = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    if not pts:
        return None
    return {
        "min_x": min(p.x for p in pts),
        "max_x": max(p.x for p in pts),
        "min_y": min(p.y for p in pts),
        "max_y": max(p.y for p in pts),
        "min_z": min(p.z for p in pts),
        "max_z": max(p.z for p in pts),
        "center": Vector((
            (min(p.x for p in pts) + max(p.x for p in pts)) * 0.5,
            (min(p.y for p in pts) + max(p.y for p in pts)) * 0.5,
            (min(p.z for p in pts) + max(p.z for p in pts)) * 0.5,
        )),
    }


def _mid_overlap_or_gap(a0, a1, b0, b1):
    lo = max(a0, b0)
    hi = min(a1, b1)
    if lo <= hi:
        return (lo + hi) * 0.5
    if a1 < b0:
        return (a1 + b0) * 0.5
    return (b1 + a0) * 0.5


def _spawn_columns_between_objects(
    obj_a,
    obj_b,
    *,
    radius=0.18,
    segments=24,
    placement_mode="CURSOR",
    cursor_location=None,
    z_offset=0.0,
    bottom_gap=0.0,
    top_gap=0.0,
    count=1,
    spacing=1.0,
    row_axis="X",
    parent_to_active=True,
    active_parent=None,
    style="CLASSIC",
):
    if not obj_a or not obj_b or obj_a.type != "MESH" or obj_b.type != "MESH":
        return [], "Для колонн нужно выбрать два Mesh-объекта."
    if obj_a == obj_b:
        return [], "Выберите два разных объекта."

    ba = _bbox_world_minmax(obj_a)
    bb = _bbox_world_minmax(obj_b)
    if not ba or not bb:
        return [], "Не удалось получить габариты выбранных объектов."

    ca = (ba["min_z"] + ba["max_z"]) * 0.5
    cb = (bb["min_z"] + bb["max_z"]) * 0.5
    lower, upper = (ba, bb) if ca <= cb else (bb, ba)

    z0 = lower["max_z"] + float(bottom_gap) + float(z_offset)
    z1 = upper["min_z"] - float(top_gap) + float(z_offset)

    if z1 - z0 <= 0.01:
        z0 = min(ba["min_z"], bb["min_z"]) + float(bottom_gap) + float(z_offset)
        z1 = max(ba["max_z"], bb["max_z"]) - float(top_gap) + float(z_offset)

    if z1 - z0 <= 0.01:
        return [], "Высота колонн слишком мала."

    placement_mode = str(placement_mode or "CURSOR").upper()
    if placement_mode == "CENTER" or cursor_location is None:
        x = _mid_overlap_or_gap(ba["min_x"], ba["max_x"], bb["min_x"], bb["max_x"])
        y = _mid_overlap_or_gap(ba["min_y"], ba["max_y"], bb["min_y"], bb["max_y"])
        base_center = Vector((x, y, 0.0))
    else:
        base_center = Vector((float(cursor_location.x), float(cursor_location.y), 0.0))

    count = max(1, int(count))
    spacing = max(0.0, float(spacing))
    if count > 1 and spacing <= EPS:
        return [], "Для нескольких колонн параметр Spacing должен быть больше 0."

    row_axis = str(row_axis or "X").upper().strip()
    direction = Vector((0.0, 1.0, 0.0)) if row_axis == "Y" else Vector((1.0, 0.0, 0.0))
    middle = (count - 1) * 0.5

    columns = []
    for i in range(count):
        offset = (i - middle) * spacing
        center = base_center + direction * offset
        column = _make_column_mesh_object("Column", center, radius, z1 - z0, segments, z0, z1, style=style)
        column["house_generated_column"] = True
        column["house_column_between"] = f"{obj_a.name}|{obj_b.name}"
        column["house_column_style"] = str(style).upper()
        column["house_column_index"] = i + 1
        column["house_column_count"] = count
        column["house_column_spacing"] = spacing
        column["house_column_axis"] = row_axis
        if parent_to_active and active_parent and active_parent.name in bpy.data.objects:
            _parent_keep_world(column, active_parent)
        columns.append(column)

    return columns, None
