import bpy
import bmesh
from mathutils import Vector, Matrix

from .constants import EPS


def _set_active(obj: bpy.types.Object):
    vl = bpy.context.view_layer
    for o in vl.objects:
        o.select_set(False)
    obj.select_set(True)
    vl.objects.active = obj


def _ensure_object_mode():
    if bpy.context.object and bpy.context.object.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")


def _mesh_apply_scale(obj: bpy.types.Object):
    _set_active(obj)
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)


def _parent_keep_world(child: bpy.types.Object, parent: bpy.types.Object):
    child.parent = parent
    child.matrix_parent_inverse = parent.matrix_world.inverted()


def _remove_object_by_name(name: str):
    if not name:
        return
    o = bpy.data.objects.get(name)
    if o:
        bpy.data.objects.remove(o, do_unlink=True)


def _remove_objects_from_packed_names(packed: str):
    if not packed:
        return
    for n in packed.split("|"):
        _remove_object_by_name(n.strip())


def _building_bbox_world(obj: bpy.types.Object):
    mw = obj.matrix_world
    pts = [mw @ Vector(c) for c in obj.bound_box]
    min_x = min(p.x for p in pts)
    max_x = max(p.x for p in pts)
    min_y = min(p.y for p in pts)
    max_y = max(p.y for p in pts)
    min_z = min(p.z for p in pts)
    max_z = max(p.z for p in pts)
    center = Vector(((min_x + max_x) * 0.5, (min_y + max_y) * 0.5, (min_z + max_z) * 0.5))
    size = Vector((max_x - min_x, max_y - min_y, max_z - min_z))
    return (min_x, max_x, min_y, max_y, min_z, max_z, center, size)


def _set_object_basis_world(
    obj: bpy.types.Object,
    x_axis_w: Vector,
    y_axis_w: Vector,
    z_axis_w: Vector,
    location_w: Vector,
):
    R = Matrix((x_axis_w, y_axis_w, z_axis_w)).transposed().to_4x4()
    R.translation = location_w
    obj.matrix_world = R


def _get_selected_face_index_edit(obj: bpy.types.Object):
    if obj is None or obj.type != "MESH":
        return None, "Активный объект не Mesh"
    if obj.mode != "EDIT":
        return None, "Нужно быть в Edit Mode и выделить одну грань"

    bm = bmesh.from_edit_mesh(obj.data)
    bm.faces.ensure_lookup_table()
    bm.faces.index_update()
    faces = [f for f in bm.faces if f.select]
    if len(faces) != 1:
        return None, "Нужно выделить ровно одну грань"
    return faces[0].index, None


def _face_axes_bounds_world_by_index(obj: bpy.types.Object, face_index: int):
    if obj is None or obj.type != "MESH":
        return None, "Объект не Mesh"
    me = obj.data
    if face_index is None or face_index < 0 or face_index >= len(me.polygons):
        return None, "Неверный индекс грани"

    poly = me.polygons[face_index]
    mw = obj.matrix_world
    m3 = mw.to_3x3()

    center_l = poly.center
    normal_l = poly.normal.normalized()

    center_w = mw @ center_l
    n_w = (m3 @ normal_l).normalized()


    up_ref = Vector((0, 0, 1))
    if abs(n_w.dot(up_ref)) > 0.999:
        up_ref = Vector((1, 0, 0))

    right_w = up_ref.cross(n_w)
    if right_w.length < EPS:
        return None, "Не удалось построить оси грани"
    right_w.normalize()

    up_w = n_w.cross(right_w)
    if up_w.length < EPS:
        return None, "Не удалось построить оси грани"
    up_w.normalize()

    verts_w = [mw @ me.vertices[i].co for i in poly.vertices]
    us, vs = [], []
    for p in verts_w:
        rel = p - center_w
        us.append(right_w.dot(rel))
        vs.append(up_w.dot(rel))

    min_u, max_u = min(us), max(us)
    min_v, max_v = min(vs), max(vs)
    return (center_w, n_w, right_w, up_w, min_u, max_u, min_v, max_v), None


def _face_world_rect(obj: bpy.types.Object, face_index: int):
    me = obj.data
    poly = me.polygons[face_index]
    mw = obj.matrix_world
    m3 = mw.to_3x3()

    verts_w = [mw @ me.vertices[i].co for i in poly.vertices]
    min_x = min(v.x for v in verts_w)
    max_x = max(v.x for v in verts_w)
    min_y = min(v.y for v in verts_w)
    max_y = max(v.y for v in verts_w)
    z_top = max(v.z for v in verts_w)

    n_w = (m3 @ poly.normal).normalized()
    return (min_x, max_x, min_y, max_y, z_top, n_w)


def _is_top_face(obj: bpy.types.Object, face_index: int, up_dot_min=0.9):
    me = obj.data
    mw = obj.matrix_world
    m3 = mw.to_3x3()

    n_w = (m3 @ me.polygons[face_index].normal).normalized()
    if n_w.dot(Vector((0, 0, 1))) < up_dot_min:
        return False

    all_verts_z = [(mw @ v.co).z for v in me.vertices]
    max_z = max(all_verts_z) if all_verts_z else 0.0

    face_verts_z = [(mw @ me.vertices[i].co).z for i in me.polygons[face_index].vertices]
    if not face_verts_z:
        return False

    tol = 1e-4
    return all(abs(z - max_z) <= tol for z in face_verts_z)


def _world_height_to_local_dz(obj: bpy.types.Object, world_h: float) -> float:
    z_w = obj.matrix_world.to_3x3() @ Vector((0.0, 0.0, 1.0))
    return float(world_h) / max(EPS, z_w.length)


def _unique_mesh_name(base: str) -> str:
    if base not in bpy.data.meshes:
        return base
    i = 1
    while f"{base}.{i:03d}" in bpy.data.meshes:
        i += 1
    return f"{base}.{i:03d}"


def _cleanup_house_redo_backups(keep_names=None):
    keep = {str(n) for n in (keep_names or []) if n}
    for mesh in list(bpy.data.meshes):
        try:
            is_backup = bool(mesh.get("house_redo_backup"))
        except Exception:
            is_backup = False
        if is_backup and mesh.name not in keep and mesh.users == 0:
            try:
                bpy.data.meshes.remove(mesh)
            except Exception:
                pass


def _backup_mesh_for_redo(obj: bpy.types.Object, base_name: str = "HouseOpeningBaseMesh") -> str:
    if not obj or obj.type != "MESH":
        return ""
    try:
        if obj.mode == "EDIT":
            obj.update_from_editmode()
    except Exception:
        pass
    _cleanup_house_redo_backups()
    mesh = obj.data.copy()
    mesh.name = _unique_mesh_name(base_name)
    mesh["house_redo_backup"] = True
    return mesh.name


def _restore_mesh_from_redo_backup(obj: bpy.types.Object, backup_mesh_name: str) -> bool:
    if not obj or obj.type != "MESH" or not backup_mesh_name:
        return False
    backup = bpy.data.meshes.get(backup_mesh_name)
    if not backup:
        return False

    old_mesh = obj.data
    restored = backup.copy()
    restored.name = old_mesh.name
    obj.data = restored

    try:
        if old_mesh.users == 0 and not old_mesh.get("house_redo_backup"):
            bpy.data.meshes.remove(old_mesh)
    except Exception:
        pass

    try:
        obj.update_tag(refresh={"DATA"})
        bpy.context.view_layer.update()
    except Exception:
        pass
    return True

def _remove_modifier_by_name(obj: bpy.types.Object, name: str):
    if not obj or not name:
        return
    mod = obj.modifiers.get(name)
    if mod:
        obj.modifiers.remove(mod)


def _remove_modifiers_from_packed_names(obj: bpy.types.Object, packed: str):
    if not obj or not packed:
        return
    for n in packed.split("|"):
        _remove_modifier_by_name(obj, n.strip())


def _face_world_polygon(obj: bpy.types.Object, face_index: int):
    if obj is None or obj.type != "MESH":
        return None, "Объект не Mesh"
    me = obj.data
    if face_index is None or face_index < 0 or face_index >= len(me.polygons):
        return None, "Неверный индекс грани"

    poly = me.polygons[face_index]
    mw = obj.matrix_world
    m3 = mw.to_3x3()
    verts_w = [mw @ me.vertices[i].co for i in poly.vertices]
    if len(verts_w) < 3:
        return None, "У грани меньше трёх вершин"

    z_top = max(v.z for v in verts_w)
    n_w = (m3 @ poly.normal).normalized()
    return (verts_w, z_top, n_w), None
