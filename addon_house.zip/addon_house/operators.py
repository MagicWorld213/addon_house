import bpy
import bmesh
from mathutils import Vector

from .constants import (
    BUILDING_DEFAULT_BASE,
    BUILDING_DEFAULT_PLUS_ARM_RATIO,
    BUILDING_DEFAULT_PLUS_ARM_WIDTH,
    BUILDING_DEFAULT_PLUS_SIZE_MODE,
    BUILDING_DEFAULT_L_ARM_WIDTH,
    BUILDING_DEFAULT_L_VERTICAL_WIDTH,
    BUILDING_DEFAULT_L_HORIZONTAL_WIDTH,
    BUILDING_DEFAULT_L_X_LENGTH,
    BUILDING_DEFAULT_L_Y_LENGTH,
    BUILDING_DEFAULT_U_ARM_WIDTH,
    BUILDING_DEFAULT_U_LEFT_ARM_WIDTH,
    BUILDING_DEFAULT_U_RIGHT_ARM_WIDTH,
    BUILDING_DEFAULT_U_SUPPORT_DEPTH,
    BUILDING_DEFAULT_U_LEFT_LENGTH,
    BUILDING_DEFAULT_U_RIGHT_LENGTH,
    BUILDING_DEFAULT_FLOORS,
    BUILDING_DEFAULT_WIDTH,
    BUILDING_DEFAULT_DEPTH,
    BUILDING_DEFAULT_FLOOR_HEIGHT,
    BUILDING_DEFAULT_LOC_X,
    BUILDING_DEFAULT_LOC_Y,
    DOOR_DEFAULT_SCALE,
    WINDOW_DEFAULT_SCALE,
    WINDOW_DEFAULT_TYPE,
    WINDOW_DEFAULT_ARCH_SEGMENTS,
    WINDOW_DEFAULT_ROUND_SEGMENTS,
    ROOF_DEFAULT_HEIGHT,
    ROOF_DEFAULT_OVERHANG,
    ROOF_DEFAULT_OVERHANG_X,
    ROOF_DEFAULT_OVERHANG_Y,
    ROOF_DEFAULT_THICKNESS,
    ROOF_DEFAULT_RIDGE_AXIS,
    ROOF_DEFAULT_GABLE_TYPE,
    STAIRS_DEFAULT_STEPS,
    STAIRS_DEFAULT_X,
    STAIRS_DEFAULT_Y,
    STAIRS_DEFAULT_Z,
    STAIRS_DEFAULT_GAP,
    DOOR_GAP,
    WINDOW_GAP,
    OPENING_DEFAULT_CUT_DEPTH,
    BALCONY_DEFAULT_WIDTH,
    BALCONY_DEFAULT_DEPTH,
    BALCONY_DEFAULT_RAIL_HEIGHT,
    BALCONY_DEFAULT_SLAB_THICKNESS,
    BALCONY_DEFAULT_POST_SIZE,
    BALCONY_DEFAULT_BAR_THICKNESS,
    BALCONY_DEFAULT_BAR_SPACING,
    BALCONY_DEFAULT_GAP,
    PLATFORM_DEFAULT_OVERHANG,
    PLATFORM_DEFAULT_OFFSET_X,
    PLATFORM_DEFAULT_OFFSET_Y,
    PLATFORM_DEFAULT_HEIGHT,
    PLATFORM_DEFAULT_BORDER_INSET,
    COLUMN_DEFAULT_RADIUS,
    COLUMN_DEFAULT_SEGMENTS,
    COLUMN_DEFAULT_COUNT,
    COLUMN_DEFAULT_SPACING,
    COLUMN_DEFAULT_FACE_OFFSET,
    COLUMN_DEFAULT_Z_OFFSET,
)
from .callbacks import (
    _upd_reset_building,
    _upd_reset_door_scale,
    _upd_reset_window_scale,
    _upd_reset_roof,
    _upd_reset_balcony,
    _upd_platform_overhang,
    _upd_reset_platform,
    _upd_reset_column,
)
from .utils import (
    _ensure_object_mode,
    _face_axes_bounds_world_by_index,
    _get_selected_face_index_edit,
    _is_top_face,
    _parent_keep_world,
    _remove_object_by_name,
    _remove_objects_from_packed_names,
    _remove_modifiers_from_packed_names,
    _face_world_polygon,
    _set_active,
    _backup_mesh_for_redo,
    _restore_mesh_from_redo_backup,
)
from .building import create_building, add_floor
from .openings import (
    _spawn_door,
    _door_uv,
    _spawn_window_at_u_v,
    _spawn_window_arch_at_u_v,
    _spawn_window_round_at_u_v,
    _add_opening_cutout_rect,
    _add_opening_recesses,
)
from .roof import add_roof
from .stairs import _spawn_stairs_on_face
from .platform import _spawn_platform_under_building
from .columns import (
    _column_height_from_house_source,
    _merge_column_objects,
    _spawn_columns_on_face,
    _spawn_columns_between_objects,
)
from .balcony import (
    _merge_objects_evaluated,
    _spawn_balcony_on_face,
    _unique_name,
)


_ROOF_TYPE_ITEMS_COMMON = [
    ("PYRAMID", "Pyramid", "Pyramid/hip roof"),
    ("GABLE", "Gable", "Gable roof (ridge)"),
    ("FLAT", "Flat", "Flat roof"),
    ("CONE", "Cone", "Cone roof"),
]

_ROOF_TYPE_ITEMS_NO_CONE = [
    ("PYRAMID", "Pyramid", "Pyramid/hip roof"),
    ("GABLE", "Gable", "Gable roof (ridge)"),
    ("FLAT", "Flat", "Flat roof"),
]

_ROOF_PYRAMID_TYPE_ITEMS = [
    ("A", "Type A", "Hip-style rectangular roof with a short ridge"),
    ("B", "Type B", "Classic pyramid roof where all faces meet at one center apex"),
]

_ROOF_GABLE_TYPE_ITEMS = [
    ("A", "Type A", "Corner/bent gable with ridge turning through the L/U corners"),
]

_ROOF_GABLE_TYPE_ITEMS_U = [
    ("A", "Type A", "Corner/bent gable with ridge turning through the U corners"),
]


def _roof_operator_base_type(self, context):
    obj = None
    name = getattr(self, "building_name", "")
    if name:
        obj = bpy.data.objects.get(name)
    if obj is None and context is not None:
        obj = context.active_object
    if obj is None:
        return ""
    return str(obj.get("house_base_type", "")).upper().strip()


def _operator_prop(self, name, default=None):
    try:
        return getattr(self, name)
    except Exception:
        return default


def _set_operator_prop(self, name, value):
    try:
        setattr(self, name, value)
        return True
    except Exception:
        return False


def _restore_active_mode(context, prev_active, prev_mode):
    try:
        if prev_active and prev_active.name in bpy.data.objects:
            _set_active(prev_active)
        if (
            prev_mode == "EDIT_MESH"
            and prev_active
            and prev_active.name in bpy.data.objects
            and prev_active.type == "MESH"
        ):
            bpy.ops.object.mode_set(mode="EDIT")
    except Exception:
        pass


def _roof_gable_type_items(self, context):
    if _roof_operator_base_type(self, context) == "U":
        return _ROOF_GABLE_TYPE_ITEMS_U
    return _ROOF_GABLE_TYPE_ITEMS


def _roof_type_items(self, context):


    if _roof_operator_base_type(self, context) in {"L", "U"}:
        return _ROOF_TYPE_ITEMS_NO_CONE
    return _ROOF_TYPE_ITEMS_COMMON


def _get_selected_face_indices_edit(obj, expected_count=None):
    if not obj or obj.type != "MESH":
        return [], "Активный объект не является Mesh."
    if bpy.context.mode != "EDIT_MESH":
        return [], "Перейдите в Edit Mode и выберите грани."
    bm = bmesh.from_edit_mesh(obj.data)
    bm.faces.ensure_lookup_table()
    bm.faces.index_update()
    faces = [f.index for f in bm.faces if f.select]
    if expected_count is not None and len(faces) != expected_count:
        return faces, f"Выберите ровно {expected_count} грани. Сейчас выбрано: {len(faces)}."
    return faces, None


class OBJECT_OT_create_building(bpy.types.Operator):
    bl_idname = "object.create_building"
    bl_label = "Create Building"
    bl_options = {"REGISTER", "UNDO"}

    base_type: bpy.props.EnumProperty(
        name="Base",
        items=[
            ("RECT", "Rect", "Прямоугольное основание"),
            ("CIRCLE", "Circle", "Круглое/овальное основание (цилиндр)"),
            ("PLUS", "Plus", "Основание в виде плюса"),
            ("L", "L-Shape", "Г-образное основание"),
            ("U", "U-Shape", "П-образное основание"),
        ],
        default=BUILDING_DEFAULT_BASE,
    )

    plus_arm_ratio: bpy.props.FloatProperty(
        name="Plus Arm Ratio",
        description="Толщина перекладины плюса (доля от min(Width, Depth))",
        default=BUILDING_DEFAULT_PLUS_ARM_RATIO,
        min=0.05,
        max=0.95,
    )

    plus_size_mode: bpy.props.EnumProperty(
        name="Plus Size Mode",
        items=[
            ("WIDTH", "Width", "Толщина перекладин в метрах"),
        ],
        default="WIDTH",
    )

    plus_arm_width: bpy.props.FloatProperty(
        name="Plus Arm Width",
        description="Толщина перекладин плюса (в метрах)",
        default=BUILDING_DEFAULT_PLUS_ARM_WIDTH,
        min=0.01,
    )

    l_arm_width: bpy.props.FloatProperty(
        name="L Common Width",
        description="Legacy common thickness fallback for L-shape",
        default=BUILDING_DEFAULT_L_ARM_WIDTH,
        min=0.01,
        options={"HIDDEN"},
    )
    l_vertical_width: bpy.props.FloatProperty(
        name="Vertical Width",
        description="Толщина вертикального рукава Г-образного основания",
        default=BUILDING_DEFAULT_L_VERTICAL_WIDTH,
        min=0.01,
    )
    l_horizontal_width: bpy.props.FloatProperty(
        name="Horizontal Width",
        description="Толщина горизонтального рукава Г-образного основания",
        default=BUILDING_DEFAULT_L_HORIZONTAL_WIDTH,
        min=0.01,
    )
    l_x_length: bpy.props.FloatProperty(
        name="X Length",
        description="Длина горизонтального рукава Г-образного основания",
        default=BUILDING_DEFAULT_L_X_LENGTH,
        min=0.1,
    )
    l_y_length: bpy.props.FloatProperty(
        name="Y Length",
        description="Длина вертикального рукава Г-образного основания",
        default=BUILDING_DEFAULT_L_Y_LENGTH,
        min=0.1,
    )

    u_arm_width: bpy.props.FloatProperty(
        name="U Common Width",
        description="Legacy common thickness fallback for U-shape",
        default=BUILDING_DEFAULT_U_ARM_WIDTH,
        min=0.01,
        options={"HIDDEN"},
    )
    u_left_arm_width: bpy.props.FloatProperty(
        name="Left Width",
        description="Толщина левой ножки П-образного основания; меняется внутрь независимо от опоры",
        default=BUILDING_DEFAULT_U_LEFT_ARM_WIDTH,
        min=0.01,
    )
    u_right_arm_width: bpy.props.FloatProperty(
        name="Right Width",
        description="Толщина правой ножки П-образного основания; меняется внутрь независимо от опоры",
        default=BUILDING_DEFAULT_U_RIGHT_ARM_WIDTH,
        min=0.01,
    )
    u_support_depth: bpy.props.FloatProperty(
        name="Support Depth",
        description="Глубина нижней опоры/перемычки П-образного основания; расширяется внутрь отдельно от ножек",
        default=BUILDING_DEFAULT_U_SUPPORT_DEPTH,
        min=0.01,
    )
    u_left_length: bpy.props.FloatProperty(
        name="Left Length",
        description="Длина левого рукава П-образного основания",
        default=BUILDING_DEFAULT_U_LEFT_LENGTH,
        min=0.1,
    )
    u_right_length: bpy.props.FloatProperty(
        name="Right Length",
        description="Длина правого рукава П-образного основания",
        default=BUILDING_DEFAULT_U_RIGHT_LENGTH,
        min=0.1,
    )

    created_obj_name: bpy.props.StringProperty(options={"HIDDEN"}, default="")

    floors: bpy.props.IntProperty(name="Floors", default=BUILDING_DEFAULT_FLOORS, min=1)
    width: bpy.props.FloatProperty(name="Width", default=BUILDING_DEFAULT_WIDTH, min=0.1)
    depth: bpy.props.FloatProperty(name="Depth", default=BUILDING_DEFAULT_DEPTH, min=0.1)
    floor_height: bpy.props.FloatProperty(name="Floor Height", default=BUILDING_DEFAULT_FLOOR_HEIGHT, min=0.1)

    loc_x: bpy.props.FloatProperty(name="Location X", default=BUILDING_DEFAULT_LOC_X)
    loc_y: bpy.props.FloatProperty(name="Location Y", default=BUILDING_DEFAULT_LOC_Y)

    reset_building: bpy.props.BoolProperty(
        name="Return start scale",
        default=False,
        update=_upd_reset_building,
    )

    def invoke(self, context, event):
        self.created_obj_name = ""
        return self.execute(context)

    def draw(self, context):
        layout = self.layout

        layout.prop(self, "base_type")
        if self.base_type == "PLUS":
            layout.prop(self, "plus_arm_width")
        elif self.base_type == "L":
            layout.prop(self, "l_x_length")
            layout.prop(self, "l_y_length")
            layout.separator()
            layout.prop(self, "l_vertical_width")
            layout.prop(self, "l_horizontal_width")
        elif self.base_type == "U":
            layout.prop(self, "u_left_length")
            layout.prop(self, "u_right_length")
            layout.separator()
            layout.prop(self, "u_left_arm_width")
            layout.prop(self, "u_right_arm_width")
            layout.prop(self, "u_support_depth")

        layout.prop(self, "floors")

        if self.base_type in {"RECT", "CIRCLE", "PLUS"}:
            layout.prop(self, "width")
            layout.prop(self, "depth")
        elif self.base_type == "U":
            layout.prop(self, "width", text="Total Width")

        layout.prop(self, "floor_height")
        layout.separator()
        layout.prop(self, "loc_x")
        layout.prop(self, "loc_y")
        layout.separator()
        layout.prop(self, "reset_building", text="Return start scale", toggle=True, icon="LOOP_BACK")

    def execute(self, context):
        _ensure_object_mode()
        _remove_object_by_name(self.created_obj_name)

        b = create_building(
            floors=self.floors,
            width=self.width,
            depth=self.depth,
            floor_height=self.floor_height,
            loc_x=self.loc_x,
            loc_y=self.loc_y,
            base_type=self.base_type,
            plus_arm_ratio=self.plus_arm_ratio,
            plus_arm_width=self.plus_arm_width,
            plus_size_mode="WIDTH",
            l_arm_width=self.l_arm_width,
            l_vertical_width=self.l_vertical_width,
            l_horizontal_width=self.l_horizontal_width,
            l_x_length=self.l_x_length,
            l_y_length=self.l_y_length,
            u_arm_width=self.u_arm_width,
            u_left_arm_width=self.u_left_arm_width,
            u_right_arm_width=self.u_right_arm_width,
            u_support_depth=self.u_support_depth,
            u_left_length=self.u_left_length,
            u_right_length=self.u_right_length,
        )

        if b:
            self.created_obj_name = b.name
            return {"FINISHED"}
        self.report({"ERROR"}, "Не удалось создать здание с выбранными параметрами.")
        return {"CANCELLED"}


class OBJECT_OT_add_floor(bpy.types.Operator):
    bl_idname = "object.add_floor"
    bl_label = "Add Floor"
    bl_options = {"REGISTER", "UNDO"}

    floor_height: bpy.props.FloatProperty(name="Floor Height", default=BUILDING_DEFAULT_FLOOR_HEIGHT, min=0.1)

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == "MESH"

    def invoke(self, context, event):
        obj = context.active_object
        if obj is not None and "house_floor_height" in obj:
            self.floor_height = float(obj["house_floor_height"])
        return self.execute(context)

    def execute(self, context):
        obj = context.active_object
        ok, err = add_floor(obj=obj, floor_height=self.floor_height)
        if err:
            self.report({"ERROR"}, err)
            return {"CANCELLED"}
        if ok and obj is not None and obj.type == "MESH":
            obj["house_floor_height"] = float(self.floor_height)
        return {"FINISHED"}


class OBJECT_OT_add_door(bpy.types.Operator):
    bl_idname = "object.add_door"
    bl_label = "Add Door"
    bl_options = {"REGISTER", "UNDO"}

    building_name: bpy.props.StringProperty(options={"HIDDEN"})
    face_index: bpy.props.IntProperty(options={"HIDDEN"}, default=-1)
    created_obj_name: bpy.props.StringProperty(options={"HIDDEN"}, default="")
    created_cutout_name: bpy.props.StringProperty(options={"HIDDEN"}, default="")
    created_modifier_name: bpy.props.StringProperty(options={"HIDDEN"}, default="")
    base_mesh_name: bpy.props.StringProperty(options={"HIDDEN"}, default="")

    count: bpy.props.IntProperty(
        name="Count",
        default=1,
        min=1,
        max=200,
        description="Количество дверей на выбранной грани",
    )
    spacing: bpy.props.FloatProperty(
        name="Spacing",
        default=1.0,
        min=0.0,
        description="Расстояние между центрами соседних дверей",
    )
    offset_x: bpy.props.FloatProperty(name="Left / Right Offset", default=0.0)
    offset_z: bpy.props.FloatProperty(name="Up Offset", default=0.0)

    scale: bpy.props.FloatVectorProperty(
        name="Door Size",
        subtype="XYZ",
        size=3,
        default=(DOOR_DEFAULT_SCALE.x, DOOR_DEFAULT_SCALE.y, DOOR_DEFAULT_SCALE.z),
        min=0.001,
    )

    cut_opening: bpy.props.BoolProperty(
        name="Cut Opening",
        description="Создать реальную редактируемую геометрию проёма в выбранной грани",
        default=True,
    )
    cut_depth: bpy.props.FloatProperty(
        name="Cut Depth",
        description="Глубина реального выреза внутрь стены/массы здания",
        default=OPENING_DEFAULT_CUT_DEPTH,
        min=0.001,
    )
    cut_extra_x: bpy.props.FloatProperty(
        name="Cut Width Extra",
        description="Internal fixed margin for the door cutout",
        default=0.02,
        min=0.0,
        options={"HIDDEN"},
    )
    cut_extra_z: bpy.props.FloatProperty(
        name="Cut Height Extra",
        description="Internal fixed margin for the door cutout",
        default=0.02,
        min=0.0,
        options={"HIDDEN"},
    )
    show_insert: bpy.props.BoolProperty(
        name="Show Door Object",
        description="Показывать отдельный объект двери. Отключите, чтобы не закрывать нишу/глубину выреза",
        default=False,
    )

    reset_scale: bpy.props.BoolProperty(
        name="Return start scale",
        default=False,
        update=_upd_reset_door_scale,
    )

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == "MESH" and context.mode == "EDIT_MESH"

    def invoke(self, context, event):
        obj = context.active_object
        idx, err = _get_selected_face_index_edit(obj)
        if err:
            self.report({"ERROR"}, err)
            return {"CANCELLED"}

        self.building_name = obj.name
        self.face_index = idx
        self.created_obj_name = ""
        self.created_cutout_name = ""
        self.created_modifier_name = ""
        self.base_mesh_name = ""
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "count")
        if self.count > 1:
            layout.prop(self, "spacing")
        layout.prop(self, "offset_x", text="Left / Right Offset")
        layout.prop(self, "offset_z", text="Up Offset")

        layout.separator()
        layout.label(text="Door Size")
        col = layout.column(align=True)
        col.prop(self, "scale", index=0, text="Width")
        col.prop(self, "scale", index=1, text="Out")
        col.prop(self, "scale", index=2, text="Height")

        layout.separator()
        layout.prop(self, "cut_opening")
        if self.cut_opening:
            layout.prop(self, "cut_depth")
            layout.prop(self, "show_insert")
        layout.separator()
        layout.prop(self, "reset_scale", text="Return start scale", toggle=True, icon="LOOP_BACK")

    def execute(self, context):
        building = bpy.data.objects.get(self.building_name)
        if not building or building.type != "MESH":
            self.report({"ERROR"}, "Здание не найдено.")
            return {"CANCELLED"}

        prev_active = context.view_layer.objects.active
        prev_mode = context.mode

        _ensure_object_mode()
        self.base_mesh_name = _backup_mesh_for_redo(building, "HouseDoorBaseMesh")
        _remove_modifiers_from_packed_names(building, self.created_modifier_name)
        _remove_objects_from_packed_names(self.created_cutout_name)
        _remove_objects_from_packed_names(self.created_obj_name)
        self.created_obj_name = ""
        self.created_modifier_name = ""
        self.created_cutout_name = ""

        data, err = _face_axes_bounds_world_by_index(building, self.face_index)
        if err:
            self.report({"ERROR"}, err)
            _restore_active_mode(context, prev_active, prev_mode)
            return {"CANCELLED"}

        _, _, _, _, min_u, max_u, min_v, _ = data
        s = Vector(self.scale)
        count = max(1, int(self.count))
        spacing = max(0.0, float(self.spacing))
        if count > 1 and spacing <= 1e-6:
            self.report({"ERROR"}, "Для нескольких дверей параметр Spacing должен быть больше 0.")
            _restore_active_mode(context, prev_active, prev_mode)
            return {"CANCELLED"}

        v = min_v + float(s.z) * 0.5 + float(self.offset_z)
        center_u = (min_u + max_u) * 0.5 + float(self.offset_x)
        if count == 1:
            us = [center_u]
        else:
            total = (count - 1) * spacing
            start_u = center_u - total * 0.5
            us = [start_u + i * spacing for i in range(count)]

        created = []
        opening_specs = []
        center_u_no_offset = (min_u + max_u) * 0.5

        for u in us:
            if (not self.cut_opening) or self.show_insert:
                door = _spawn_door(
                    building=building,
                    face_index=self.face_index,
                    offset_x=float(u) - center_u_no_offset,
                    offset_z=self.offset_z,
                    gap=DOOR_GAP,
                    scale=s,
                    parent_to_building=True,
                )
                if door:
                    created.append(door.name)
                else:
                    _remove_objects_from_packed_names("|".join(created))
                    self.report({"ERROR"}, "Не удалось создать объект двери на выбранной грани.")
                    _restore_active_mode(context, prev_active, prev_mode)
                    return {"CANCELLED"}

            if self.cut_opening:
                opening_specs.append({
                    "u": float(u),
                    "v": float(v),
                    "width": float(s.x) + float(self.cut_extra_x) * 2.0,
                    "height": float(s.z) + float(self.cut_extra_z) * 2.0,
                    "profile_type": "RECT",
                    "segments": 4,
                })

        if self.cut_opening and opening_specs:
            cutter_names, mod_names, cut_err = _add_opening_recesses(
                building=building,
                face_index=self.face_index,
                openings=opening_specs,
                cut_depth=self.cut_depth,
            )
            if cut_err:
                _remove_objects_from_packed_names("|".join(created))
                _restore_mesh_from_redo_backup(building, self.base_mesh_name)
                self.report({"ERROR"}, cut_err)
                _restore_active_mode(context, prev_active, prev_mode)
                return {"CANCELLED"}
            self.created_cutout_name = cutter_names or ""
            self.created_modifier_name = mod_names or ""

        self.created_obj_name = "|".join(created)

        _restore_active_mode(context, prev_active, prev_mode)
        return {"FINISHED"}


class OBJECT_OT_add_window(bpy.types.Operator):
    bl_idname = "object.add_window"
    bl_label = "Add Window"
    bl_options = {"REGISTER", "UNDO"}

    building_name: bpy.props.StringProperty(options={"HIDDEN"})
    face_index: bpy.props.IntProperty(options={"HIDDEN"}, default=-1)
    created_obj_names: bpy.props.StringProperty(options={"HIDDEN"}, default="")
    created_cutout_names: bpy.props.StringProperty(options={"HIDDEN"}, default="")
    created_modifier_names: bpy.props.StringProperty(options={"HIDDEN"}, default="")
    base_mesh_name: bpy.props.StringProperty(options={"HIDDEN"}, default="")

    window_type: bpy.props.EnumProperty(
        name="Type",
        items=[
            ("RECT", "Rect", "Regular rectangular window (cube)"),
            ("ARCH", "Arch", "Arched window"),
            ("ROUND", "Round", "Round/Ellipse window"),
        ],
        default=WINDOW_DEFAULT_TYPE,
    )

    arch_segments: bpy.props.IntProperty(
        name="Arch Segments",
        default=WINDOW_DEFAULT_ARCH_SEGMENTS,
        min=4,
        max=128,
    )

    round_segments: bpy.props.IntProperty(
        name="Round Segments",
        default=WINDOW_DEFAULT_ROUND_SEGMENTS,
        min=8,
        max=256,
    )

    count: bpy.props.IntProperty(name="Count", default=1, min=1, max=200)
    spacing: bpy.props.FloatProperty(name="Spacing", default=1.0, min=0.0)
    offset_x: bpy.props.FloatProperty(name="Left / Right Offset", default=0.0)
    offset_z: bpy.props.FloatProperty(name="Up / Down Offset", default=0.0)

    scale: bpy.props.FloatVectorProperty(
        name="Scale",
        subtype="XYZ",
        size=3,
        default=(WINDOW_DEFAULT_SCALE.x, WINDOW_DEFAULT_SCALE.y, WINDOW_DEFAULT_SCALE.z),
        min=0.001,
    )

    cut_opening: bpy.props.BoolProperty(
        name="Cut Opening",
        description="Создать реальную редактируемую геометрию проёма в выбранной грани",
        default=True,
    )
    cut_depth: bpy.props.FloatProperty(
        name="Cut Depth",
        description="Глубина реального выреза внутрь стены/массы здания",
        default=OPENING_DEFAULT_CUT_DEPTH,
        min=0.001,
    )
    cut_extra_x: bpy.props.FloatProperty(
        name="Cut Width Extra",
        description="Дополнительный запас выреза слева/справа от окна",
        default=0.02,
        min=0.0,
    )
    cut_extra_z: bpy.props.FloatProperty(
        name="Cut Height Extra",
        description="Дополнительный запас выреза сверху/снизу от окна",
        default=0.02,
        min=0.0,
    )
    show_insert: bpy.props.BoolProperty(
        name="Show Window Object",
        description="Показывать отдельный объект окна. Отключите, чтобы не закрывать нишу/глубину выреза",
        default=False,
    )

    reset_scale: bpy.props.BoolProperty(
        name="Return start scale",
        default=False,
        update=_upd_reset_window_scale,
    )

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == "MESH" and context.mode == "EDIT_MESH"

    def invoke(self, context, event):
        obj = context.active_object
        idx, err = _get_selected_face_index_edit(obj)
        if err:
            self.report({"ERROR"}, err)
            return {"CANCELLED"}

        self.building_name = obj.name
        self.face_index = idx
        self.created_obj_names = ""
        self.created_cutout_names = ""
        self.created_modifier_names = ""
        self.base_mesh_name = ""
        return self.execute(context)

    def draw(self, context):
        layout = self.layout

        layout.prop(self, "window_type")
        if self.window_type == "ARCH":
            layout.prop(self, "arch_segments")
        if self.window_type == "ROUND":
            layout.prop(self, "round_segments")

        layout.separator()
        layout.prop(self, "count")
        layout.prop(self, "spacing")
        layout.prop(self, "offset_x", text="Left / Right Offset")
        layout.prop(self, "offset_z", text="Up / Down Offset")

        layout.label(text="Size:")
        col = layout.column(align=True)
        col.prop(self, "scale", index=0, text="Width")
        col.prop(self, "scale", index=1, text="Out")
        col.prop(self, "scale", index=2, text="Height")

        layout.separator()
        layout.prop(self, "cut_opening")
        if self.cut_opening:
            layout.prop(self, "cut_depth")
            layout.prop(self, "show_insert")
        layout.separator()
        layout.prop(self, "reset_scale", text="Return start scale", toggle=True, icon="LOOP_BACK")

    def execute(self, context):
        building = bpy.data.objects.get(self.building_name)
        if not building or building.type != "MESH":
            self.report({"ERROR"}, "Здание не найдено.")
            return {"CANCELLED"}

        prev_active = context.view_layer.objects.active
        prev_mode = context.mode

        _ensure_object_mode()
        self.base_mesh_name = _backup_mesh_for_redo(building, "HouseWindowBaseMesh")
        _remove_modifiers_from_packed_names(building, self.created_modifier_names)
        _remove_objects_from_packed_names(self.created_cutout_names)
        _remove_objects_from_packed_names(self.created_obj_names)
        self.created_obj_names = ""
        self.created_cutout_names = ""
        self.created_modifier_names = ""

        data, err = _face_axes_bounds_world_by_index(building, self.face_index)
        if err:
            self.report({"ERROR"}, err)
            _restore_active_mode(context, prev_active, prev_mode)
            return {"CANCELLED"}

        center_w, n_w, right_w, up_w, min_u, max_u, min_v, max_v = data

        v = (min_v + max_v) * 0.5 + self.offset_z
        center_u = (min_u + max_u) * 0.5 + self.offset_x

        if self.count == 1:
            us = [center_u]
        else:
            total = (self.count - 1) * self.spacing
            start_u = center_u - total * 0.5
            us = [start_u + i * self.spacing for i in range(self.count)]

        created = []
        cutouts = []
        modifiers = []
        opening_specs = []
        s = Vector(self.scale)

        for u in us:
            win = None
            if (not self.cut_opening) or self.show_insert:
                if self.window_type == "RECT":
                    win = _spawn_window_at_u_v(
                        building=building,
                        face_index=self.face_index,
                        u=u,
                        v=v,
                        gap=WINDOW_GAP,
                        scale=s,
                        parent_to_building=True,
                    )
                elif self.window_type == "ARCH":
                    win = _spawn_window_arch_at_u_v(
                        building=building,
                        face_index=self.face_index,
                        u=u,
                        v=v,
                        gap=WINDOW_GAP,
                        scale=s,
                        arc_segments=self.arch_segments,
                        parent_to_building=True,
                    )
                else:
                    win = _spawn_window_round_at_u_v(
                        building=building,
                        face_index=self.face_index,
                        u=u,
                        v=v,
                        gap=WINDOW_GAP,
                        scale=s,
                        round_segments=self.round_segments,
                        parent_to_building=True,
                    )

                if win:
                    created.append(win.name)
                else:
                    _remove_objects_from_packed_names("|".join(created))
                    self.report({"ERROR"}, "Не удалось создать объект окна на выбранной грани.")
                    _restore_active_mode(context, prev_active, prev_mode)
                    return {"CANCELLED"}

            if self.cut_opening:
                if self.window_type == "ARCH":
                    segs = self.arch_segments
                elif self.window_type == "ROUND":
                    segs = self.round_segments
                else:
                    segs = 4

                opening_specs.append({
                    "u": float(u),
                    "v": float(v),
                    "width": float(s.x) + float(self.cut_extra_x) * 2.0,
                    "height": float(s.z) + float(self.cut_extra_z) * 2.0,
                    "profile_type": self.window_type,
                    "segments": segs,
                })

        if self.cut_opening and opening_specs:
            cutter_names, mod_names, cut_err = _add_opening_recesses(
                building=building,
                face_index=self.face_index,
                openings=opening_specs,
                cut_depth=self.cut_depth,
            )
            if cut_err:
                _remove_objects_from_packed_names("|".join(created))
                _restore_mesh_from_redo_backup(building, self.base_mesh_name)
                self.report({"ERROR"}, cut_err)
                _restore_active_mode(context, prev_active, prev_mode)
                return {"CANCELLED"}
            if cutter_names:
                cutouts.extend([n for n in cutter_names.split("|") if n])
            if mod_names:
                modifiers.extend([n for n in mod_names.split("|") if n])

        self.created_obj_names = "|".join(created)
        self.created_cutout_names = "|".join(cutouts)
        self.created_modifier_names = "|".join(modifiers)

        _restore_active_mode(context, prev_active, prev_mode)
        return {"FINISHED"}


class OBJECT_OT_add_roof(bpy.types.Operator):
    bl_idname = "object.add_roof"
    bl_label = "Add Roof"
    bl_options = {"REGISTER", "UNDO"}

    building_name: bpy.props.StringProperty(options={"HIDDEN"})
    face_index: bpy.props.IntProperty(options={"HIDDEN"}, default=-1)
    created_obj_name: bpy.props.StringProperty(options={"HIDDEN"}, default="")

    roof_type: bpy.props.EnumProperty(
        name="Roof Type",
        items=_ROOF_TYPE_ITEMS_COMMON,
        default="PYRAMID",
    )

    roof_type_lu: bpy.props.EnumProperty(
        name="Roof Type",
        items=_ROOF_TYPE_ITEMS_NO_CONE,
        default="PYRAMID",
    )

    ridge_axis: bpy.props.EnumProperty(
        name="Ridge Axis",
        items=[
            ("AUTO", "Auto", "Rect: use longer side; PLUS: cross-gable"),
            ("X", "Along X", "Ridge goes along X"),
            ("Y", "Along Y", "Ridge goes along Y"),
        ],
        default=ROOF_DEFAULT_RIDGE_AXIS,
    )

    ridge_axis_rect_gable: bpy.props.EnumProperty(
        name="Ridge Axis",
        items=[
            ("X", "Along X", "Ridge goes along X"),
            ("Y", "Along Y", "Ridge goes along Y"),
        ],
        default="X",
    )

    pyramid_type: bpy.props.EnumProperty(
        name="Pyramid Type",
        items=_ROOF_PYRAMID_TYPE_ITEMS,
        default="A",
    )

    gable_type_lu: bpy.props.EnumProperty(
        name="Gable Type",
        items=_roof_gable_type_items,
    )

    roof_height: bpy.props.FloatProperty(name="Roof Height", default=ROOF_DEFAULT_HEIGHT, min=0.05)
    overhang: bpy.props.FloatProperty(name="Overhang", default=ROOF_DEFAULT_OVERHANG, min=0.0)
    overhang_x: bpy.props.FloatProperty(name="Overhang X", default=ROOF_DEFAULT_OVERHANG_X, min=0.0)
    overhang_y: bpy.props.FloatProperty(name="Overhang Y", default=ROOF_DEFAULT_OVERHANG_Y, min=0.0)
    thickness: bpy.props.FloatProperty(name="Thickness", default=ROOF_DEFAULT_THICKNESS, min=0.01)

    reset_roof: bpy.props.BoolProperty(
        name="Return start scale",
        default=False,
        update=_upd_reset_roof,
    )

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == "MESH" and context.mode == "EDIT_MESH"

    def invoke(self, context, event):
        obj = context.active_object
        idx, err = _get_selected_face_index_edit(obj)
        if err:
            self.report({"ERROR"}, err)
            return {"CANCELLED"}

        if not _is_top_face(obj, idx):
            self.report({"ERROR"}, "Выберите верхнюю горизонтальную грань (самую верхнюю) перед добавлением крыши.")
            return {"CANCELLED"}

        self.building_name = obj.name
        self.face_index = idx
        self.created_obj_name = ""
        base_type = _roof_operator_base_type(self, context)
        if base_type in {"L", "U"}:
            roof_type = _operator_prop(self, "roof_type", "PYRAMID")
            if roof_type != "CONE":
                _set_operator_prop(self, "roof_type_lu", roof_type)
            else:
                _set_operator_prop(self, "roof_type_lu", "PYRAMID")
            if _operator_prop(self, "gable_type_lu", "A") != "A":
                _set_operator_prop(self, "gable_type_lu", "A")
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        base_type = _roof_operator_base_type(self, context)
        if base_type in {"L", "U"}:
            roof_type = _operator_prop(self, "roof_type_lu", "PYRAMID")
            try:
                layout.prop(self, "roof_type_lu")
            except Exception:
                layout.label(text="Roof Type: Pyramid")
        else:
            roof_type = _operator_prop(self, "roof_type", "PYRAMID")
            try:
                layout.prop(self, "roof_type")
            except Exception:
                layout.label(text="Roof Type: Pyramid")

        if roof_type == "PYRAMID":
            if base_type == "RECT":
                layout.prop(self, "pyramid_type")
        elif roof_type == "GABLE":
            if base_type == "RECT":
                layout.prop(self, "ridge_axis_rect_gable")
            elif base_type in {"L", "U", "PLUS"}:
                pass
            else:
                layout.prop(self, "ridge_axis")

        if roof_type in {"PYRAMID", "GABLE", "CONE"}:
            layout.prop(self, "roof_height")

        if roof_type == "FLAT":
            layout.prop(self, "thickness")

        layout.separator()
        layout.prop(self, "overhang")

        if roof_type != "CONE":
            layout.prop(self, "overhang_x")
            layout.prop(self, "overhang_y")

        layout.separator()
        layout.prop(self, "reset_roof", text="Return start scale", toggle=True, icon="LOOP_BACK")

    def execute(self, context):
        building = bpy.data.objects.get(self.building_name)
        if not building or building.type != "MESH":
            self.report({"ERROR"}, "Здание не найдено.")
            return {"CANCELLED"}

        if self.face_index < 0 or self.face_index >= len(building.data.polygons):
            self.report({"ERROR"}, "Грань недоступна. Выберите верхнюю грань заново и добавьте крышу.")
            return {"CANCELLED"}

        base_type = str(building.get("house_base_type", "")).upper().strip()
        roof_type = _operator_prop(self, "roof_type_lu", "PYRAMID") if base_type in {"L", "U"} else _operator_prop(self, "roof_type", "PYRAMID")
        if base_type in {"L", "U"} and _operator_prop(self, "gable_type_lu", "A") != "A":
            _set_operator_prop(self, "gable_type_lu", "A")
        if base_type in {"L", "U"} and roof_type == "CONE":
            self.report({"ERROR"}, "Круглая крыша недоступна для L/U оснований.")
            return {"CANCELLED"}

        prev_active = context.view_layer.objects.active
        prev_mode = context.mode

        _ensure_object_mode()
        _remove_object_by_name(self.created_obj_name)

        poly_data, err = _face_world_polygon(building, self.face_index)
        if err:
            self.report({"ERROR"}, err)
            _restore_active_mode(context, prev_active, prev_mode)
            return {"CANCELLED"}
        base_polygon_world, _, _ = poly_data

        ox = self.overhang_x if roof_type != "CONE" else 0.0
        oy = self.overhang_y if roof_type != "CONE" else 0.0
        pyramid_type = _operator_prop(self, "pyramid_type", "A")
        ridge_axis = self.ridge_axis
        if roof_type == "GABLE" and base_type == "RECT":
            ridge_axis = _operator_prop(self, "ridge_axis_rect_gable", "X")
        if roof_type == "PYRAMID" and base_type == "RECT" and pyramid_type == "A":


            ridge_axis = "AUTO"

        roof = add_roof(
            obj=building,
            roof_type=roof_type,
            roof_height=self.roof_height,
            overhang=self.overhang,
            overhang_x=ox,
            overhang_y=oy,
            thickness=self.thickness,
            ridge_axis=ridge_axis,
            gable_type=_operator_prop(self, "gable_type_lu", "A") if base_type in {"L", "U"} else "A",
            pyramid_type=pyramid_type,
            base_polygon_world=base_polygon_world,
        )
        if roof:
            self.created_obj_name = roof.name
        else:
            self.report({"ERROR"}, "Не удалось создать крышу с выбранными параметрами.")
            _restore_active_mode(context, prev_active, prev_mode)
            return {"CANCELLED"}

        _restore_active_mode(context, prev_active, prev_mode)
        return {"FINISHED"}


class OBJECT_OT_add_stairs(bpy.types.Operator):
    bl_idname = "object.add_stairs"
    bl_label = "Add Stairs"
    bl_options = {"REGISTER", "UNDO"}

    building_name: bpy.props.StringProperty(options={"HIDDEN"})
    face_index: bpy.props.IntProperty(options={"HIDDEN"}, default=-1)
    created_obj_name: bpy.props.StringProperty(options={"HIDDEN"}, default="")

    steps: bpy.props.IntProperty(name="Steps", default=STAIRS_DEFAULT_STEPS, min=1, max=300)
    size_x: bpy.props.FloatProperty(name="Length", default=STAIRS_DEFAULT_X, min=0.01)
    size_y: bpy.props.FloatProperty(name="Width", default=STAIRS_DEFAULT_Y, min=0.01)
    size_z: bpy.props.FloatProperty(name="Height", default=STAIRS_DEFAULT_Z, min=0.01)

    offset_x: bpy.props.FloatProperty(
        name="Left / Right Offset",
        description="Move the stairs left/right along the selected face",
        default=0.0,
    )

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == "MESH" and context.mode == "EDIT_MESH"

    def invoke(self, context, event):
        obj = context.active_object
        idx, err = _get_selected_face_index_edit(obj)
        if err:
            self.report({"ERROR"}, err)
            return {"CANCELLED"}

        self.building_name = obj.name
        self.face_index = idx
        self.created_obj_name = ""
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "steps")
        layout.prop(self, "size_x")
        layout.prop(self, "size_y")
        layout.prop(self, "size_z")
        layout.separator()
        layout.prop(self, "offset_x")

    def execute(self, context):
        building = bpy.data.objects.get(self.building_name)
        if not building or building.type != "MESH":
            self.report({"ERROR"}, "Здание не найдено.")
            return {"CANCELLED"}

        prev_active = context.view_layer.objects.active
        prev_mode = context.mode

        _ensure_object_mode()
        _remove_object_by_name(self.created_obj_name)

        stairs = _spawn_stairs_on_face(
            building=building,
            face_index=self.face_index,
            steps=self.steps,
            size_x=self.size_x,
            size_y=self.size_y,
            size_z=self.size_z,
            offset_x=self.offset_x,
            offset_z=0.0,
            gap=STAIRS_DEFAULT_GAP,
            parent_to_building=True,
        )
        if stairs:
            self.created_obj_name = stairs.name
        else:
            self.report({"ERROR"}, "Не удалось создать лестницу на выбранной грани.")
            _restore_active_mode(context, prev_active, prev_mode)
            return {"CANCELLED"}

        _restore_active_mode(context, prev_active, prev_mode)
        return {"FINISHED"}


class OBJECT_OT_add_balcony(bpy.types.Operator):
    bl_idname = "object.add_balcony"
    bl_label = "Add Balcony"
    bl_options = {"REGISTER", "UNDO"}

    building_name: bpy.props.StringProperty(options={"HIDDEN"})
    face_index: bpy.props.IntProperty(options={"HIDDEN"}, default=-1)

    width: bpy.props.FloatProperty(name="Width", default=BALCONY_DEFAULT_WIDTH, min=0.2)
    depth: bpy.props.FloatProperty(name="Depth", default=BALCONY_DEFAULT_DEPTH, min=0.2)
    rail_height: bpy.props.FloatProperty(name="Rail Height", default=BALCONY_DEFAULT_RAIL_HEIGHT, min=0.2)
    slab_thickness: bpy.props.FloatProperty(name="Slab Thickness", default=BALCONY_DEFAULT_SLAB_THICKNESS, min=0.01)

    post_size: bpy.props.FloatProperty(name="Post Size", default=BALCONY_DEFAULT_POST_SIZE, min=0.02)

    infill_type: bpy.props.EnumProperty(
        name="Bars Type",
        items=(
            ("VERTICAL", "Vertical", "Vertical infill bars"),
            ("HORIZONTAL", "Horizontal", "Horizontal infill bars"),
        ),
        default="VERTICAL",
    )

    bar_thickness: bpy.props.FloatProperty(
        name="Bar Thickness",
        default=BALCONY_DEFAULT_BAR_THICKNESS,
        min=0.005,
        max=1.0,
    )
    bar_spacing: bpy.props.FloatProperty(name="Bar Spacing", default=BALCONY_DEFAULT_BAR_SPACING, min=0.02)

    offset_x: bpy.props.FloatProperty(
        name="Left / Right Offset",
        description="Move the balcony left/right along the selected face",
        default=0.0,
    )
    offset_z: bpy.props.FloatProperty(
        name="Up / Down Offset",
        description="Move the balcony up/down on the selected face",
        default=0.0,
    )

    reset_balcony: bpy.props.BoolProperty(
        name="Return start scale",
        default=False,
        update=_upd_reset_balcony,
    )

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == "MESH" and context.mode == "EDIT_MESH"

    def invoke(self, context, event):
        obj = context.active_object
        idx, err = _get_selected_face_index_edit(obj)
        if err:
            self.report({"ERROR"}, err)
            return {"CANCELLED"}
        self.building_name = obj.name
        self.face_index = idx
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "width")
        layout.prop(self, "depth")
        layout.prop(self, "rail_height")
        layout.prop(self, "slab_thickness")
        layout.separator()
        layout.prop(self, "post_size")
        layout.prop(self, "infill_type")
        layout.separator()
        layout.prop(self, "bar_thickness")
        layout.prop(self, "bar_spacing")
        layout.separator()
        layout.prop(self, "offset_x")
        layout.prop(self, "offset_z")
        layout.separator()
        layout.prop(self, "reset_balcony", text="Return start scale", toggle=True)

    def execute(self, context):
        building = bpy.data.objects.get(self.building_name)
        if not building or building.type != "MESH":
            self.report({"ERROR"}, "Объект не найден или не Mesh.")
            return {"CANCELLED"}


        if self.bar_thickness > self.post_size:
            self.bar_thickness = self.post_size

        prev_active = context.view_layer.objects.active
        prev_mode = context.mode

        _ensure_object_mode()


        redo_key = f"house_last_balcony_face_{int(self.face_index)}"
        old_name = str(building.get(redo_key, "") or "")
        if old_name:
            _remove_object_by_name(old_name)
            try:
                del building[redo_key]
            except Exception:
                pass

        parts, parent, err = _spawn_balcony_on_face(
            building=building,
            face_index=self.face_index,
            width=self.width,
            depth=self.depth,
            rail_h=self.rail_height,
            slab_t=self.slab_thickness,
            post_s=self.post_size,
            bar_t=self.bar_thickness,
            bar_spacing=self.bar_spacing,
            offset_x=self.offset_x,
            offset_z=self.offset_z,
            gap=BALCONY_DEFAULT_GAP,
            infill_type=self.infill_type,
            parent_to_building=True,
        )
        if err:
            self.report({"ERROR"}, err)
            if prev_active and prev_mode == "EDIT_MESH":
                try:
                    bpy.ops.object.mode_set(mode="EDIT")
                except Exception:
                    pass
            return {"CANCELLED"}


        merged = _merge_objects_evaluated(parts, _unique_name("Balcony"))
        if merged:
            _parent_keep_world(merged, building)
            merged["house_generated_balcony"] = True
            merged["house_balcony_for"] = building.name
            merged["house_balcony_face"] = int(self.face_index)
            building[redo_key] = merged.name

            for o in parts:
                if o and o.name in bpy.data.objects:
                    bpy.data.objects.remove(o, do_unlink=True)
            if parent and parent.name in bpy.data.objects:
                bpy.data.objects.remove(parent, do_unlink=True)
        else:
            for o in parts:
                if o and o.name in bpy.data.objects:
                    bpy.data.objects.remove(o, do_unlink=True)
            if parent and parent.name in bpy.data.objects:
                bpy.data.objects.remove(parent, do_unlink=True)
            self.report({"ERROR"}, "Не удалось собрать балкон в один Mesh.")
            if prev_active and prev_mode == "EDIT_MESH":
                try:
                    bpy.ops.object.mode_set(mode="EDIT")
                except Exception:
                    pass
            return {"CANCELLED"}

        if prev_active:
            context.view_layer.objects.active = prev_active
        if prev_mode == "EDIT_MESH" and prev_active and prev_active.type == "MESH":
            bpy.ops.object.mode_set(mode="EDIT")

        return {"FINISHED"}


class OBJECT_OT_add_platform(bpy.types.Operator):
    bl_idname = "object.add_platform"
    bl_label = "Add Platform"
    bl_options = {"REGISTER", "UNDO"}

    building_name: bpy.props.StringProperty(options={"HIDDEN"})
    created_obj_name: bpy.props.StringProperty(options={"HIDDEN"}, default="")

    overhang: bpy.props.FloatProperty(
        name="Overhang",
        description="Symmetric platform extension around the building. Changing this also updates Offset X and Offset Y.",
        default=PLATFORM_DEFAULT_OVERHANG,
        min=0.0,
        update=_upd_platform_overhang,
    )
    offset_x: bpy.props.FloatProperty(name="Offset X", default=PLATFORM_DEFAULT_OFFSET_X, min=0.0)
    offset_y: bpy.props.FloatProperty(name="Offset Y", default=PLATFORM_DEFAULT_OFFSET_Y, min=0.0)
    height: bpy.props.FloatProperty(name="Height", default=PLATFORM_DEFAULT_HEIGHT, min=0.01)
    border_inset: bpy.props.FloatProperty(
        name="Top Border Inset",
        description="Inset for the top face loop, matching the platform sketch",
        default=PLATFORM_DEFAULT_BORDER_INSET,
        min=0.0,
    )
    reset_platform: bpy.props.BoolProperty(
        name="Return start scale",
        default=False,
        update=_upd_reset_platform,
    )

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == "MESH"

    def invoke(self, context, event):
        obj = context.active_object
        if not obj or obj.type != "MESH":
            self.report({"ERROR"}, "Выберите здание Mesh.")
            return {"CANCELLED"}


        source_name = obj.get("house_platform_for") if obj.get("house_generated_platform") else ""
        source = bpy.data.objects.get(str(source_name)) if source_name else None
        self.building_name = source.name if source and source.type == "MESH" else obj.name
        self.created_obj_name = ""
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "overhang")
        layout.prop(self, "offset_x")
        layout.prop(self, "offset_y")
        layout.prop(self, "height")
        layout.prop(self, "border_inset")
        layout.separator()
        layout.prop(self, "reset_platform", text="Return start scale", toggle=True)

    def execute(self, context):
        building = bpy.data.objects.get(self.building_name)
        if not building or building.type != "MESH":
            self.report({"ERROR"}, "Здание не найдено.")
            return {"CANCELLED"}

        prev_active = context.view_layer.objects.active
        prev_mode = context.mode

        _ensure_object_mode()
        _remove_object_by_name(self.created_obj_name)
        self.created_obj_name = ""

        redo_key = "house_last_platform"
        old_name = str(building.get(redo_key, "") or "")
        if old_name:
            _remove_object_by_name(old_name)
            try:
                del building[redo_key]
            except Exception:
                pass

        platform, err = _spawn_platform_under_building(
            building,
            offset_x=self.offset_x,
            offset_y=self.offset_y,
            height=self.height,
            border_inset=self.border_inset,
            parent_to_building=True,
        )
        if err:
            self.report({"ERROR"}, err)
            _restore_active_mode(context, prev_active, prev_mode)
            return {"CANCELLED"}
        if platform:
            self.created_obj_name = platform.name
            building[redo_key] = platform.name
            _set_active(platform)
            try:
                bpy.ops.object.mode_set(mode="EDIT")
                bpy.ops.mesh.select_mode(type="FACE")
                bpy.ops.mesh.select_all(action="SELECT")
            except Exception:


                try:
                    bpy.ops.object.mode_set(mode="OBJECT")
                    _set_active(platform)
                except Exception:
                    pass

        return {"FINISHED"}


class OBJECT_OT_add_column(bpy.types.Operator):
    bl_idname = "object.add_column"
    bl_label = "Add Column"
    bl_options = {"REGISTER", "UNDO"}

    building_name: bpy.props.StringProperty(options={"HIDDEN"})
    face_indices: bpy.props.StringProperty(options={"HIDDEN"}, default="")
    object_names: bpy.props.StringProperty(options={"HIDDEN"}, default="")
    created_obj_name: bpy.props.StringProperty(options={"HIDDEN"}, default="")
    default_height: bpy.props.FloatProperty(options={"HIDDEN"}, default=2.0)
    source_mode: bpy.props.EnumProperty(
        name="Source",
        items=[
            ("FACE", "Selected Face", "Create columns on one selected face in Edit Mode"),
            ("OBJECTS", "Two Objects", "Legacy: create columns between two selected objects"),
        ],
        default="FACE",
        options={"HIDDEN"},
    )

    style: bpy.props.EnumProperty(
        name="Style",
        items=[
            ("CLASSIC", "Classic", "Detailed fluted classical column with base and capital"),
            ("SIMPLE", "Simple", "Simple cylindrical column"),
        ],
        default="CLASSIC",
    )
    radius: bpy.props.FloatProperty(name="Radius", default=COLUMN_DEFAULT_RADIUS, min=0.01)
    segments: bpy.props.IntProperty(name="Segments", default=COLUMN_DEFAULT_SEGMENTS, min=6, max=128)
    count: bpy.props.IntProperty(
        name="Count",
        default=COLUMN_DEFAULT_COUNT,
        min=1,
        max=100,
        description="Number of columns to create in one row",
    )
    spacing: bpy.props.FloatProperty(
        name="Spacing",
        default=COLUMN_DEFAULT_SPACING,
        min=0.0,
        description="Distance between neighboring columns when Count is greater than 1",
    )
    height: bpy.props.FloatProperty(
        name="Height",
        default=2.0,
        min=0.01,
        description="Column height. The base stays in place and only the top moves.",
    )
    row_axis: bpy.props.EnumProperty(
        name="Row Axis",
        items=[
            ("X", "X", "Legacy object mode: place additional columns along global X"),
            ("Y", "Y", "Legacy object mode: place additional columns along global Y"),
        ],
        default="X",
    )

    placement_mode: bpy.props.EnumProperty(
        name="Placement",
        items=[
            ("CURSOR", "3D Cursor", "Legacy object mode: use 3D Cursor X/Y as the column position"),
            ("CENTER", "Between Objects", "Legacy object mode: use the overlap/nearest midpoint between selected objects"),
        ],
        default="CURSOR",
    )
    bottom_gap: bpy.props.FloatProperty(
        name="Bottom Gap",
        default=0.0,
        description="Legacy object mode: raise the column start from the lower selected object",
    )
    top_gap: bpy.props.FloatProperty(
        name="Top Gap",
        default=0.0,
        description="Legacy object mode: lower the column end from the upper selected object",
    )

    face_offset: bpy.props.FloatProperty(
        name="Forward / Back Offset",
        default=COLUMN_DEFAULT_FACE_OFFSET,
        description="Move the column row forward/back along the selected face depth direction.",
    )
    z_offset: bpy.props.FloatProperty(name="Z Offset", default=COLUMN_DEFAULT_Z_OFFSET)
    reset_column: bpy.props.BoolProperty(
        name="Return start scale",
        default=False,
        update=_upd_reset_column,
    )

    @classmethod
    def poll(cls, context):
        if context.mode == "EDIT_MESH":
            return context.active_object and context.active_object.type == "MESH"

        if context.mode == "OBJECT":
            return len([o for o in context.selected_objects if o.type == "MESH"]) >= 2
        return False

    def invoke(self, context, event):
        self.created_obj_name = ""
        self.face_indices = ""
        self.object_names = ""
        self.default_height = 2.0

        if context.mode == "EDIT_MESH":
            obj = context.active_object
            indices, err = _get_selected_face_indices_edit(obj, expected_count=1)
            if err:
                self.report({"ERROR"}, err)
                return {"CANCELLED"}
            self.source_mode = "FACE"
            self.building_name = obj.name
            self.face_indices = str(indices[0])
            try:
                self.default_height = _column_height_from_house_source(obj, fallback_height=2.0)
                self.height = max(0.01, float(self.default_height))
            except Exception:
                self.default_height = 2.0
                self.height = 2.0
            return self.execute(context)

        if context.mode == "OBJECT":
            selected = [o for o in context.selected_objects if o.type == "MESH"]
            if len(selected) != 2:
                self.report({"ERROR"}, "Основной режим: перейдите в Edit Mode и выберите одну грань. Старый режим требует ровно два Mesh-объекта.")
                return {"CANCELLED"}
            self.source_mode = "OBJECTS"
            self.object_names = "|".join(o.name for o in selected)
            active = context.active_object if context.active_object in selected else selected[0]
            self.building_name = active.name
            return self.execute(context)

        self.report({"ERROR"}, "Перейдите в Edit Mode и выберите одну грань.")
        return {"CANCELLED"}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "style")
        layout.prop(self, "radius")
        layout.prop(self, "segments")
        layout.prop(self, "count")
        if self.count > 1:
            layout.prop(self, "spacing")
            if self.source_mode == "OBJECTS":
                layout.prop(self, "row_axis")

        layout.separator()
        if self.source_mode == "FACE":
            layout.prop(self, "height")
            layout.prop(self, "face_offset", text="Forward / Back Offset")
            layout.prop(self, "z_offset")
        elif self.source_mode == "OBJECTS":
            layout.prop(self, "placement_mode")
            layout.prop(self, "bottom_gap")
            layout.prop(self, "top_gap")
            layout.prop(self, "z_offset")

        layout.separator()
        layout.prop(self, "reset_column", text="Return start scale", toggle=True)

    def execute(self, context):
        prev_active = context.view_layer.objects.active
        prev_mode = context.mode

        _ensure_object_mode()
        _remove_objects_from_packed_names(self.created_obj_name)
        self.created_obj_name = ""
        merge_parent = None

        if self.source_mode == "OBJECTS":
            names = [n for n in self.object_names.split("|") if n]
            if len(names) != 2:
                self.report({"ERROR"}, "Выберите два объекта заново.")
                _restore_active_mode(context, prev_active, prev_mode)
                return {"CANCELLED"}
            obj_a = bpy.data.objects.get(names[0])
            obj_b = bpy.data.objects.get(names[1])
            active_parent = bpy.data.objects.get(self.building_name) or obj_a
            merge_parent = active_parent
            columns, err = _spawn_columns_between_objects(
                obj_a,
                obj_b,
                radius=self.radius,
                segments=self.segments,
                placement_mode=self.placement_mode,
                cursor_location=context.scene.cursor.location,
                z_offset=self.z_offset,
                bottom_gap=self.bottom_gap,
                top_gap=self.top_gap,
                count=self.count,
                spacing=self.spacing,
                row_axis=self.row_axis,
                parent_to_active=True,
                active_parent=active_parent,
                style=self.style,
            )

        elif self.source_mode == "FACE":
            building = bpy.data.objects.get(self.building_name)
            if not building or building.type != "MESH":
                self.report({"ERROR"}, "Объект не найден.")
                _restore_active_mode(context, prev_active, prev_mode)
                return {"CANCELLED"}
            merge_parent = building
            try:
                face_index = int(self.face_indices)
            except Exception:
                face_index = -1
            columns, err = _spawn_columns_on_face(
                building,
                face_index,
                radius=self.radius,
                segments=self.segments,
                count=self.count,
                spacing=self.spacing,
                face_offset=self.face_offset,
                z_offset=self.z_offset,
                height=self.height,
                style=self.style,
                parent_to_building=True,
            )
        else:
            self.report({"ERROR"}, "Перейдите в Edit Mode и выберите одну грань.")
            _restore_active_mode(context, prev_active, prev_mode)
            return {"CANCELLED"}

        if err:
            self.report({"ERROR"}, err)
            _restore_active_mode(context, prev_active, prev_mode)
            return {"CANCELLED"}
        if columns:
            merged = _merge_column_objects(columns, parent=merge_parent)
            if merged:
                columns = [merged]
            else:
                self.report({"ERROR"}, "Не удалось объединить колонны в один объект.")
                _restore_active_mode(context, prev_active, prev_mode)
                return {"CANCELLED"}
            self.created_obj_name = "|".join(c.name for c in columns if c and c.name in bpy.data.objects)

        _restore_active_mode(context, prev_active, prev_mode)
        return {"FINISHED"}
