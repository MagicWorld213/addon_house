import bpy
import bmesh
from mathutils import Vector

from .constants import EPS
from .utils import (
    _face_axes_bounds_world_by_index,
    _parent_keep_world,
    _set_object_basis_world,
)


def _unique_name(base: str) -> str:
    if base not in bpy.data.objects:
        return base
    i = 1
    while f"{base}.{i:03d}" in bpy.data.objects:
        i += 1
    return f"{base}.{i:03d}"


def _create_box_object(name: str, sx: float, sy: float, sz: float) -> bpy.types.Object:
    sx = max(EPS, float(sx))
    sy = max(EPS, float(sy))
    sz = max(EPS, float(sz))

    mesh = bpy.data.meshes.new(name + "_Mesh")
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)

    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)

    scale = Vector((sx, sy, sz))
    for v in bm.verts:
        v.co.x *= scale.x
        v.co.y *= scale.y
        v.co.z *= scale.z

    bm.normal_update()
    bm.to_mesh(mesh)
    bm.free()
    mesh.update()
    return obj


def _add_array_modifier(obj: bpy.types.Object, axis: str, spacing: float, count: int):
    m = obj.modifiers.new(name="Array", type="ARRAY")
    m.use_relative_offset = False
    m.use_constant_offset = True
    spacing = float(spacing)

    axis = axis.upper()
    if axis == "X":
        m.constant_offset_displace = (spacing, 0.0, 0.0)
    elif axis == "Y":
        m.constant_offset_displace = (0.0, spacing, 0.0)
    else:
        m.constant_offset_displace = (0.0, 0.0, spacing)

    m.count = max(1, int(count))
    return m


def _create_bar_with_array(
    name: str,
    parent: bpy.types.Object,
    x_axis_w: Vector,
    y_axis_w: Vector,
    z_axis_w: Vector,
    origin_w: Vector,
    sx: float,
    sy: float,
    sz: float,
    axis: str,
    spacing: float,
    count: int,
) -> bpy.types.Object:
    bar = _create_box_object(name, sx, sy, sz)
    _set_object_basis_world(bar, x_axis_w, y_axis_w, z_axis_w, origin_w)
    _add_array_modifier(bar, axis=axis, spacing=spacing, count=count)
    _parent_keep_world(bar, parent)
    return bar


def _merge_objects_evaluated(objs: list[bpy.types.Object], new_name: str) -> bpy.types.Object | None:
    objs = [o for o in objs if o and o.type == "MESH"]
    if not objs:
        return None

    depsgraph = bpy.context.evaluated_depsgraph_get()
    bm_out = bmesh.new()

    for o in objs:
        o_eval = o.evaluated_get(depsgraph)
        me_eval = o_eval.to_mesh(preserve_all_data_layers=False, depsgraph=depsgraph)
        if not me_eval:
            continue

        bm_tmp = bmesh.new()
        bm_tmp.from_mesh(me_eval)

        bm_tmp.verts.ensure_lookup_table()
        for v in bm_tmp.verts:
            v.co = o.matrix_world @ v.co

        bm_tmp.to_mesh(me_eval)
        bm_out.from_mesh(me_eval)

        bm_tmp.free()
        o_eval.to_mesh_clear()

    mesh = bpy.data.meshes.new(new_name + "_Mesh")
    bm_out.normal_update()
    bm_out.to_mesh(mesh)
    bm_out.free()
    mesh.update()

    merged = bpy.data.objects.new(new_name, mesh)
    bpy.context.collection.objects.link(merged)
    return merged


def _spawn_balcony_on_face(
    building: bpy.types.Object,
    face_index: int,
    width: float,
    depth: float,
    rail_h: float,
    slab_t: float,
    post_s: float,
    bar_t: float,
    bar_spacing: float,
    offset_x: float,
    offset_z: float,
    gap: float,
    infill_type: str,
    parent_to_building: bool = True,
):
    data, err = _face_axes_bounds_world_by_index(building, face_index)
    if err:
        return [], None, err

    center_w, n_w, right_w, up_w, min_u, max_u, min_v, _ = data

    width = max(EPS, float(width))
    depth = max(EPS, float(depth))
    rail_h = max(EPS, float(rail_h))
    slab_t = max(EPS, float(slab_t))
    post_s = max(EPS, float(post_s))
    bar_t = max(EPS, float(bar_t))
    bar_spacing = max(EPS, float(bar_spacing))
    g = max(0.0, float(gap))

    infill_type = (infill_type or "VERTICAL").upper()


    rail_t = post_s

    u_center = (min_u + max_u) * 0.5 + float(offset_x)
    v_base = float(min_v) + float(offset_z)
    base_w = center_w + right_w * u_center + up_w * v_base

    parent = bpy.data.objects.new(_unique_name("Balcony"), None)
    bpy.context.collection.objects.link(parent)
    _set_object_basis_world(parent, right_w, n_w, up_w, base_w)
    if parent_to_building:
        _parent_keep_world(parent, building)

    created: list[bpy.types.Object] = []


    slab = _create_box_object(_unique_name("Balcony_Slab"), width, depth, slab_t)
    slab_loc = base_w + n_w * (g + depth * 0.5) + up_w * (slab_t * 0.5)
    _set_object_basis_world(slab, right_w, n_w, up_w, slab_loc)
    _parent_keep_world(slab, parent)
    created.append(slab)


    xL = -width * 0.5 + post_s * 0.5
    xR = width * 0.5 - post_s * 0.5
    yB = g + post_s * 0.5
    yF = g + depth - post_s * 0.5

    post_h = max(EPS, rail_h - rail_t)
    post_center_z = slab_t + post_h * 0.5

    def _make_post(x, y):
        p = _create_box_object(_unique_name("Balcony_Post"), post_s, post_s, post_h)
        loc = base_w + right_w * x + n_w * y + up_w * post_center_z
        _set_object_basis_world(p, right_w, n_w, up_w, loc)
        _parent_keep_world(p, parent)
        created.append(p)

    _make_post(xL, yB)
    _make_post(xR, yB)
    _make_post(xL, yF)
    _make_post(xR, yF)


    top_center_z = slab_t + rail_h - rail_t * 0.5

    front = _create_box_object(_unique_name("Balcony_TopRail_Front"), width, rail_t, rail_t)
    front_loc = base_w + n_w * (g + depth - rail_t * 0.5) + up_w * top_center_z
    _set_object_basis_world(front, right_w, n_w, up_w, front_loc)
    _parent_keep_world(front, parent)
    created.append(front)

    side_len = max(EPS, depth - rail_t)
    side_center_y = g + side_len * 0.5

    left = _create_box_object(_unique_name("Balcony_TopRail_Left"), rail_t, side_len, rail_t)
    left_loc = base_w + right_w * (-width * 0.5 + rail_t * 0.5) + n_w * side_center_y + up_w * top_center_z
    _set_object_basis_world(left, right_w, n_w, up_w, left_loc)
    _parent_keep_world(left, parent)
    created.append(left)

    right = _create_box_object(_unique_name("Balcony_TopRail_Right"), rail_t, side_len, rail_t)
    right_loc = base_w + right_w * (width * 0.5 - rail_t * 0.5) + n_w * side_center_y + up_w * top_center_z
    _set_object_basis_world(right, right_w, n_w, up_w, right_loc)
    _parent_keep_world(right, parent)
    created.append(right)


    bar_h = max(EPS, rail_h - rail_t)
    bar_center_z = slab_t + bar_h * 0.5


    edge_clear_v = max(0.0, bar_t * 0.5 + 0.002)


    front_y = g + depth - rail_t * 0.5
    left_x = -width * 0.5 + rail_t * 0.5
    right_x = width * 0.5 - rail_t * 0.5


    left_post_inner_x = -width * 0.5 + post_s
    right_post_inner_x = width * 0.5 - post_s
    back_post_inner_y = g + post_s
    front_post_inner_y = g + depth - post_s


    if infill_type == "VERTICAL":
        left_inner_x = left_post_inner_x + edge_clear_v
        right_inner_x = right_post_inner_x - edge_clear_v
        back_inner_y = back_post_inner_y + edge_clear_v
        front_inner_y = front_post_inner_y - edge_clear_v


        left_c = left_inner_x + bar_t * 0.5
        right_c = right_inner_x - bar_t * 0.5
        avail = max(EPS, right_c - left_c)

        count_front = max(1, int(avail / bar_spacing) + 1)
        span = (count_front - 1) * bar_spacing
        margin = max(0.0, (avail - span) * 0.5)
        start_x = left_c + margin

        front_origin = base_w + right_w * start_x + n_w * front_y + up_w * bar_center_z
        front_bars = _create_bar_with_array(
            name=_unique_name("Balcony_Bars_Front_V"),
            parent=parent,
            x_axis_w=right_w,
            y_axis_w=n_w,
            z_axis_w=up_w,
            origin_w=front_origin,
            sx=bar_t,
            sy=bar_t,
            sz=bar_h,
            axis="X",
            spacing=bar_spacing,
            count=count_front,
        )
        created.append(front_bars)


        back_c = back_inner_y + bar_t * 0.5
        front_c = front_inner_y - bar_t * 0.5
        avail_y = max(EPS, front_c - back_c)

        count_side = max(1, int(avail_y / bar_spacing) + 1)
        span_y = (count_side - 1) * bar_spacing
        margin_y = max(0.0, (avail_y - span_y) * 0.5)
        start_y = back_c + margin_y

        left_origin = base_w + right_w * left_x + n_w * start_y + up_w * bar_center_z
        left_bars = _create_bar_with_array(
            name=_unique_name("Balcony_Bars_Left_V"),
            parent=parent,
            x_axis_w=right_w,
            y_axis_w=n_w,
            z_axis_w=up_w,
            origin_w=left_origin,
            sx=bar_t,
            sy=bar_t,
            sz=bar_h,
            axis="Y",
            spacing=bar_spacing,
            count=count_side,
        )
        created.append(left_bars)

        right_origin = base_w + right_w * right_x + n_w * start_y + up_w * bar_center_z
        right_bars = _create_bar_with_array(
            name=_unique_name("Balcony_Bars_Right_V"),
            parent=parent,
            x_axis_w=right_w,
            y_axis_w=n_w,
            z_axis_w=up_w,
            origin_w=right_origin,
            sx=bar_t,
            sy=bar_t,
            sz=bar_h,
            axis="Y",
            spacing=bar_spacing,
            count=count_side,
        )
        created.append(right_bars)


    if infill_type == "HORIZONTAL":
        z_bot = slab_t + bar_t * 0.5
        z_top = slab_t + bar_h - bar_t * 0.5
        avail_z = max(EPS, z_top - z_bot)

        count_z = max(1, int(avail_z / bar_spacing) + 1)
        span_z = (count_z - 1) * bar_spacing
        margin_z = max(0.0, (avail_z - span_z) * 0.5)
        start_z = z_bot + margin_z

        len_x = max(EPS, (right_post_inner_x - left_post_inner_x))
        x_center = (left_post_inner_x + right_post_inner_x) * 0.5

        len_y = max(EPS, (front_post_inner_y - back_post_inner_y))
        y_center = (back_post_inner_y + front_post_inner_y) * 0.5

        len_x += EPS * 10.0
        len_y += EPS * 10.0


        front_h_origin = base_w + right_w * x_center + n_w * front_y + up_w * start_z
        front_h = _create_bar_with_array(
            name=_unique_name("Balcony_Bars_Front_H"),
            parent=parent,
            x_axis_w=right_w,
            y_axis_w=n_w,
            z_axis_w=up_w,
            origin_w=front_h_origin,
            sx=len_x,
            sy=bar_t,
            sz=bar_t,
            axis="Z",
            spacing=bar_spacing,
            count=count_z,
        )
        created.append(front_h)


        left_h_origin = base_w + right_w * left_x + n_w * y_center + up_w * start_z
        left_h = _create_bar_with_array(
            name=_unique_name("Balcony_Bars_Left_H"),
            parent=parent,
            x_axis_w=right_w,
            y_axis_w=n_w,
            z_axis_w=up_w,
            origin_w=left_h_origin,
            sx=bar_t,
            sy=len_y,
            sz=bar_t,
            axis="Z",
            spacing=bar_spacing,
            count=count_z,
        )
        created.append(left_h)

        right_h_origin = base_w + right_w * right_x + n_w * y_center + up_w * start_z
        right_h = _create_bar_with_array(
            name=_unique_name("Balcony_Bars_Right_H"),
            parent=parent,
            x_axis_w=right_w,
            y_axis_w=n_w,
            z_axis_w=up_w,
            origin_w=right_h_origin,
            sx=bar_t,
            sy=len_y,
            sz=bar_t,
            axis="Z",
            spacing=bar_spacing,
            count=count_z,
        )
        created.append(right_h)

    return created, parent, None
