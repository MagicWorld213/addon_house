from .constants import (
    BUILDING_DEFAULT_FLOORS,
    BUILDING_DEFAULT_WIDTH,
    BUILDING_DEFAULT_DEPTH,
    BUILDING_DEFAULT_FLOOR_HEIGHT,
    BUILDING_DEFAULT_LOC_X,
    BUILDING_DEFAULT_LOC_Y,
    BUILDING_DEFAULT_PLUS_ARM_RATIO,
    BUILDING_DEFAULT_PLUS_ARM_WIDTH,
    BUILDING_DEFAULT_PLUS_SIZE_MODE,
    BUILDING_DEFAULT_L_ARM_WIDTH,
    BUILDING_DEFAULT_L_VERTICAL_WIDTH,
    BUILDING_DEFAULT_L_HORIZONTAL_WIDTH,
    BUILDING_DEFAULT_L_X_LENGTH,
    BUILDING_DEFAULT_L_Y_LENGTH,
    BUILDING_DEFAULT_U_ARM_WIDTH,
    BUILDING_DEFAULT_U_LEFT_ARM_WIDTH,
    BUILDING_DEFAULT_U_RIGHT_ARM_WIDTH,
    BUILDING_DEFAULT_U_SUPPORT_DEPTH,
    BUILDING_DEFAULT_U_LEFT_LENGTH,
    BUILDING_DEFAULT_U_RIGHT_LENGTH,
    DOOR_DEFAULT_SCALE,
    WINDOW_DEFAULT_SCALE,
    ROOF_DEFAULT_OVERHANG,
    ROOF_DEFAULT_OVERHANG_X,
    ROOF_DEFAULT_OVERHANG_Y,
    ROOF_DEFAULT_THICKNESS,
    ROOF_DEFAULT_HEIGHT,
    ROOF_DEFAULT_RIDGE_AXIS,
    ROOF_DEFAULT_GABLE_TYPE,
    BALCONY_DEFAULT_WIDTH,
    BALCONY_DEFAULT_DEPTH,
    BALCONY_DEFAULT_RAIL_HEIGHT,
    BALCONY_DEFAULT_SLAB_THICKNESS,
    BALCONY_DEFAULT_POST_SIZE,
    BALCONY_DEFAULT_BAR_THICKNESS,
    BALCONY_DEFAULT_BAR_SPACING,
    PLATFORM_DEFAULT_OVERHANG,
    PLATFORM_DEFAULT_OFFSET_X,
    PLATFORM_DEFAULT_OFFSET_Y,
    PLATFORM_DEFAULT_HEIGHT,
    PLATFORM_DEFAULT_BORDER_INSET,
    COLUMN_DEFAULT_RADIUS,
    COLUMN_DEFAULT_SEGMENTS,
    COLUMN_DEFAULT_COUNT,
    COLUMN_DEFAULT_SPACING,
    COLUMN_DEFAULT_FACE_OFFSET,
    COLUMN_DEFAULT_Z_OFFSET,
)


def _upd_reset_building(self, context):
    if not getattr(self, "reset_building", False):
        return
    self.floors = BUILDING_DEFAULT_FLOORS
    self.width = BUILDING_DEFAULT_WIDTH
    self.depth = BUILDING_DEFAULT_DEPTH
    self.floor_height = BUILDING_DEFAULT_FLOOR_HEIGHT
    self.loc_x = BUILDING_DEFAULT_LOC_X
    self.loc_y = BUILDING_DEFAULT_LOC_Y
    if hasattr(self, "plus_size_mode"):
        self.plus_size_mode = BUILDING_DEFAULT_PLUS_SIZE_MODE
    if hasattr(self, "plus_arm_ratio"):
        self.plus_arm_ratio = BUILDING_DEFAULT_PLUS_ARM_RATIO
    if hasattr(self, "plus_arm_width"):
        self.plus_arm_width = BUILDING_DEFAULT_PLUS_ARM_WIDTH
    if hasattr(self, "l_arm_width"):
        self.l_arm_width = BUILDING_DEFAULT_L_ARM_WIDTH
    if hasattr(self, "l_vertical_width"):
        self.l_vertical_width = BUILDING_DEFAULT_L_VERTICAL_WIDTH
    if hasattr(self, "l_horizontal_width"):
        self.l_horizontal_width = BUILDING_DEFAULT_L_HORIZONTAL_WIDTH
    if hasattr(self, "l_x_length"):
        self.l_x_length = BUILDING_DEFAULT_L_X_LENGTH
    if hasattr(self, "l_y_length"):
        self.l_y_length = BUILDING_DEFAULT_L_Y_LENGTH
    if hasattr(self, "u_arm_width"):
        self.u_arm_width = BUILDING_DEFAULT_U_ARM_WIDTH
    if hasattr(self, "u_left_arm_width"):
        self.u_left_arm_width = BUILDING_DEFAULT_U_LEFT_ARM_WIDTH
    if hasattr(self, "u_right_arm_width"):
        self.u_right_arm_width = BUILDING_DEFAULT_U_RIGHT_ARM_WIDTH
    if hasattr(self, "u_support_depth"):
        self.u_support_depth = BUILDING_DEFAULT_U_SUPPORT_DEPTH
    if hasattr(self, "u_left_length"):
        self.u_left_length = BUILDING_DEFAULT_U_LEFT_LENGTH
    if hasattr(self, "u_right_length"):
        self.u_right_length = BUILDING_DEFAULT_U_RIGHT_LENGTH
    self.reset_building = False


def _upd_reset_door_scale(self, context):
    if not getattr(self, "reset_scale", False):
        return
    if hasattr(self, "count"):
        self.count = 1
    self.scale = (DOOR_DEFAULT_SCALE.x, DOOR_DEFAULT_SCALE.y, DOOR_DEFAULT_SCALE.z)
    self.reset_scale = False


def _upd_reset_window_scale(self, context):
    if not getattr(self, "reset_scale", False):
        return
    if hasattr(self, "count"):
        self.count = 1
    self.scale = (WINDOW_DEFAULT_SCALE.x, WINDOW_DEFAULT_SCALE.y, WINDOW_DEFAULT_SCALE.z)
    self.reset_scale = False


def _upd_reset_roof(self, context):
    if not getattr(self, "reset_roof", False):
        return

    try:
        rt = self.roof_type_lu
    except Exception:
        try:
            rt = self.roof_type
        except Exception:
            rt = "PYRAMID"
    self.overhang = ROOF_DEFAULT_OVERHANG

    if rt != "CONE":
        self.overhang_x = ROOF_DEFAULT_OVERHANG_X
        self.overhang_y = ROOF_DEFAULT_OVERHANG_Y

    if rt == "FLAT":
        self.thickness = ROOF_DEFAULT_THICKNESS
    else:
        self.roof_height = ROOF_DEFAULT_HEIGHT

    if rt == "GABLE":
        if hasattr(self, "ridge_axis"):
            self.ridge_axis = ROOF_DEFAULT_RIDGE_AXIS
        if hasattr(self, "gable_type_lu"):
            self.gable_type_lu = ROOF_DEFAULT_GABLE_TYPE

    self.reset_roof = False


def _upd_reset_balcony(self, context):
    if not getattr(self, "reset_balcony", False):
        return

    self.width = BALCONY_DEFAULT_WIDTH
    self.depth = BALCONY_DEFAULT_DEPTH
    self.rail_height = BALCONY_DEFAULT_RAIL_HEIGHT
    self.slab_thickness = BALCONY_DEFAULT_SLAB_THICKNESS
    self.post_size = BALCONY_DEFAULT_POST_SIZE
    self.bar_thickness = BALCONY_DEFAULT_BAR_THICKNESS
    self.bar_spacing = BALCONY_DEFAULT_BAR_SPACING
    if hasattr(self, "infill_type"):
        self.infill_type = "VERTICAL"
    if hasattr(self, "offset_x"):
        self.offset_x = 0.0
    if hasattr(self, "offset_z"):
        self.offset_z = 0.0

    self.reset_balcony = False


def _upd_platform_overhang(self, context):


    try:
        value = max(0.0, float(getattr(self, "overhang", PLATFORM_DEFAULT_OVERHANG)))
        self.offset_x = value
        self.offset_y = value
    except Exception:
        pass

def _upd_reset_platform(self, context):
    if not getattr(self, "reset_platform", False):
        return

    if hasattr(self, "overhang"):
        self.overhang = PLATFORM_DEFAULT_OVERHANG
    self.offset_x = PLATFORM_DEFAULT_OFFSET_X
    self.offset_y = PLATFORM_DEFAULT_OFFSET_Y
    self.height = PLATFORM_DEFAULT_HEIGHT
    if hasattr(self, "border_inset"):
        self.border_inset = PLATFORM_DEFAULT_BORDER_INSET

    self.reset_platform = False


def _upd_reset_column(self, context):
    if not getattr(self, "reset_column", False):
        return

    self.radius = COLUMN_DEFAULT_RADIUS
    self.segments = COLUMN_DEFAULT_SEGMENTS
    self.count = COLUMN_DEFAULT_COUNT
    self.spacing = COLUMN_DEFAULT_SPACING
    if hasattr(self, "face_offset"):
        self.face_offset = COLUMN_DEFAULT_FACE_OFFSET
    if hasattr(self, "z_offset"):
        self.z_offset = COLUMN_DEFAULT_Z_OFFSET
    if hasattr(self, "bottom_gap"):
        self.bottom_gap = 0.0
    if hasattr(self, "top_gap"):
        self.top_gap = 0.0
    if hasattr(self, "height"):
        try:
            self.height = max(0.01, float(getattr(self, "default_height", self.height)))
        except Exception:
            pass

    self.reset_column = False
