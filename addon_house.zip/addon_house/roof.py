import bpy
import bmesh
from mathutils import Vector

from .constants import EPS
from .utils import (
    _building_bbox_world,
    _ensure_object_mode,
    _parent_keep_world,
)


def _create_mesh_object(name: str = "Roof"):
    mesh = bpy.data.meshes.new(name + "Mesh")
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    return obj, mesh


def _poly_center_xy(points: list[Vector]) -> Vector:
    if not points:
        return Vector((0.0, 0.0, 0.0))
    return sum(points, Vector()) / float(len(points))


def _rect_from_bounds(min_x, max_x, min_y, max_y, z):
    return [
        Vector((min_x, min_y, z)),
        Vector((max_x, min_y, z)),
        Vector((max_x, max_y, z)),
        Vector((min_x, max_y, z)),
    ]


def _bounds_from_points(points: list[Vector]):
    min_x = min(p.x for p in points)
    max_x = max(p.x for p in points)
    min_y = min(p.y for p in points)
    max_y = max(p.y for p in points)
    min_z = min(p.z for p in points)
    max_z = max(p.z for p in points)
    return min_x, max_x, min_y, max_y, min_z, max_z


def _expanded_rect_or_convex_polygon_xy(points: list[Vector], ox: float, oy: float, z: float) -> list[Vector]:
    ox = max(0.0, float(ox))
    oy = max(0.0, float(oy))
    c = _poly_center_xy(points)
    out = []
    for p in points:
        sx = 1.0 if p.x >= c.x else -1.0
        sy = 1.0 if p.y >= c.y else -1.0
        out.append(Vector((p.x + sx * ox, p.y + sy * oy, z)))
    return out


def _unique_sorted(vals, ndigits=5):
    return sorted({round(float(v), ndigits) for v in vals})


def _plus_params_from_polygon(points: list[Vector]):
    if len(points) < 8:
        return None

    min_x, max_x, min_y, max_y, _, _ = _bounds_from_points(points)
    span_x = max_x - min_x
    span_y = max_y - min_y
    if span_x <= EPS or span_y <= EPS:
        return None

    cx = (min_x + max_x) * 0.5
    cy = (min_y + max_y) * 0.5
    xs = _unique_sorted([p.x for p in points])
    ys = _unique_sorted([p.y for p in points])

    inner_x = [abs(x - cx) for x in xs if min_x + EPS < x < max_x - EPS and abs(x - cx) > EPS]
    inner_y = [abs(y - cy) for y in ys if min_y + EPS < y < max_y - EPS and abs(y - cy) > EPS]
    if not inner_x or not inner_y:
        return None

    tx = min(inner_x)
    ty = min(inner_y)
    if tx <= EPS or ty <= EPS:
        return None
    if tx >= span_x * 0.49 or ty >= span_y * 0.49:
        return None

    return {
        "cx": cx,
        "cy": cy,
        "min_x": min_x,
        "max_x": max_x,
        "min_y": min_y,
        "max_y": max_y,
        "tx": tx,
        "ty": ty,
    }


def _polygon_area_xy(points: list[Vector]) -> float:
    area = 0.0
    n = len(points)
    if n < 3:
        return 0.0
    for i in range(n):
        a = points[i]
        b = points[(i + 1) % n]
        area += a.x * b.y - b.x * a.y
    return area * 0.5


def _without_collinear_xy(points: list[Vector], eps: float = EPS) -> list[Vector]:
    if not points:
        return []

    cleaned = []
    for p in points:
        v = Vector((float(p.x), float(p.y), float(p.z)))
        if not cleaned or (v - cleaned[-1]).length > eps:
            cleaned.append(v)
    if len(cleaned) > 1 and (cleaned[0] - cleaned[-1]).length <= eps:
        cleaned.pop()

    changed = True
    while changed and len(cleaned) >= 3:
        changed = False
        out = []
        n = len(cleaned)
        for i in range(n):
            a = cleaned[(i - 1) % n]
            b = cleaned[i]
            c = cleaned[(i + 1) % n]
            ab = Vector((b.x - a.x, b.y - a.y, 0.0))
            bc = Vector((c.x - b.x, c.y - b.y, 0.0))
            cross = ab.x * bc.y - ab.y * bc.x
            if abs(cross) <= eps and ab.length > eps and bc.length > eps:

                changed = True
                continue
            out.append(b)
        cleaned = out
    return cleaned


def _concave_corner_count_xy(points: list[Vector]) -> int:
    pts = _without_collinear_xy(points)
    n = len(pts)
    if n < 4:
        return 0

    area = _polygon_area_xy(pts)
    if abs(area) <= EPS:
        return 0

    sign = 1.0 if area > 0.0 else -1.0
    concave = 0
    for i in range(n):
        a = pts[(i - 1) % n]
        b = pts[i]
        c = pts[(i + 1) % n]
        ab = Vector((b.x - a.x, b.y - a.y, 0.0))
        bc = Vector((c.x - b.x, c.y - b.y, 0.0))
        cross = ab.x * bc.y - ab.y * bc.x
        if cross * sign < -EPS:
            concave += 1
    return concave


def _looks_like_plus_polygon(points: list[Vector]) -> bool:


    simplified = _without_collinear_xy(points)
    if len(simplified) < 8:
        return False
    if _concave_corner_count_xy(simplified) < 2:
        return False
    return _plus_params_from_polygon(simplified) is not None


def _should_use_plus_roof(obj: bpy.types.Object, points: list[Vector]) -> bool:
    base_type = str(obj.get("house_base_type", "")).upper().strip() if obj else ""
    return base_type == "PLUS" and _looks_like_plus_polygon(points)


def _plus_footprint_points(points: list[Vector], ox: float, oy: float, z: float) -> list[Vector] | None:
    params = _plus_params_from_polygon(points)
    if not params:
        return None

    cx = params["cx"]
    cy = params["cy"]
    min_x = params["min_x"] - max(0.0, float(ox))
    max_x = params["max_x"] + max(0.0, float(ox))
    min_y = params["min_y"] - max(0.0, float(oy))
    max_y = params["max_y"] + max(0.0, float(oy))
    tx = params["tx"] + max(0.0, float(ox))
    ty = params["ty"] + max(0.0, float(oy))


    return [
        Vector((cx - tx, min_y, z)),
        Vector((cx + tx, min_y, z)),
        Vector((cx + tx, cy - ty, z)),
        Vector((max_x, cy - ty, z)),
        Vector((max_x, cy + ty, z)),
        Vector((cx + tx, cy + ty, z)),
        Vector((cx + tx, max_y, z)),
        Vector((cx - tx, max_y, z)),
        Vector((cx - tx, cy + ty, z)),
        Vector((min_x, cy + ty, z)),
        Vector((min_x, cy - ty, z)),
        Vector((cx - tx, cy - ty, z)),
    ]


def _plus_gable_rects(points: list[Vector], ox: float, oy: float, z: float):
    params = _plus_params_from_polygon(points)
    if not params:
        return []

    cx = params["cx"]
    cy = params["cy"]
    min_x = params["min_x"] - max(0.0, float(ox))
    max_x = params["max_x"] + max(0.0, float(ox))
    min_y = params["min_y"] - max(0.0, float(oy))
    max_y = params["max_y"] + max(0.0, float(oy))
    tx = params["tx"] + max(0.0, float(ox))
    ty = params["ty"] + max(0.0, float(oy))


    e = max(EPS * 10.0, 0.0001)
    return [
        (cx - tx, cx + tx, cy - ty, cy + ty, z),
        (cx - tx, cx + tx, min_y, cy - ty + e, z),
        (cx - tx, cx + tx, cy + ty - e, max_y, z),
        (min_x, cx - tx + e, cy - ty, cy + ty, z),
        (cx + tx - e, max_x, cy - ty, cy + ty, z),
    ]


def _add_pyramid_to_bmesh(bm, points: list[Vector], apex: Vector):
    verts = [bm.verts.new((p.x, p.y, p.z)) for p in points]
    apex_v = bm.verts.new((apex.x, apex.y, apex.z))
    base_c = bm.verts.new((apex.x, apex.y, points[0].z))
    n = len(verts)


    for i in range(n):
        bm.faces.new((verts[i], verts[(i + 1) % n], apex_v))


    for i in range(n):
        try:
            bm.faces.new((base_c, verts[(i + 1) % n], verts[i]))
        except ValueError:
            pass


def _add_flat_prism_to_bmesh(bm, points: list[Vector], thickness: float):
    thickness = max(EPS, float(thickness))
    bottom = [bm.verts.new((p.x, p.y, p.z)) for p in points]
    top = [bm.verts.new((p.x, p.y, p.z + thickness)) for p in points]
    c = _poly_center_xy(points)
    bottom_c = bm.verts.new((c.x, c.y, points[0].z))
    top_c = bm.verts.new((c.x, c.y, points[0].z + thickness))
    n = len(points)

    for i in range(n):
        bm.faces.new((bottom[i], bottom[(i + 1) % n], top[(i + 1) % n], top[i]))


    for i in range(n):
        try:
            bm.faces.new((bottom_c, bottom[i], bottom[(i + 1) % n]))
        except ValueError:
            pass
        try:
            bm.faces.new((top_c, top[(i + 1) % n], top[i]))
        except ValueError:
            pass


def _add_rect_flat_prism_to_bmesh(bm, min_x, max_x, min_y, max_y, z, thickness: float):
    if max_x - min_x <= EPS or max_y - min_y <= EPS:
        return
    thickness = max(EPS, float(thickness))
    z0 = float(z)
    z1 = z0 + thickness

    b0 = bm.verts.new((min_x, min_y, z0))
    b1 = bm.verts.new((max_x, min_y, z0))
    b2 = bm.verts.new((max_x, max_y, z0))
    b3 = bm.verts.new((min_x, max_y, z0))
    t0 = bm.verts.new((min_x, min_y, z1))
    t1 = bm.verts.new((max_x, min_y, z1))
    t2 = bm.verts.new((max_x, max_y, z1))
    t3 = bm.verts.new((min_x, max_y, z1))

    bm.faces.new((b3, b2, b1, b0))
    bm.faces.new((t0, t1, t2, t3))
    bm.faces.new((b0, b1, t1, t0))
    bm.faces.new((b1, b2, t2, t1))
    bm.faces.new((b2, b3, t3, t2))
    bm.faces.new((b3, b0, t0, t3))


def _add_rect_gable_to_bmesh(bm, min_x, max_x, min_y, max_y, z, height, ridge_axis="X"):
    if max_x - min_x <= EPS or max_y - min_y <= EPS:
        return

    v0 = bm.verts.new((min_x, min_y, z))
    v1 = bm.verts.new((max_x, min_y, z))
    v2 = bm.verts.new((max_x, max_y, z))
    v3 = bm.verts.new((min_x, max_y, z))
    cx = (min_x + max_x) * 0.5
    cy = (min_y + max_y) * 0.5
    height = max(EPS, float(height))

    if ridge_axis == "X":
        r0 = bm.verts.new((min_x, cy, z + height))
        r1 = bm.verts.new((max_x, cy, z + height))
        bm.faces.new((v0, v1, r1, r0))
        bm.faces.new((v3, v2, r1, r0))
        bm.faces.new((v0, v3, r0))
        bm.faces.new((v1, v2, r1))
    else:
        r0 = bm.verts.new((cx, min_y, z + height))
        r1 = bm.verts.new((cx, max_y, z + height))
        bm.faces.new((v0, v3, r1, r0))
        bm.faces.new((v1, v2, r1, r0))
        bm.faces.new((v0, v1, r0))
        bm.faces.new((v3, v2, r1))

    try:
        bm.faces.new((v3, v2, v1, v0))
    except ValueError:
        pass


def _add_rect_pyramid_section_to_bmesh(bm, min_x, max_x, min_y, max_y, z, height) -> bool:
    if max_x - min_x <= EPS or max_y - min_y <= EPS:
        return False
    apex = Vector(((min_x + max_x) * 0.5, (min_y + max_y) * 0.5, z + max(EPS, float(height))))
    _add_pyramid_to_bmesh(bm, _rect_from_bounds(min_x, max_x, min_y, max_y, z), apex)
    return True


def _add_quad_pyramid_patch_to_bmesh(bm, min_x, max_x, min_y, max_y, z, apex: Vector) -> bool:
    if max_x - min_x <= EPS or max_y - min_y <= EPS:
        return False
    v0 = bm.verts.new((min_x, min_y, z))
    v1 = bm.verts.new((max_x, min_y, z))
    v2 = bm.verts.new((max_x, max_y, z))
    v3 = bm.verts.new((min_x, max_y, z))
    va = bm.verts.new((apex.x, apex.y, apex.z))
    made = False
    for seq in ((v0, v1, va), (v1, v2, va), (v2, v3, va), (v3, v0, va)):
        try:
            bm.faces.new(seq)
            made = True
        except ValueError:
            pass
    try:
        bm.faces.new((v3, v2, v1, v0))
    except ValueError:
        pass
    return made


def _add_rect_hip_to_bmesh(bm, min_x, max_x, min_y, max_y, z, height, ridge_axis="AUTO") -> bool:
    w = float(max_x) - float(min_x)
    d = float(max_y) - float(min_y)
    if w <= EPS or d <= EPS:
        return False

    height = max(EPS, float(height))
    axis = str(ridge_axis or "AUTO").upper().strip()
    if axis == "AUTO":
        axis = "X" if w >= d else "Y"

    def face(seq):
        try:
            bm.faces.new(seq)
            return True
        except ValueError:
            return False

    v0 = bm.verts.new((min_x, min_y, z))
    v1 = bm.verts.new((max_x, min_y, z))
    v2 = bm.verts.new((max_x, max_y, z))
    v3 = bm.verts.new((min_x, max_y, z))
    made = False

    if axis == "Y":
        inset = min(w * 0.5, d * 0.5)
        y0 = min_y + inset
        y1 = max_y - inset
        cx = (min_x + max_x) * 0.5
        if y1 - y0 <= EPS:
            a = bm.verts.new((cx, (min_y + max_y) * 0.5, z + height))
            made |= face((v0, v1, a))
            made |= face((v1, v2, a))
            made |= face((v2, v3, a))
            made |= face((v3, v0, a))
        else:
            r0 = bm.verts.new((cx, y0, z + height))
            r1 = bm.verts.new((cx, y1, z + height))
            made |= face((v0, v1, r0))
            made |= face((v1, v2, r1, r0))
            made |= face((v2, v3, r1))
            made |= face((v3, v0, r0, r1))
    else:
        inset = min(w * 0.5, d * 0.5)
        x0 = min_x + inset
        x1 = max_x - inset
        cy = (min_y + max_y) * 0.5
        if x1 - x0 <= EPS:
            a = bm.verts.new(((min_x + max_x) * 0.5, cy, z + height))
            made |= face((v0, v1, a))
            made |= face((v1, v2, a))
            made |= face((v2, v3, a))
            made |= face((v3, v0, a))
        else:
            r0 = bm.verts.new((x0, cy, z + height))
            r1 = bm.verts.new((x1, cy, z + height))
            made |= face((v0, v1, r1, r0))
            made |= face((v1, v2, r1))
            made |= face((v2, v3, r0, r1))
            made |= face((v3, v0, r0))


    face((v3, v2, v1, v0))
    return bool(made)


def _add_l_section_hip_roofs_to_bmesh(bm, points: list[Vector], ox: float, oy: float, z: float, height: float) -> bool:
    p = _l_params_from_polygon(points)
    if not p:
        return False
    ox = max(0.0, float(ox))
    oy = max(0.0, float(oy))
    x0 = p["min_x"] - ox
    x1 = p["inner_x"] + ox
    x2 = p["max_x"] + ox
    y0 = p["min_y"] - oy
    y1 = p["inner_y"] + oy
    y2 = p["max_y"] + oy
    made = False
    made |= _add_rect_hip_to_bmesh(bm, x0, x2, y0, y1, z, height, "X")
    made |= _add_rect_hip_to_bmesh(bm, x0, x1, y1, y2, z, height, "Y")
    return bool(made)


def _add_u_section_hip_roofs_to_bmesh(bm, points: list[Vector], ox: float, oy: float, z: float, height: float) -> bool:
    p = _u_params_from_polygon(points)
    if not p:
        return False
    ox = max(0.0, float(ox))
    oy = max(0.0, float(oy))
    x0 = p["min_x"] - ox
    x1 = p["left_inner"] + ox
    x2 = p["right_inner"] - ox
    x3 = p["max_x"] + ox
    y0 = p["min_y"] - oy
    ys = p["support_y"] + oy
    yl = p["left_top"] + oy
    yr = p["right_top"] + oy
    if not (x0 + EPS < x1 < x2 < x3 - EPS):
        return False
    made = False
    made |= _add_rect_hip_to_bmesh(bm, x0, x3, y0, ys, z, height, "X")
    made |= _add_rect_hip_to_bmesh(bm, x0, x1, ys, yl, z, height, "Y")
    made |= _add_rect_hip_to_bmesh(bm, x2, x3, ys, yr, z, height, "Y")
    return bool(made)


def _add_l_type_b_gable_to_bmesh(
    bm,
    points: list[Vector],
    ox: float,
    oy: float,
    z: float,
    height: float,
) -> bool:

    p = _l_params_from_polygon(points)
    if not p:
        return False

    ox = max(0.0, float(ox))
    oy = max(0.0, float(oy))
    height = max(EPS, float(height))

    x0 = p["min_x"] - ox
    x1 = p["inner_x"] + ox
    x2 = p["max_x"] + ox

    y0 = p["min_y"] - oy
    y1 = p["inner_y"] + oy
    y2 = p["max_y"] + oy

    if x1 <= x0 + EPS or x2 <= x1 + EPS:
        return False
    if y1 <= y0 + EPS or y2 <= y1 + EPS:
        return False


    cx = (x0 + x1) * 0.5
    cy = (y0 + y1) * 0.5

    main_half_depth = max(EPS, (y1 - y0) * 0.5)
    side_half_width = max(EPS, (x1 - x0) * 0.5)


    xs = _unique_sorted([x0, cx, x1, x2])
    ys = _unique_sorted([y0, cy, y1, y2])

    def in_main(x: float, y: float) -> bool:
        return (
            x0 - EPS <= x <= x2 + EPS
            and y0 - EPS <= y <= y1 + EPS
        )

    def in_side(x: float, y: float) -> bool:
        return (
            x0 - EPS <= x <= x1 + EPS
            and y0 - EPS <= y <= y2 + EPS
        )

    def cell_inside(i: int, j: int) -> bool:
        mx = (xs[i] + xs[i + 1]) * 0.5
        my = (ys[j] + ys[j + 1]) * 0.5
        return in_main(mx, my) or in_side(mx, my)

    def roof_z(x: float, y: float) -> float:
        factors = []


        if in_main(x, y):
            f_main = 1.0 - abs(y - cy) / main_half_depth
            factors.append(max(0.0, min(1.0, f_main)))


        if in_side(x, y):
            f_side = 1.0 - abs(x - cx) / side_half_width
            factors.append(max(0.0, min(1.0, f_side)))

        if not factors:
            return z


        return z + height * max(factors)

    top_verts = {}
    bottom_verts = {}
    edge_counts = {}

    def top_vertex(i: int, j: int):
        key = (i, j)
        if key not in top_verts:
            x = xs[i]
            y = ys[j]
            top_verts[key] = bm.verts.new((x, y, roof_z(x, y)))
        return top_verts[key]

    def bottom_vertex(i: int, j: int):
        key = (i, j)
        if key not in bottom_verts:
            x = xs[i]
            y = ys[j]
            bottom_verts[key] = bm.verts.new((x, y, z))
        return bottom_verts[key]

    def add_edge(a, b):
        key = tuple(sorted((a, b)))
        edge_counts[key] = edge_counts.get(key, 0) + 1

    def face(seq):
        try:
            bm.faces.new(seq)
            return True
        except ValueError:
            return False

    def is_center_key(key) -> bool:
        i, j = key
        return abs(xs[i] - cx) <= EPS and abs(ys[j] - cy) <= EPS

    def use_center_diagonal(i: int, j: int):
        v00_key = (i, j)
        v10_key = (i + 1, j)
        v11_key = (i + 1, j + 1)
        v01_key = (i, j + 1)

        if is_center_key(v00_key) or is_center_key(v11_key):
            return "v00_v11"

        if is_center_key(v10_key) or is_center_key(v01_key):
            return "v10_v01"

        return "v00_v11"

    made = False

    for i in range(len(xs) - 1):
        for j in range(len(ys) - 1):
            if not cell_inside(i, j):
                continue

            v00 = top_vertex(i, j)
            v10 = top_vertex(i + 1, j)
            v11 = top_vertex(i + 1, j + 1)
            v01 = top_vertex(i, j + 1)

            diag = use_center_diagonal(i, j)

            if diag == "v10_v01":
                made |= face((v00, v10, v01))
                made |= face((v10, v11, v01))
            else:
                made |= face((v00, v10, v11))
                made |= face((v00, v11, v01))

            b00 = bottom_vertex(i, j)
            b10 = bottom_vertex(i + 1, j)
            b11 = bottom_vertex(i + 1, j + 1)
            b01 = bottom_vertex(i, j + 1)


            face((b01, b11, b10, b00))

            add_edge((i, j), (i + 1, j))
            add_edge((i + 1, j), (i + 1, j + 1))
            add_edge((i + 1, j + 1), (i, j + 1))
            add_edge((i, j + 1), (i, j))


    for edge, count in edge_counts.items():
        if count != 1:
            continue

        a, b = edge

        ta = top_vertex(*a)
        tb = top_vertex(*b)

        ba = bottom_vertex(*a)
        bb = bottom_vertex(*b)

        face((ba, bb, tb, ta))

    return bool(made)


def _add_u_type_b_gable_to_bmesh(bm, points: list[Vector], ox: float, oy: float, z: float, height: float) -> bool:
    p = _u_params_from_polygon(points)
    if not p:
        return False
    ox = max(0.0, float(ox))
    oy = max(0.0, float(oy))
    x0 = p["min_x"] - ox
    x1 = p["left_inner"] + ox
    x2 = p["right_inner"] - ox
    x3 = p["max_x"] + ox
    y0 = p["min_y"] - oy
    ys = p["support_y"] + oy
    yl = p["left_top"] + oy
    yr = p["right_top"] + oy
    if not (x0 + EPS < x1 < x2 < x3 - EPS):
        return False
    made = False
    before = len(bm.faces)
    _add_rect_gable_to_bmesh(bm, x0, x3, y0, ys, z, height, "X")
    made |= len(bm.faces) > before
    before = len(bm.faces)
    _add_rect_gable_to_bmesh(bm, x0, x1, ys, yl, z, height, "Y")
    made |= len(bm.faces) > before
    before = len(bm.faces)
    _add_rect_gable_to_bmesh(bm, x2, x3, ys, yr, z, height, "Y")
    made |= len(bm.faces) > before
    return bool(made)


def _add_l_section_hip_to_bmesh(bm, points: list[Vector], ox: float, oy: float, z: float, height: float) -> bool:
    p = _l_params_from_polygon(points)
    if not p:
        return False
    ox = max(0.0, float(ox))
    oy = max(0.0, float(oy))
    x0 = p["min_x"] - ox
    x1 = p["inner_x"] + ox
    x2 = p["max_x"] + ox
    y0 = p["min_y"] - oy
    y1 = p["inner_y"] + oy
    y2 = p["max_y"] + oy

    made = False
    made |= _add_rect_pyramid_section_to_bmesh(bm, x0, x1, y0, y1, z, height)
    made |= _add_rect_pyramid_section_to_bmesh(bm, x1, x2, y0, y1, z, height)
    made |= _add_rect_pyramid_section_to_bmesh(bm, x0, x1, y1, y2, z, height)
    return bool(made)


def _add_u_section_hip_to_bmesh(bm, points: list[Vector], ox: float, oy: float, z: float, height: float) -> bool:
    p = _u_params_from_polygon(points)
    if not p:
        return False
    ox = max(0.0, float(ox))
    oy = max(0.0, float(oy))
    x0 = p["min_x"] - ox
    x1 = p["left_inner"] + ox
    x2 = p["right_inner"] - ox
    x3 = p["max_x"] + ox
    y0 = p["min_y"] - oy
    ys = p["support_y"] + oy
    yl = p["left_top"] + oy
    yr = p["right_top"] + oy


    mid_x1 = min(x1, x2)
    mid_x2 = max(x1, x2)

    made = False
    made |= _add_rect_pyramid_section_to_bmesh(bm, x0, x1, y0, ys, z, height)
    made |= _add_rect_pyramid_section_to_bmesh(bm, mid_x1, mid_x2, y0, ys, z, height)
    made |= _add_rect_pyramid_section_to_bmesh(bm, x2, x3, y0, ys, z, height)
    made |= _add_rect_pyramid_section_to_bmesh(bm, x0, x1, ys, yl, z, height)
    made |= _add_rect_pyramid_section_to_bmesh(bm, x2, x3, ys, yr, z, height)
    return bool(made)


def _add_plus_cross_gable_to_bmesh(bm, points: list[Vector], ox: float, oy: float, z: float, height: float) -> bool:
    params = _plus_params_from_polygon(points)
    if not params:
        return False

    cx = params["cx"]
    cy = params["cy"]
    min_x = params["min_x"] - max(0.0, float(ox))
    max_x = params["max_x"] + max(0.0, float(ox))
    min_y = params["min_y"] - max(0.0, float(oy))
    max_y = params["max_y"] + max(0.0, float(oy))
    tx = params["tx"] + max(0.0, float(ox))
    ty = params["ty"] + max(0.0, float(oy))
    height = max(EPS, float(height))
    if tx <= EPS or ty <= EPS:
        return False

    hz = z + height
    top_verts: dict[tuple[float, float, float], any] = {}
    top_xy: dict[tuple[float, float], any] = {}
    bottom_verts: dict[tuple[float, float], any] = {}
    edge_counts: dict[tuple[tuple[float, float], tuple[float, float]], int] = {}
    made = False

    def k2(x: float, y: float):
        return (round(float(x), 8), round(float(y), 8))

    def k3(x: float, y: float, zz: float):
        return (round(float(x), 8), round(float(y), 8), round(float(zz), 8))

    def top_v(co):
        key3 = k3(*co)
        if key3 not in top_verts:
            vert = bm.verts.new(co)
            top_verts[key3] = vert
            top_xy[k2(co[0], co[1])] = vert
        return top_verts[key3]

    def bottom_v(x: float, y: float):
        key2 = k2(x, y)
        if key2 not in bottom_verts:
            bottom_verts[key2] = bm.verts.new((x, y, z))
        return bottom_verts[key2]

    def add_face(coords):
        nonlocal made
        verts = [top_v(co) for co in coords]
        try:
            bm.faces.new(tuple(verts))
            made = True
        except ValueError:
            pass
        for i in range(len(coords)):
            a = k2(coords[i][0], coords[i][1])
            b = k2(coords[(i + 1) % len(coords)][0], coords[(i + 1) % len(coords)][1])
            key = tuple(sorted((a, b)))
            edge_counts[key] = edge_counts.get(key, 0) + 1


    P0 = (cx - tx, min_y, z)
    P1 = (cx + tx, min_y, z)
    P2 = (cx + tx, cy - ty, z)
    P3 = (max_x, cy - ty, z)
    P4 = (max_x, cy + ty, z)
    P5 = (cx + tx, cy + ty, z)
    P6 = (cx + tx, max_y, z)
    P7 = (cx - tx, max_y, z)
    P8 = (cx - tx, cy + ty, z)
    P9 = (min_x, cy + ty, z)
    P10 = (min_x, cy - ty, z)
    P11 = (cx - tx, cy - ty, z)
    boundary = [P0, P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11]


    W = (min_x, cy, hz)
    WI = (cx - tx, cy, hz)
    C = (cx, cy, hz)
    EI = (cx + tx, cy, hz)
    E = (max_x, cy, hz)
    S = (cx, min_y, hz)
    SI = (cx, cy - ty, hz)
    NI = (cx, cy + ty, hz)
    N = (cx, max_y, hz)


    add_face((P10, P11, WI, W))
    add_face((P8, P9, W, WI))
    add_face((P2, P3, E, EI))
    add_face((P5, EI, E, P4))


    add_face((P0, P11, SI, S))
    add_face((P2, P1, S, SI))
    add_face((P8, P7, N, NI))
    add_face((NI, N, P6, P5))


    add_face((P11, SI, C))
    add_face((P11, C, WI))
    add_face((P2, EI, C))
    add_face((P2, C, SI))
    add_face((P5, NI, C))
    add_face((P5, C, EI))
    add_face((P8, WI, C))
    add_face((P8, C, NI))


    for edge, count in edge_counts.items():
        if count != 1:
            continue
        (ax, ay), (bx, by) = edge
        ta = top_xy.get((ax, ay))
        tb = top_xy.get((bx, by))
        if ta is None or tb is None:
            continue
        ba = bottom_v(ax, ay)
        bb = bottom_v(bx, by)
        if (ta.co - ba.co).length <= EPS and (tb.co - bb.co).length <= EPS:
            continue
        try:
            bm.faces.new((ba, bb, tb, ta))
            made = True
        except ValueError:
            pass


    base_c = bm.verts.new((cx, cy, z))
    bottom_loop = [bottom_v(co[0], co[1]) for co in boundary]
    for i in range(len(bottom_loop)):
        try:
            bm.faces.new((base_c, bottom_loop[(i + 1) % len(bottom_loop)], bottom_loop[i]))
            made = True
        except ValueError:
            pass

    return bool(made)

def _point_on_segment_xy(x: float, y: float, a: Vector, b: Vector, eps: float = EPS) -> bool:
    min_x, max_x = min(a.x, b.x) - eps, max(a.x, b.x) + eps
    min_y, max_y = min(a.y, b.y) - eps, max(a.y, b.y) + eps
    if x < min_x or x > max_x or y < min_y or y > max_y:
        return False
    cross = (b.x - a.x) * (y - a.y) - (b.y - a.y) * (x - a.x)
    return abs(cross) <= eps


def _point_in_polygon_xy(x: float, y: float, points: list[Vector]) -> bool:
    pts = _without_collinear_xy(points)
    n = len(pts)
    if n < 3:
        return False
    for i in range(n):
        if _point_on_segment_xy(x, y, pts[i], pts[(i + 1) % n]):
            return True

    inside = False
    j = n - 1
    for i in range(n):
        pi = pts[i]
        pj = pts[j]
        if ((pi.y > y) != (pj.y > y)):
            xinters = (pj.x - pi.x) * (y - pi.y) / max(EPS, (pj.y - pi.y)) + pi.x
            if x < xinters:
                inside = not inside
        j = i
    return inside


def _dist_point_to_segment_xy(x: float, y: float, a: Vector, b: Vector) -> float:
    ax, ay = a.x, a.y
    bx, by = b.x, b.y
    vx, vy = bx - ax, by - ay
    wx, wy = x - ax, y - ay
    denom = vx * vx + vy * vy
    if denom <= EPS:
        return ((x - ax) ** 2 + (y - ay) ** 2) ** 0.5
    t = max(0.0, min(1.0, (wx * vx + wy * vy) / denom))
    px = ax + t * vx
    py = ay + t * vy
    return ((x - px) ** 2 + (y - py) ** 2) ** 0.5


def _distance_to_polygon_boundary_xy(x: float, y: float, points: list[Vector]) -> float:
    pts = _without_collinear_xy(points)
    if len(pts) < 2:
        return 0.0
    return min(_dist_point_to_segment_xy(x, y, pts[i], pts[(i + 1) % len(pts)]) for i in range(len(pts)))


def _is_same_xy(a: tuple[float, float], b: tuple[float, float], eps: float = EPS) -> bool:
    return abs(a[0] - b[0]) <= eps and abs(a[1] - b[1]) <= eps


def _add_l_footprint_points(points: list[Vector], ox: float, oy: float, z: float) -> list[Vector] | None:
    p = _l_params_from_polygon(points)
    if not p:
        return None
    ox = max(0.0, float(ox))
    oy = max(0.0, float(oy))
    x0 = p["min_x"] - ox
    x1 = p["inner_x"] + ox
    x2 = p["max_x"] + ox
    y0 = p["min_y"] - oy
    y1 = p["inner_y"] + oy
    y2 = p["max_y"] + oy
    if not (x0 + EPS < x1 < x2 - EPS and y0 + EPS < y1 < y2 - EPS):
        return None
    return [
        Vector((x0, y0, z)),
        Vector((x2, y0, z)),
        Vector((x2, y1, z)),
        Vector((x1, y1, z)),
        Vector((x1, y2, z)),
        Vector((x0, y2, z)),
    ]


def _add_u_footprint_points(points: list[Vector], ox: float, oy: float, z: float) -> list[Vector] | None:
    p = _u_params_from_polygon(points)
    if not p:
        return None
    ox = max(0.0, float(ox))
    oy = max(0.0, float(oy))
    x0 = p["min_x"] - ox
    x1 = p["left_inner"] + ox
    x2 = p["right_inner"] - ox
    x3 = p["max_x"] + ox
    y0 = p["min_y"] - oy
    ys = p["support_y"] + oy
    yl = p["left_top"] + oy
    yr = p["right_top"] + oy
    if not (x0 + EPS < x1 < x2 < x3 - EPS):
        return None
    if not (y0 + EPS < ys and yl > ys + EPS and yr > ys + EPS):
        return None
    return [
        Vector((x0, y0, z)),
        Vector((x3, y0, z)),
        Vector((x3, yr, z)),
        Vector((x2, yr, z)),
        Vector((x2, ys, z)),
        Vector((x1, ys, z)),
        Vector((x1, yl, z)),
        Vector((x0, yl, z)),
    ]


def _expanded_lu_footprint_points(obj: bpy.types.Object, points: list[Vector], ox: float, oy: float, z: float) -> list[Vector] | None:
    base_type = str(obj.get("house_base_type", "")).upper().strip() if obj else ""
    if base_type == "L":
        return _add_l_footprint_points(points, ox, oy, z)
    if base_type == "U":
        return _add_u_footprint_points(points, ox, oy, z)
    return None


def _lu_grid_hints(obj: bpy.types.Object, points: list[Vector], ox: float, oy: float) -> tuple[list[float], list[float], list[tuple[float, float]]]:
    base_type = str(obj.get("house_base_type", "")).upper().strip() if obj else ""
    xs: list[float] = []
    ys: list[float] = []
    concave: list[tuple[float, float]] = []
    if base_type == "L":
        p = _l_params_from_polygon(points)
        if not p:
            return xs, ys, concave
        x0 = p["min_x"] - ox
        x1 = p["inner_x"] + ox
        x2 = p["max_x"] + ox
        y0 = p["min_y"] - oy
        y1 = p["inner_y"] + oy
        y2 = p["max_y"] + oy
        xs.extend([(x0 + x1) * 0.5, (x1 + x2) * 0.5])
        ys.extend([(y0 + y1) * 0.5, (y1 + y2) * 0.5])
        concave.append((x1, y1))
    elif base_type == "U":
        p = _u_params_from_polygon(points)
        if not p:
            return xs, ys, concave
        x0 = p["min_x"] - ox
        x1 = p["left_inner"] + ox
        x2 = p["right_inner"] - ox
        x3 = p["max_x"] + ox
        y0 = p["min_y"] - oy
        ysupp = p["support_y"] + oy
        yl = p["left_top"] + oy
        yr = p["right_top"] + oy
        xs.extend([(x0 + x1) * 0.5, (x1 + x2) * 0.5, (x2 + x3) * 0.5])
        ys.extend([(y0 + ysupp) * 0.5, (ysupp + yl) * 0.5, (ysupp + yr) * 0.5])
        concave.extend([(x1, ysupp), (x2, ysupp)])
    return xs, ys, concave


def _add_lu_hip_heightfield_to_bmesh(bm, obj: bpy.types.Object, points: list[Vector], ox: float, oy: float, z: float, height: float) -> bool:
    footprint = _expanded_lu_footprint_points(obj, points, ox, oy, z)
    if not footprint:
        return False
    footprint = _without_collinear_xy(footprint)
    if len(footprint) < 6:
        return False

    extra_x, extra_y, concave_corners = _lu_grid_hints(obj, points, max(0.0, float(ox)), max(0.0, float(oy)))
    xs = _unique_sorted([p.x for p in footprint] + extra_x)
    ys = _unique_sorted([p.y for p in footprint] + extra_y)
    if len(xs) < 2 or len(ys) < 2:
        return False

    def cell_inside(i: int, j: int) -> bool:
        mx = (xs[i] + xs[i + 1]) * 0.5
        my = (ys[j] + ys[j + 1]) * 0.5
        return _point_in_polygon_xy(mx, my, footprint)

    inside_cells = []
    for i in range(len(xs) - 1):
        for j in range(len(ys) - 1):
            if cell_inside(i, j):
                inside_cells.append((i, j))
    if not inside_cells:
        return False


    max_d = 0.0
    candidate_points = []
    for i, j in inside_cells:
        for key in ((i, j), (i + 1, j), (i + 1, j + 1), (i, j + 1)):
            x, y = xs[key[0]], ys[key[1]]
            if _point_in_polygon_xy(x, y, footprint):
                candidate_points.append((x, y))
                max_d = max(max_d, _distance_to_polygon_boundary_xy(x, y, footprint))
    if max_d <= EPS:
        return False

    height = max(EPS, float(height))
    top_verts = {}
    bottom_verts = {}
    edge_counts = {}

    def roof_z(x: float, y: float) -> float:
        d = _distance_to_polygon_boundary_xy(x, y, footprint)
        return z + height * max(0.0, min(1.0, d / max_d))

    def top_vertex(i: int, j: int):
        key = (i, j)
        if key not in top_verts:
            x, y = xs[i], ys[j]
            top_verts[key] = bm.verts.new((x, y, roof_z(x, y)))
        return top_verts[key]

    def bottom_vertex(i: int, j: int):
        key = (i, j)
        if key not in bottom_verts:
            x, y = xs[i], ys[j]
            bottom_verts[key] = bm.verts.new((x, y, z))
        return bottom_verts[key]

    def add_edge(a, b):
        key = tuple(sorted((a, b)))
        edge_counts[key] = edge_counts.get(key, 0) + 1

    def face(seq):
        try:
            bm.faces.new(seq)
            return True
        except ValueError:
            return False

    def use_concave_diagonal(i: int, j: int):

        corners = {
            "v00": (xs[i], ys[j]),
            "v10": (xs[i + 1], ys[j]),
            "v11": (xs[i + 1], ys[j + 1]),
            "v01": (xs[i], ys[j + 1]),
        }
        for cc in concave_corners:
            if _is_same_xy(corners["v00"], cc) or _is_same_xy(corners["v11"], cc):
                return True
            if _is_same_xy(corners["v10"], cc) or _is_same_xy(corners["v01"], cc):
                return False
        return None

    made = False
    for i, j in inside_cells:
        v00 = top_vertex(i, j)
        v10 = top_vertex(i + 1, j)
        v11 = top_vertex(i + 1, j + 1)
        v01 = top_vertex(i, j + 1)
        diag = use_concave_diagonal(i, j)
        if diag is False:
            made |= face((v00, v10, v01))
            made |= face((v10, v11, v01))
        else:
            made |= face((v00, v10, v11))
            made |= face((v00, v11, v01))

        b00 = bottom_vertex(i, j)
        b10 = bottom_vertex(i + 1, j)
        b11 = bottom_vertex(i + 1, j + 1)
        b01 = bottom_vertex(i, j + 1)
        face((b01, b11, b10, b00))

        add_edge((i, j), (i + 1, j))
        add_edge((i + 1, j), (i + 1, j + 1))
        add_edge((i + 1, j + 1), (i, j + 1))
        add_edge((i, j + 1), (i, j))

    for edge, count in edge_counts.items():
        if count != 1:
            continue
        a, b = edge
        ta = top_vertex(*a)
        tb = top_vertex(*b)
        ba = bottom_vertex(*a)
        bb = bottom_vertex(*b)
        face((ba, bb, tb, ta))

    return bool(made)


def _point_in_rect(x: float, y: float, rect: dict) -> bool:
    return (
        rect["min_x"] - EPS <= x <= rect["max_x"] + EPS
        and rect["min_y"] - EPS <= y <= rect["max_y"] + EPS
    )


def _add_rect_union_roof_to_bmesh(
    bm,
    rects: list[dict],
    z: float,
    height: float,
    mode: str = "GABLE",
    thickness: float = 0.15,
) -> bool:
    rects = [r for r in rects if r["max_x"] - r["min_x"] > EPS and r["max_y"] - r["min_y"] > EPS]
    if not rects:
        return False

    mode = str(mode or "GABLE").upper().strip()
    height = max(EPS, float(height))
    thickness = max(EPS, float(thickness))

    xs = []
    ys = []
    for r in rects:
        xs.extend([r["min_x"], r["max_x"]])
        ys.extend([r["min_y"], r["max_y"]])
        axis = str(r.get("axis", "X")).upper()
        cx = (r["min_x"] + r["max_x"]) * 0.5
        cy = (r["min_y"] + r["max_y"]) * 0.5
        if mode == "GABLE":
            if axis == "Y":
                xs.append(cx)
            else:
                ys.append(cy)
        elif mode == "HIP":
            xs.append(cx)
            ys.append(cy)

    xs = _unique_sorted(xs)
    ys = _unique_sorted(ys)
    if len(xs) < 2 or len(ys) < 2:
        return False

    def cell_inside(i: int, j: int) -> bool:
        mx = (xs[i] + xs[i + 1]) * 0.5
        my = (ys[j] + ys[j + 1]) * 0.5
        return any(_point_in_rect(mx, my, r) for r in rects)

    def roof_factor_for_rect(x: float, y: float, r: dict) -> float:
        if not _point_in_rect(x, y, r):
            return 0.0
        w = max(EPS, r["max_x"] - r["min_x"])
        d = max(EPS, r["max_y"] - r["min_y"])
        cx = (r["min_x"] + r["max_x"]) * 0.5
        cy = (r["min_y"] + r["max_y"]) * 0.5
        axis = str(r.get("axis", "X")).upper()
        if mode == "GABLE":
            if axis == "Y":
                return max(0.0, 1.0 - abs(x - cx) / max(EPS, w * 0.5))
            return max(0.0, 1.0 - abs(y - cy) / max(EPS, d * 0.5))
        if mode == "HIP":
            return max(0.0, min(
                (x - r["min_x"]) / max(EPS, w * 0.5),
                (r["max_x"] - x) / max(EPS, w * 0.5),
                (y - r["min_y"]) / max(EPS, d * 0.5),
                (r["max_y"] - y) / max(EPS, d * 0.5),
            ))
        return 1.0

    def roof_z(x: float, y: float) -> float:
        if mode == "FLAT":
            return z + thickness
        return z + height * min(1.0, max(roof_factor_for_rect(x, y, r) for r in rects))

    top_verts = {}
    bottom_verts = {}
    edge_counts = {}
    made_faces = False

    def top_vertex(i: int, j: int):
        key = (i, j)
        if key not in top_verts:
            x, y = xs[i], ys[j]
            top_verts[key] = bm.verts.new((x, y, roof_z(x, y)))
        return top_verts[key]

    def bottom_vertex(i: int, j: int):
        key = (i, j)
        if key not in bottom_verts:
            x, y = xs[i], ys[j]
            bottom_verts[key] = bm.verts.new((x, y, z))
        return bottom_verts[key]

    def add_edge(a, b):
        key = tuple(sorted((a, b)))
        edge_counts[key] = edge_counts.get(key, 0) + 1

    for i in range(len(xs) - 1):
        for j in range(len(ys) - 1):
            if not cell_inside(i, j):
                continue

            v00 = top_vertex(i, j)
            v10 = top_vertex(i + 1, j)
            v11 = top_vertex(i + 1, j + 1)
            v01 = top_vertex(i, j + 1)


            try:
                bm.faces.new((v00, v10, v11))
                made_faces = True
            except ValueError:
                pass
            try:
                bm.faces.new((v00, v11, v01))
                made_faces = True
            except ValueError:
                pass

            b00 = bottom_vertex(i, j)
            b10 = bottom_vertex(i + 1, j)
            b11 = bottom_vertex(i + 1, j + 1)
            b01 = bottom_vertex(i, j + 1)
            try:
                bm.faces.new((b01, b11, b10, b00))
            except ValueError:
                pass

            add_edge((i, j), (i + 1, j))
            add_edge((i + 1, j), (i + 1, j + 1))
            add_edge((i + 1, j + 1), (i, j + 1))
            add_edge((i, j + 1), (i, j))

    for edge, count in edge_counts.items():
        if count != 1:
            continue
        a, b = edge
        ta = top_vertex(*a)
        tb = top_vertex(*b)
        ba = bottom_vertex(*a)
        bb = bottom_vertex(*b)
        try:
            bm.faces.new((ba, bb, tb, ta))
        except ValueError:
            pass

    return made_faces


def _l_params_from_polygon(points: list[Vector]) -> dict | None:
    pts = _without_collinear_xy(points)
    if len(pts) < 6:
        return None
    xs = _unique_sorted([p.x for p in pts])
    ys = _unique_sorted([p.y for p in pts])
    if len(xs) < 3 or len(ys) < 3:
        return None
    min_x, max_x = xs[0], xs[-1]
    min_y, max_y = ys[0], ys[-1]
    inner_x = xs[1]
    inner_y = ys[1]
    if inner_x <= min_x + EPS or inner_x >= max_x - EPS:
        return None
    if inner_y <= min_y + EPS or inner_y >= max_y - EPS:
        return None


    return {
        "min_x": min_x,
        "max_x": max_x,
        "min_y": min_y,
        "max_y": max_y,
        "inner_x": inner_x,
        "inner_y": inner_y,
    }


def _u_params_from_polygon(points: list[Vector]) -> dict | None:
    pts = _without_collinear_xy(points)
    if len(pts) < 8:
        return None
    xs = _unique_sorted([p.x for p in pts])
    ys = _unique_sorted([p.y for p in pts])
    if len(xs) < 4 or len(ys) < 2:
        return None

    min_x, max_x = xs[0], xs[-1]
    left_inner = xs[1]
    right_inner = xs[-2]
    min_y = ys[0]
    max_y = ys[-1]
    support_y = ys[1]
    if not (min_x + EPS < left_inner < right_inner < max_x - EPS):
        return None
    if not (min_y + EPS < support_y <= max_y + EPS):
        return None

    span_x = max(EPS, max_x - min_x)
    tol = max(EPS * 10.0, span_x * 1e-4)
    left_top_candidates = [p.y for p in pts if abs(p.x - min_x) <= tol]
    right_top_candidates = [p.y for p in pts if abs(p.x - max_x) <= tol]
    left_top = max(left_top_candidates) if left_top_candidates else max_y
    right_top = max(right_top_candidates) if right_top_candidates else max_y

    return {
        "min_x": min_x,
        "max_x": max_x,
        "min_y": min_y,
        "max_y": max_y,
        "left_inner": left_inner,
        "right_inner": right_inner,
        "support_y": support_y,
        "left_top": left_top,
        "right_top": right_top,
    }


def _l_roof_rects(points: list[Vector], ox: float, oy: float) -> list[dict]:
    p = _l_params_from_polygon(points)
    if not p:
        return []
    ox = max(0.0, float(ox))
    oy = max(0.0, float(oy))
    return [
        {
            "min_x": p["min_x"] - ox,
            "max_x": p["inner_x"] + ox,
            "min_y": p["min_y"] - oy,
            "max_y": p["max_y"] + oy,
            "axis": "Y",
        },
        {
            "min_x": p["min_x"] - ox,
            "max_x": p["max_x"] + ox,
            "min_y": p["min_y"] - oy,
            "max_y": p["inner_y"] + oy,
            "axis": "X",
        },
    ]


def _u_roof_rects(points: list[Vector], ox: float, oy: float) -> list[dict]:
    p = _u_params_from_polygon(points)
    if not p:
        return []
    ox = max(0.0, float(ox))
    oy = max(0.0, float(oy))
    return [
        {
            "min_x": p["min_x"] - ox,
            "max_x": p["left_inner"] + ox,
            "min_y": p["min_y"] - oy,
            "max_y": p["left_top"] + oy,
            "axis": "Y",
        },
        {
            "min_x": p["right_inner"] - ox,
            "max_x": p["max_x"] + ox,
            "min_y": p["min_y"] - oy,
            "max_y": p["right_top"] + oy,
            "axis": "Y",
        },
        {
            "min_x": p["min_x"] - ox,
            "max_x": p["max_x"] + ox,
            "min_y": p["min_y"] - oy,
            "max_y": p["support_y"] + oy,
            "axis": "X",
        },
    ]


def _add_l_corner_gable_to_bmesh(bm, points: list[Vector], ox: float, oy: float, z: float, height: float) -> bool:
    p = _l_params_from_polygon(points)
    if not p:
        return False

    ox = max(0.0, float(ox))
    oy = max(0.0, float(oy))
    height = max(EPS, float(height))

    x0 = p["min_x"] - ox
    x1 = p["inner_x"] + ox
    x2 = p["max_x"] + ox
    y0 = p["min_y"] - oy
    y1 = p["inner_y"] + oy
    y2 = p["max_y"] + oy

    if x1 <= x0 + EPS or x2 <= x1 + EPS or y1 <= y0 + EPS or y2 <= y1 + EPS:
        return False


    cx = (x0 + x1) * 0.5
    cy = (y0 + y1) * 0.5
    zh = z + height

    verts = {}

    def v(key, x, y, zz):
        if key not in verts:
            verts[key] = bm.verts.new((x, y, zz))
        return verts[key]


    A = v("A_outer_corner", x0, y0, z)
    B = v("B_bottom_inner", x1, y0, z)
    Cb = v("C_bottom_right", x2, y0, z)
    D = v("D_right_top", x2, y1, z)
    E = v("E_inner_corner", x1, y1, z)
    F = v("F_upper_right", x1, y2, z)
    G = v("G_upper_left", x0, y2, z)
    H = v("H_left_inner", x0, y1, z)

    R = v("R_corner_ridge", cx, cy, zh)
    RX = v("RX_right_ridge_end", x2, cy, zh)
    RY = v("RY_upper_ridge_end", cx, y2, zh)

    def face(seq):
        try:
            bm.faces.new(seq)
            return True
        except ValueError:
            return False

    made = False


    made |= face((B, Cb, RX, R))
    made |= face((E, R, RX, D))
    made |= face((Cb, D, RX))


    made |= face((H, G, RY, R))
    made |= face((E, R, RY, F))
    made |= face((G, F, RY))


    made |= face((A, B, R))
    made |= face((A, R, H))
    made |= face((B, E, R))
    made |= face((E, H, R))


    made |= face((A, H, G, F, E, D, Cb, B))

    return bool(made)


def _add_l_corner_hip_to_bmesh(bm, points: list[Vector], ox: float, oy: float, z: float, height: float) -> bool:
    p = _l_params_from_polygon(points)
    if not p:
        return False

    ox = max(0.0, float(ox))
    oy = max(0.0, float(oy))
    height = max(EPS, float(height))

    x0 = p["min_x"] - ox
    x1 = p["inner_x"] + ox
    x2 = p["max_x"] + ox
    y0 = p["min_y"] - oy
    y1 = p["inner_y"] + oy
    y2 = p["max_y"] + oy

    if x1 <= x0 + EPS or x2 <= x1 + EPS or y1 <= y0 + EPS or y2 <= y1 + EPS:
        return False

    cx = (x0 + x1) * 0.5
    cy = (y0 + y1) * 0.5
    zh = z + height


    right_inset = min((y1 - y0) * 0.5, max(EPS, (x2 - cx) * 0.45))
    upper_inset = min((x1 - x0) * 0.5, max(EPS, (y2 - cy) * 0.45))
    rx_x = max(cx + EPS, x2 - right_inset)
    ry_y = max(cy + EPS, y2 - upper_inset)

    verts = {}

    def v(key, x, y, zz):
        if key not in verts:
            verts[key] = bm.verts.new((x, y, zz))
        return verts[key]


    A = v("A_outer_corner", x0, y0, z)
    B = v("B_bottom_inner", x1, y0, z)
    Cb = v("C_bottom_right", x2, y0, z)
    D = v("D_right_top", x2, y1, z)
    E = v("E_inner_corner", x1, y1, z)
    F = v("F_upper_right", x1, y2, z)
    G = v("G_upper_left", x0, y2, z)
    H = v("H_left_inner", x0, y1, z)

    R = v("R_corner_ridge", cx, cy, zh)
    RX = v("RX_right_hip_ridge_end", rx_x, cy, zh)
    RY = v("RY_upper_hip_ridge_end", cx, ry_y, zh)

    def face(seq):
        try:
            bm.faces.new(seq)
            return True
        except ValueError:
            return False

    made = False


    made |= face((B, Cb, RX, R))
    made |= face((E, R, RX, D))
    made |= face((Cb, D, RX))


    made |= face((H, G, RY, R))
    made |= face((E, R, RY, F))
    made |= face((G, F, RY))


    made |= face((A, B, R))
    made |= face((A, R, H))
    made |= face((B, E, R))
    made |= face((E, H, R))


    made |= face((A, H, G, F, E, D, Cb, B))

    return bool(made)


def _add_u_corner_hip_to_bmesh(bm, points: list[Vector], ox: float, oy: float, z: float, height: float) -> bool:
    p = _u_params_from_polygon(points)
    if not p:
        return False

    ox = max(0.0, float(ox))
    oy = max(0.0, float(oy))
    height = max(EPS, float(height))

    x0 = p["min_x"] - ox
    x1 = p["left_inner"] + ox
    x2 = p["right_inner"] - ox
    x3 = p["max_x"] + ox
    y0 = p["min_y"] - oy
    ys = p["support_y"] + oy
    yl = p["left_top"] + oy
    yr = p["right_top"] + oy

    if not (x0 + EPS < x1 < x2 < x3 - EPS):
        return False
    if not (y0 + EPS < ys and yl > ys + EPS and yr > ys + EPS):
        return False

    c_left = (x0 + x1) * 0.5
    c_right = (x2 + x3) * 0.5
    c_support = (y0 + ys) * 0.5
    zh = z + height

    left_leg_width = max(EPS, x1 - x0)
    right_leg_width = max(EPS, x3 - x2)
    left_leg_len = max(EPS, yl - c_support)
    right_leg_len = max(EPS, yr - c_support)


    left_inset = min(left_leg_width * 0.5, left_leg_len * 0.45)
    right_inset = min(right_leg_width * 0.5, right_leg_len * 0.45)
    rlt_y = max(c_support + EPS, yl - left_inset)
    rrt_y = max(c_support + EPS, yr - right_inset)

    verts = {}

    def v(key, x, y, zz):
        if key not in verts:
            verts[key] = bm.verts.new((x, y, zz))
        return verts[key]


    A = v("A_lower_left", x0, y0, z)
    B = v("B_lower_right", x3, y0, z)
    C = v("C_right_outer_top", x3, yr, z)
    D = v("D_right_inner_top", x2, yr, z)
    E = v("E_right_inner_corner", x2, ys, z)
    F = v("F_left_inner_corner", x1, ys, z)
    G = v("G_left_inner_top", x1, yl, z)
    H = v("H_left_outer_top", x0, yl, z)


    RL = v("RL_left_support_ridge", c_left, c_support, zh)
    RR = v("RR_right_support_ridge", c_right, c_support, zh)
    RLT = v("RLT_left_hip_ridge_end", c_left, rlt_y, zh)
    RRT = v("RRT_right_hip_ridge_end", c_right, rrt_y, zh)

    def face(seq):
        try:
            bm.faces.new(seq)
            return True
        except ValueError:
            return False

    made = False


    made |= face((A, B, RR, RL))
    made |= face((F, E, RR, RL))


    made |= face((A, H, RLT, RL))
    made |= face((F, RL, RLT, G))
    made |= face((H, G, RLT))


    made |= face((B, RR, RRT, C))
    made |= face((E, D, RRT, RR))
    made |= face((C, RRT, D))


    made |= face((A, H, G, F, E, D, C, B))

    return bool(made)


def _add_u_corner_gable_to_bmesh(bm, points: list[Vector], ox: float, oy: float, z: float, height: float) -> bool:
    p = _u_params_from_polygon(points)
    if not p:
        return False

    ox = max(0.0, float(ox))
    oy = max(0.0, float(oy))
    height = max(EPS, float(height))

    x0 = p["min_x"] - ox
    x1 = p["left_inner"] + ox
    x2 = p["right_inner"] - ox
    x3 = p["max_x"] + ox
    y0 = p["min_y"] - oy
    ys = p["support_y"] + oy
    yl = p["left_top"] + oy
    yr = p["right_top"] + oy


    if not (x0 + EPS < x1 < x2 < x3 - EPS):
        rects = _u_roof_rects(points, ox, oy)
        return _add_rect_union_roof_to_bmesh(bm, rects, z, height, mode="GABLE", thickness=0.15) if rects else False
    if not (y0 + EPS < ys and ys < max(yl, yr) + EPS):
        return False

    c_left = (x0 + x1) * 0.5
    c_right = (x2 + x3) * 0.5
    c_support = (y0 + ys) * 0.5
    zh = z + height

    verts = {}

    def v(key, x, y, zz):
        if key not in verts:
            verts[key] = bm.verts.new((x, y, zz))
        return verts[key]


    A = v("A_lower_left", x0, y0, z)
    B = v("B_lower_right", x3, y0, z)
    C = v("C_right_outer_top", x3, yr, z)
    D = v("D_right_inner_top", x2, yr, z)
    E = v("E_right_inner_corner", x2, ys, z)
    F = v("F_left_inner_corner", x1, ys, z)
    G = v("G_left_inner_top", x1, yl, z)
    H = v("H_left_outer_top", x0, yl, z)


    RL = v("RL_left_corner_ridge", c_left, c_support, zh)
    RR = v("RR_right_corner_ridge", c_right, c_support, zh)
    RLT = v("RLT_left_leg_ridge_end", c_left, yl, zh)
    RRT = v("RRT_right_leg_ridge_end", c_right, yr, zh)

    def face(seq):
        try:
            bm.faces.new(seq)
            return True
        except ValueError:
            return False

    made = False


    made |= face((A, B, RR, RL))
    made |= face((F, E, RR, RL))


    made |= face((A, H, RLT, RL))
    made |= face((F, RL, RLT, G))
    made |= face((H, G, RLT))


    made |= face((B, RR, RRT, C))
    made |= face((E, D, RRT, RR))
    made |= face((C, RRT, D))


    made |= face((A, H, G, F, E, D, C, B))

    return bool(made)

def _lu_roof_rects(obj: bpy.types.Object, points: list[Vector], ox: float, oy: float) -> list[dict]:
    base_type = str(obj.get("house_base_type", "")).upper().strip() if obj else ""
    if base_type == "L":
        return _l_roof_rects(points, ox, oy)
    if base_type == "U":
        return _u_roof_rects(points, ox, oy)
    return []

def _finish_bmesh_object(obj, mesh, bm, parent):
    try:
        bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=max(EPS * 10.0, 1e-6))
    except Exception:
        pass
    try:
        bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    except Exception:
        pass
    bm.normal_update()
    bm.to_mesh(mesh)
    bm.free()
    mesh.update()
    try:
        obj.update_tag(refresh={"DATA"})
        bpy.context.view_layer.update()
    except Exception:
        pass
    _parent_keep_world(obj, parent)
    return obj


def add_roof(
    obj=None,
    roof_type="PYRAMID",
    roof_height=1.2,
    overhang=0.15,
    overhang_x=0.0,
    overhang_y=0.0,
    thickness=0.15,
    ridge_axis="X",
    gable_type="A",
    pyramid_type="A",
    base_rect_world=None,
    base_polygon_world=None,
):
    _ensure_object_mode()
    if obj is None:
        obj = bpy.context.active_object
    if obj is None or obj.type != "MESH":
        print("Пожалуйста, выберите здание (Mesh).")
        return None

    roof_type = str(roof_type or "PYRAMID").upper().strip()
    ridge_axis = str(ridge_axis or "X").upper().strip()
    gable_type = str(gable_type or "A").upper().strip()
    pyramid_type = str(pyramid_type or "A").upper().strip()

    if base_polygon_world:
        raw_points = [Vector((p.x, p.y, p.z)) for p in base_polygon_world]
        max_z = max(p.z for p in raw_points)
        min_x0, max_x0, min_y0, max_y0, _, _ = _bounds_from_points(raw_points)
    elif base_rect_world is not None:
        min_x0, max_x0, min_y0, max_y0, max_z = base_rect_world
        raw_points = _rect_from_bounds(min_x0, max_x0, min_y0, max_y0, max_z)
    else:
        min_x0, max_x0, min_y0, max_y0, _, max_z, _, _ = _building_bbox_world(obj)
        raw_points = _rect_from_bounds(min_x0, max_x0, min_y0, max_y0, max_z)

    cx, cy = (min_x0 + max_x0) * 0.5, (min_y0 + max_y0) * 0.5
    ox = max(0.0, float(overhang)) + max(0.0, float(overhang_x))
    oy = max(0.0, float(overhang)) + max(0.0, float(overhang_y))

    base_type = str(obj.get("house_base_type", "")).upper().strip() if obj else ""
    use_plus_roof = _should_use_plus_roof(obj, raw_points)
    lu_rects = _lu_roof_rects(obj, _without_collinear_xy(raw_points), ox, oy)
    use_lu_roof = base_type in {"L", "U"} and bool(lu_rects)

    plus_points = _plus_footprint_points(raw_points, ox, oy, max_z) if use_plus_roof else None
    if plus_points:
        points = plus_points
        plus_params = _plus_params_from_polygon(_without_collinear_xy(raw_points))
        cx = plus_params["cx"]
        cy = plus_params["cy"]
    else:
        points = _expanded_rect_or_convex_polygon_xy(raw_points, ox, oy, max_z)

    if roof_type == "PYRAMID":
        roof, mesh = _create_mesh_object("Roof")
        bm = bmesh.new()
        simplified_raw = _without_collinear_xy(raw_points)
        if base_type == "L" and _l_params_from_polygon(simplified_raw):


            if not _add_l_corner_hip_to_bmesh(bm, simplified_raw, ox, oy, max_z, roof_height):
                _add_l_section_hip_roofs_to_bmesh(bm, simplified_raw, ox, oy, max_z, roof_height)
        elif base_type == "U" and _u_params_from_polygon(simplified_raw):


            if not _add_u_corner_hip_to_bmesh(bm, simplified_raw, ox, oy, max_z, roof_height):
                _add_u_section_hip_roofs_to_bmesh(bm, simplified_raw, ox, oy, max_z, roof_height)
        elif base_type in {"L", "U"} and lu_rects:
            _add_rect_union_roof_to_bmesh(bm, lu_rects, max_z, roof_height, mode="HIP", thickness=thickness)
        elif not use_plus_roof and len(_without_collinear_xy(points)) == 4:


            if pyramid_type == "B":
                apex = Vector((cx, cy, max_z + max(EPS, float(roof_height))))
                _add_pyramid_to_bmesh(bm, points, apex)
            else:
                min_x = min(p.x for p in points)
                max_x = max(p.x for p in points)
                min_y = min(p.y for p in points)
                max_y = max(p.y for p in points)
                axis = ridge_axis
                if axis == "AUTO":
                    axis = "X" if (max_x - min_x) >= (max_y - min_y) else "Y"
                _add_rect_hip_to_bmesh(bm, min_x, max_x, min_y, max_y, max_z, roof_height, axis)
        else:
            apex = Vector((cx, cy, max_z + max(EPS, float(roof_height))))
            _add_pyramid_to_bmesh(bm, points, apex)
        return _finish_bmesh_object(roof, mesh, bm, obj)

    if roof_type == "GABLE":
        roof, mesh = _create_mesh_object("Roof")
        bm = bmesh.new()

        simplified_raw = _without_collinear_xy(raw_points)
        if use_plus_roof:
            _add_plus_cross_gable_to_bmesh(bm, simplified_raw, ox, oy, max_z, roof_height)
        elif base_type == "L" and _l_params_from_polygon(simplified_raw):
            _add_l_corner_gable_to_bmesh(bm, simplified_raw, ox, oy, max_z, roof_height)
        elif base_type == "U" and _u_params_from_polygon(simplified_raw):
            _add_u_corner_gable_to_bmesh(bm, simplified_raw, ox, oy, max_z, roof_height)
        elif use_lu_roof:
            _add_rect_union_roof_to_bmesh(bm, lu_rects, max_z, roof_height, mode="GABLE", thickness=thickness)
        else:
            min_x = min_x0 - ox
            max_x = max_x0 + ox
            min_y = min_y0 - oy
            max_y = max_y0 + oy
            if ridge_axis == "AUTO":
                ridge_axis = "X" if (max_x - min_x) >= (max_y - min_y) else "Y"
            _add_rect_gable_to_bmesh(bm, min_x, max_x, min_y, max_y, max_z, roof_height, ridge_axis)

        return _finish_bmesh_object(roof, mesh, bm, obj)

    if roof_type == "FLAT":
        roof, mesh = _create_mesh_object("Roof")
        bm = bmesh.new()
        if use_lu_roof:
            _add_rect_union_roof_to_bmesh(bm, lu_rects, max_z, roof_height, mode="FLAT", thickness=thickness)
        elif base_type == "RECT" and not use_plus_roof:
            min_x = min_x0 - ox
            max_x = max_x0 + ox
            min_y = min_y0 - oy
            max_y = max_y0 + oy
            _add_rect_flat_prism_to_bmesh(bm, min_x, max_x, min_y, max_y, max_z, thickness)
        else:
            _add_flat_prism_to_bmesh(bm, points, thickness)
        return _finish_bmesh_object(roof, mesh, bm, obj)

    if roof_type == "CONE":
        if base_type in {"L", "U"}:
            print("Круглая крыша недоступна для L/U оснований.")
            return None


        min_x = min_x0 - max(0.0, float(overhang))
        max_x = max_x0 + max(0.0, float(overhang))
        min_y = min_y0 - max(0.0, float(overhang))
        max_y = max_y0 + max(0.0, float(overhang))
        radius = max((max_x - min_x), (max_y - min_y)) * 0.5
        bpy.ops.mesh.primitive_cone_add(
            vertices=32,
            radius1=radius,
            radius2=0.0,
            depth=roof_height,
            location=(cx, cy, max_z + roof_height * 0.5),
        )
        roof = bpy.context.active_object
        roof.name = "Roof"
        _parent_keep_world(roof, obj)
        return roof

    print("Неизвестный тип крыши:", roof_type)
    return None
